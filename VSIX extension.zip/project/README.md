# SDLC Agents VSIX v3.0

Enterprise SDLC AI agents for VS Code — 17 agents, encrypted, machine-locked, tamper-protected.

## Setup

See **SETUP.md** for the complete Windows guide (start from zero, no experience needed).
See **QUICK-REFERENCE.md** for the one-page cheat sheet once everything is set up.

## Structure

```
extension/    VS Code extension — ships to customers as .vsix
tools/        Private tools — never ship, never share
agents.md     Your agent definitions (add this file)
instructions.md  Global Copilot instructions (add this file)
build.bat     One-click build: encode → compile → sign → package
test-crypto.js   Verify setup before first build
```

## Quick Commands

```cmd
# First-time setup
node tools\init-config.js
node tools\generate-keys.js
# Update licenseManager.ts with fragment values
# Create setenv.bat from setenv.bat.template

# Verify setup
node test-crypto.js

# Build
setenv.bat
build.bat

# Issue license
node tools\license-gen.js generate --machine "ID" --expires "YYYY-MM-DD" --name "Name"

# View licenses
node tools\license-gen.js list
```

## Security Layers

| Layer | What it protects against |
|-------|--------------------------|
| AES-256-GCM + HMAC-SHA256 | Reading agent content without the key |
| PBKDF2 (250,000 iterations) | Brute-forcing the access code |
| Machine ID binding | Using one license on a different machine |
| RSA-4096 signature | Post-install file tampering |
| 3 clock anchors + 4h recheck | System clock manipulation |
| Config shield (2 layers) | Extracting agent instructions |
| JS obfuscation | Reverse-engineering the key derivation |

## Back Up

```
tools\config.json        ← encryption secrets (CRITICAL)
tools\signing-key.pem    ← RSA private key    (CRITICAL)
tools\license-records.json
```
