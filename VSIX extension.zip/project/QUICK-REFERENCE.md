# SDLC Agents — Quick Reference

## First-Time Setup (once only)

```cmd
node tools\init-config.js           (generates secrets — note the fragment values)
node tools\generate-keys.js         (generates signing keys — choose a password)
```
Update `_f1/_f2/_f3/_f4` in `extension\src\licenseManager.ts` (BOTH locations).
Copy `setenv.bat.template` → `setenv.bat` → fill in your `BUILD_SECRET_A` value.

Verify setup:
```cmd
node test-crypto.js                 (must show 15 passed before building)
```

---

## Every Build

```cmd
setenv.bat          (sets BUILD_SECRET_A for this session)
build.bat           (encode → compile → sign → package)
```
Output: `extension\sdlc-agents-3.0.0.vsix`

---

## Issue a License (10 seconds per customer)

```cmd
cd tools
node license-gen.js generate --machine "MACHINE_ID" --expires "YYYY-MM-DD" --name "Name"
```
→ Email `.bin` file (attachment)
→ Send access code separately (different message)

---

## License Management Commands

```cmd
rem View all licenses
node tools\license-gen.js list

rem Renew (same code, customer re-imports new .bin)
node tools\license-gen.js renew --id lic_001 --expires 2027-12-31

rem Customer changed machine
node tools\license-gen.js add-machine --id lic_001 --machine NEW_MACHINE_ID

rem Revoke immediately
node tools\license-gen.js revoke --id lic_001

rem Inspect a .bin file
node tools\license-gen.js inspect --file tools\output\idx_customer.bin
```

---

## Customer Activation Steps

1. Customer installs the `.vsix`
2. Activation panel shows their **Machine ID** → they send it to you
3. You run `license-gen generate` → get `.bin` file + access code
4. **Email the `.bin` file** as attachment
5. **Send access code separately** (different email / chat)
6. Customer: `Ctrl+Shift+P` → `SDLC Agents: Import License` → select `.bin` → enter code
7. Done — agents active, bound to their machine only

---

## VS Code Commands

| Command | What it does |
|---------|-------------|
| `SDLC Agents: Activate`           | Manually trigger activation |
| `SDLC Agents: Import License`     | Import a `.bin` license file |
| `SDLC Agents: Show My Machine ID` | Display + copy Machine ID |
| `SDLC Agents: Show Status`        | Show expiry info |
| `SDLC Agents: Sign Out`           | Clear saved access code |

---

## Agent Invocation Examples

```
@sdlc-orchestrator start project "RetailApp"
@senior-backend-engineer implement PaymentService
@security-architect review AuthController.java
@code-reviewer review PR #42
@performance-engineer analyse /api/payments/history
@senior-frontend-engineer implement PaymentForm
@qa-automation-engineer write tests for OrderService
```

---

## Rebuild Needed?

| Action | Rebuild? | Command |
|--------|----------|---------|
| New customer | NO | `license-gen generate` |
| License renewal | NO | `license-gen renew` |
| Customer machine changed | NO | `license-gen add-machine` |
| Revoke license | NO | `license-gen revoke` |
| Updated agents.md | YES | `build.bat` |
| Fixed extension bug | YES | `build.bat` |

---

## Back Up These Files

```
tools\config.json           ← encryption secrets  (CRITICAL)
tools\signing-key.pem       ← RSA private key     (CRITICAL)
tools\license-records.json  ← customer database
```
