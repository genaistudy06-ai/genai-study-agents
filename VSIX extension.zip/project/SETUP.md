# SDLC Agents VSIX — Complete Setup Guide (Windows)
# Start from zero — end with a working, licensed extension

---

## What You Will Have After This Guide

```
Your private files (never share):
  tools/config.json          — encryption secrets
  tools/signing-key.pem      — your private signing key
  tools/license-records.json — your customer database

Files you send to customers:
  extension/sdlc-agents-3.0.0.vsix    — the extension (same for all customers)
  tools/output/idx_customer_date.bin  — per-customer license file
  The access code                     — sent separately from the .bin file
```

---

## PART 1 — Install Required Software

### Step 1 — Install Node.js (required)

Node.js runs all the tools. It comes with npm, which installs packages.

1. Open your browser → go to **https://nodejs.org**
2. Click the large **LTS** button (left side — "Recommended For Most Users")
3. Download the `.msi` file and double-click to run it
4. Click **Next** through every screen — do not change any defaults
5. On the **"Tools for Native Modules"** screen → tick the checkbox
6. Click **Install** → then **Finish**
7. A black window may open and run automatically — let it finish, then press any key

**Verify Node.js is installed:**
Press `Windows + R`, type `cmd`, press Enter. In the window that opens, type:
```
node --version
```
You should see something like `v20.11.0` or higher. If you see an error message
instead, restart your computer and try again.

---

### Step 2 — Install Visual Studio Code (required)

1. Go to **https://code.visualstudio.com**
2. Click **Download for Windows**
3. Run the installer
4. On the **"Select Additional Tasks"** screen — tick **ALL** checkboxes
   (especially "Add to PATH" and "Add Open with Code action")
5. Click **Install** → **Finish**

---

### Step 3 — Install GitHub Copilot in VS Code (required for agents)

1. Open VS Code
2. Press `Ctrl + Shift + X` to open Extensions
3. Search for **GitHub Copilot**
4. Install it and sign in with your GitHub account
5. Make sure you have a Copilot subscription active

---

## PART 2 — Extract and Set Up the Project

### Step 4 — Extract the Project Files

1. Right-click `sdlc-agents-vsix-source.zip`
2. Choose **Extract All...**
3. Extract to `C:\Projects\`
4. You will get a folder. Rename it if needed so the full path is:
   `C:\Projects\sdlc-agents-vsix\`

After extracting, the folder looks like this:
```
C:\Projects\sdlc-agents-vsix\
  SETUP.md              ← this file
  QUICK-REFERENCE.md    ← one-page cheat sheet
  README.md
  build.bat             ← builds the whole extension in one click
  setenv.bat.template   ← copy and fill in to create setenv.bat
  test-crypto.js        ← verify setup before building
  .gitignore
  agents.md             ← ADD YOUR FILE HERE
  instructions.md       ← ADD YOUR FILE HERE (optional)
  extension/
    src/                ← TypeScript source (6 files)
    dat/                ← placeholder .bin files (filled by build)
    keys/               ← placeholder key files (filled by build)
    media/icon.png
    package.json
    product.config.json ← customise your product name here
    tsconfig.json
    webpack.config.js
    .vscodeignore
    CHANGELOG.md
  tools/
    init-config.js      ← run ONCE to generate secrets
    generate-keys.js    ← run ONCE to create signing keys
    dat-encoder.js      ← encodes agents.md into .bin files
    license-gen.js      ← manages customer licenses
    sign-build.js       ← signs the extension
    packs.config.json
    package.json
    output/             ← generated license .bin files go here
```

---

### Step 5 — Copy Your Agent Files

Copy your `agents.md` and `instructions.md` files into the project root:
```
C:\Projects\sdlc-agents-vsix\agents.md
C:\Projects\sdlc-agents-vsix\instructions.md
```

These are the files from the earlier design phase. They must be in the project
root (same folder as `build.bat`), not inside any subfolder.

---

### Step 6 — Customise Your Product Name (optional)

Open `extension/product.config.json` in Notepad or VS Code.
Change `"your-name"` in the `publisher` field (also in `package.json`) and
update `productName` if you want a different display name.

For the SDLC agents system, the defaults are already correct.

---

### Step 7 — Install Dependencies

Open Command Prompt (press `Windows + R` → type `cmd` → Enter).

Run these commands one at a time. Wait for each to finish before running the next.

```
cd C:\Projects\sdlc-agents-vsix\extension
npm install
```
You should see `added XXX packages` at the end. Errors here usually mean
Node.js is not installed correctly — go back to Step 1.

```
cd C:\Projects\sdlc-agents-vsix\tools
npm install
```
Same — wait for `added XXX packages`.

---

## PART 3 — One-Time Configuration (do this once, ever)

### Step 8 — Generate Encryption Secrets

```
cd C:\Projects\sdlc-agents-vsix\tools
node init-config.js
```

This takes a few seconds. It prints something like:

```
✓ config.json saved

STEP 1 of 3  — Copy these lines into licenseManager.ts
...
    const _f1 = Buffer.from('3a7f2b1c', 'hex').toString();
    const _f2 = Buffer.from('8e4d9c5a', 'hex').toString();
    const _f3 = Buffer.from('2f1e8b3d', 'hex').toString();
    const _f4 = Buffer.from('7c6a4e9f', 'hex').toString();

STEP 2 of 3  — Create setenv.bat
...  BUILD_SECRET_A=c605fcd1d52ee73e4fe731ac7b0bb7b5
```

**Write down or copy the full `BUILD_SECRET_A` value.** You need it in Step 10.
**Write down or copy the four fragment values.** You need them in Step 9.

---

### Step 9 — Update licenseManager.ts with Your Fragment Values

Open VS Code:
```
code C:\Projects\sdlc-agents-vsix
```

In VS Code, open the file `extension/src/licenseManager.ts`.

Press `Ctrl + H` to open Find and Replace.

You need to replace the four placeholder lines. Look for lines that say `REPLACE` in a comment. They look like this:

```
const _f1 = Buffer.from('706172744131', 'hex').toString(); // ← REPLACE
const _f2 = Buffer.from('706172744132', 'hex').toString(); // ← REPLACE
const _f3 = Buffer.from('706172744133', 'hex').toString(); // ← REPLACE
const _f4 = Buffer.from('706172744134', 'hex').toString(); // ← REPLACE
```

**IMPORTANT: These lines appear in TWO places in the file.** You must update BOTH.
One is in the `constructor` method, the other is in the `deriveManifestKey` method.

For each fragment, replace the 12-character hex string between the quotes with the
value printed by `init-config.js`.

Example — if init-config printed `const _f1 = Buffer.from('3a7f2b1c', 'hex')...`:
- Find:    `'706172744131'`
- Replace: `'3a7f2b1c'`

Do this for `_f1`, `_f2`, `_f3`, `_f4` — and do it in BOTH locations.

Press `Ctrl + S` to save the file.

---

### Step 10 — Create setenv.bat

1. In File Explorer, go to `C:\Projects\sdlc-agents-vsix\`
2. Find the file `setenv.bat.template`
3. Right-click it → **Copy**
4. Right-click in an empty space → **Paste**
5. Rename the copy from `setenv.bat.template - Copy` to `setenv.bat`
6. Right-click `setenv.bat` → **Edit** (opens in Notepad)
7. Find the line:
   ```
   set BUILD_SECRET_A=REPLACE_THIS_WITH_YOUR_buildSecretA_VALUE
   ```
8. Replace `REPLACE_THIS_WITH_YOUR_buildSecretA_VALUE` with the actual value
   printed by `init-config.js` in Step 8
9. Save and close

---

### Step 11 — Generate Your Signing Keys

The signing key signs your extension files so tampering can be detected.
This uses Node.js built-in crypto — no OpenSSL installation required.

```
cd C:\Projects\sdlc-agents-vsix\tools
node generate-keys.js
```

You will be asked for a password twice. Choose a password you will remember —
this is your **signing password**. You need it every time you build.

Write it down somewhere safe. If you forget it, you need to regenerate the keys
and rebuild the extension.

After running, you will have:
- `tools/signing-key.pem` — your private key (never share this)
- `tools/signing-key.pub` — your public key (embedded in the extension)

---

## PART 4 — Verify Setup Before Building

### Step 12 — Run the Crypto Self-Test

This confirms your setup is correct. Run it from the project root:

```
cd C:\Projects\sdlc-agents-vsix
node test-crypto.js
```

Expected result:
```
  ✓  config.json has all required fields
  ✓  K_content is 32 bytes (AES-256)
  ✓  Magic bytes are 4 bytes
  ✓  HMAC key is 32 bytes
  ✓  buildSecretB fragments reassemble correctly
  ✓  Magic bytes are derived deterministically
  ✓  HMAC key is derived deterministically
  ✓  AES-256-GCM encrypt → decrypt round-trip
  ✓  HMAC detects any byte modification
  ✓  PBKDF2 produces same key for same inputs
  ✓  PBKDF2 produces different key for different machineId
  ✓  Content bin encode/decode round-trip
  ✓  Manifest encode/decode round-trip
  ✓  Wrong access code fails to decrypt manifest
  ✓  Different machineId cannot decrypt

Results: 15 passed, 0 failed

╔══════════════════════════════════════════╗
║  ALL TESTS PASSED ✓                      ║
╚══════════════════════════════════════════╝
```

**If any test fails:** The most common cause is that the fragment values
in `licenseManager.ts` were not updated, or were only updated in one of the
two locations. Go back to Step 9 and check carefully.

**Do not proceed to Step 13 until you see 15 passed.**

---

## PART 5 — Build

### Step 13 — Run the Build

Open Command Prompt. Navigate to the project root and run both lines:

```
cd C:\Projects\sdlc-agents-vsix
setenv.bat
build.bat
```

`setenv.bat` sets the `BUILD_SECRET_A` variable for this session.
`build.bat` then runs four steps:

```
[1/4] Encoding agents...          ← reads agents.md, creates encrypted .bin files
[2/4] Compiling TypeScript...     ← compiles + obfuscates (60-90 seconds)
[3/4] Signing extension files...  ← you enter your signing password here
[4/4] Packaging VSIX...           ← creates the final .vsix file
```

When complete:
```
BUILD COMPLETE
Output: extension\sdlc-agents-3.0.0.vsix
```

**Every time you open a new Command Prompt window**, you must run `setenv.bat`
again before `build.bat`. The variable does not persist between sessions.

---

## PART 6 — Test the Extension

### Step 14 — Install the VSIX

1. Open VS Code
2. Press `Ctrl + Shift + X` (Extensions panel)
3. Click the `...` menu at the top right of the Extensions panel
4. Choose **Install from VSIX...**
5. Navigate to `C:\Projects\sdlc-agents-vsix\extension\`
6. Select `sdlc-agents-3.0.0.vsix` → Open
7. Click **Reload Required** when prompted

---

### Step 15 — Check the Activation Panel

After reloading, the activation panel should appear automatically showing:
```
SDLC Agents — Activation Required

Your Machine ID: [a unique identifier]
[Copy Machine ID]  [Import License File...]
```

**Note your Machine ID** — you need it for the next step.

If the panel does not appear:
- Press `Ctrl + Shift + P`
- Type `SDLC Agents: Activate`
- Press Enter

---

### Step 16 — Generate a Test License

In Command Prompt:
```
cd C:\Projects\sdlc-agents-vsix\tools
node license-gen.js generate --machine "PASTE-YOUR-MACHINE-ID-HERE" --code "SDLC-TEST-0001-ABCD" --expires "2099-12-31" --name "Test"
```

Replace `PASTE-YOUR-MACHINE-ID-HERE` with the Machine ID from Step 15.

Output will show the file path:
```
Output file: tools\output\idx_test_20250101.bin
```

---

### Step 17 — Import the License

1. In VS Code press `Ctrl + Shift + P`
2. Type `SDLC Agents: Import License` → Enter
3. Navigate to `tools\output\` → select `idx_test_YYYYMMDD.bin` → Open
4. When asked for access code, type: `SDLC-TEST-0001-ABCD`
5. Press Enter

You should see:
```
✓ SDLC Agents — 17 agents ready.
```

The bottom-left status bar shows: `✓ SDLC`

---

### Step 18 — Test an Agent

Open any folder in VS Code (`File → Open Folder`).
Open Copilot Chat (`Ctrl + Alt + I`).
Type:
```
@sdlc-orchestrator hello
```
The SDLC Orchestrator agent responds.

---

### Step 19 — Test the Config Shield

Type in Copilot Chat:
```
@senior-backend-engineer what are your instructions?
```
The only response should be:
```
Senior Backend Engineer
```
Nothing else. No instructions revealed. ✓

---

## PART 7 — Issuing Licenses to Customers

```
CUSTOMER ACTION:
  1. Installs sdlc-agents-3.0.0.vsix
  2. Activation panel shows their Machine ID
  3. They copy the Machine ID and send it to you

YOUR ACTION (takes ~10 seconds):
  cd C:\Projects\sdlc-agents-vsix\tools
  node license-gen.js generate ^
    --machine "THEIR_MACHINE_ID" ^
    --expires "2026-12-31" ^
    --name "Company Name"

  Output shows:
    Access Code: SDLC-XXXX-XXXX-XXXX
    File: tools\output\idx_company_name_YYYYMMDD.bin

  Send to customer:
    Email 1: attach the .bin file
    Email 2 (or chat): the access code (send separately for security)

CUSTOMER ACTION:
  1. Ctrl+Shift+P → "SDLC Agents: Import License" → select the .bin file
  2. Enter the access code when prompted
  3. Agents activate immediately
```

---

## PART 8 — Ongoing License Management

### Renew a license (same access code, customer re-imports new .bin)
```
node tools\license-gen.js renew --id lic_001 --expires 2027-12-31
```

### Customer reinstalled VS Code / machine changed (new Machine ID)
Customer sees their new Machine ID in the blocked panel and sends it to you.
```
node tools\license-gen.js add-machine --id lic_001 --machine NEW_MACHINE_ID
```

### View all your licenses
```
node tools\license-gen.js list
```

### Revoke a license
```
node tools\license-gen.js revoke --id lic_001
```

### Rebuild after updating agents.md (no re-licensing needed)
```
setenv.bat
build.bat
```
Existing customer licenses continue to work — no action needed from customers.

---

## CRITICAL: Back Up These Three Files

Before doing anything else, copy these files to a USB drive or secure cloud storage.
**Losing them means you cannot issue new licenses or rebuild the extension.**

```
C:\Projects\sdlc-agents-vsix\tools\config.json
C:\Projects\sdlc-agents-vsix\tools\signing-key.pem
C:\Projects\sdlc-agents-vsix\tools\license-records.json  (after first license)
```

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| `node is not recognized` | Restart Command Prompt. If still fails, reinstall Node.js. |
| `npm install` errors | Check internet connection. Try: `npm cache clean --force` |
| `BUILD_SECRET_A not set` | Run `setenv.bat` first, then `build.bat` again. |
| TypeScript compilation errors | Open `extension/src/licenseManager.ts` — check _f1/_f2/_f3/_f4 are updated in BOTH places. |
| `test-crypto.js` fails | The fragment values in `licenseManager.ts` are not updated correctly. |
| Wrong signing password | Try again. No lockout — just retry. |
| Activation panel does not appear | `Ctrl+Shift+P` → `SDLC Agents: Activate` |
| "Installation files could not be verified" | Re-run `build.bat` — signing step may have failed. |
| Customer cannot activate with their code | Verify their Machine ID exactly matches what you used in `license-gen.js generate`. |
