@echo off
setlocal enabledelayedexpansion

echo.
echo =============================================
echo   SDLC Agents VSIX  ^|  Build Script
echo =============================================
echo.

rem ── Set all paths upfront to avoid expansion issues inside blocks ─────────────
set ROOT=%~dp0
if "!ROOT:~-1!"=="\" set ROOT=!ROOT:~0,-1!

set TOOLS_DIR=!ROOT!\tools
set EXT_DIR=!ROOT!\extension
set AGENTS_FILE=!ROOT!\agents.md
set INSTR_FILE=!ROOT!\instructions.md

rem ── Check Node.js ─────────────────────────────────────────────────────────────
where node >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo ERROR: Node.js is not installed.
    echo Install from: https://nodejs.org  ^(choose the LTS version^)
    echo.
    pause & exit /b 1
)

rem ── Check BUILD_SECRET_A ──────────────────────────────────────────────────────
if "!BUILD_SECRET_A!"=="" (
    echo ERROR: BUILD_SECRET_A is not set.
    echo.
    echo Did you run setenv.bat first?
    echo.
    pause & exit /b 1
)

echo [OK] Node.js found
echo [OK] BUILD_SECRET_A is set
echo.

rem ── Check agents.md ───────────────────────────────────────────────────────────
if not exist "!AGENTS_FILE!" (
    echo ERROR: agents.md not found.
    echo Copy it here: !AGENTS_FILE!
    echo.
    pause & exit /b 1
)

rem ── Step 1: Encode agents ──────────────────────────────────────────────────────
echo [1/4] Encoding agents into encrypted bin files...
pushd "!TOOLS_DIR!"

if exist "!INSTR_FILE!" (
    node dat-encoder.js --agents "!AGENTS_FILE!" --instructions "!INSTR_FILE!"
) else (
    node dat-encoder.js --agents "!AGENTS_FILE!"
)

if !ERRORLEVEL! neq 0 (
    popd
    echo.
    echo ERROR: dat-encoder.js failed.
    echo   - Make sure tools\config.json exists ^(run: node tools\init-config.js^)
    echo   - Make sure agents.md is in the project root
    pause & exit /b 1
)
popd
echo.

rem ── Step 2: Build extension ────────────────────────────────────────────────────
echo [2/4] Compiling TypeScript and bundling...
echo       ^(This takes 60-90 seconds -- obfuscation is slow by design^)
pushd "!EXT_DIR!"
call npm run build
if !ERRORLEVEL! neq 0 (
    popd
    echo.
    echo ERROR: Build failed. Common fixes:
    echo   - Run: cd extension ^&^& npm install
    echo   - Check _f1/_f2/_f3/_f4 values in src\licenseManager.ts
    echo   - Check TypeScript errors above
    pause & exit /b 1
)
popd
echo.

rem ── Step 3: Sign the build ─────────────────────────────────────────────────────
echo [3/4] Signing extension files...
if not exist "!TOOLS_DIR!\signing-key.pem" (
    echo ERROR: tools\signing-key.pem not found.
    echo Run: node tools\generate-keys.js
    echo.
    pause & exit /b 1
)
pushd "!TOOLS_DIR!"
node sign-build.js --key signing-key.pem --ext "!EXT_DIR!" --password "!SIGNING_KEY_PASSWORD!"
if !ERRORLEVEL! neq 0 (
    popd
    echo.
    echo ERROR: Signing failed.
    echo   - Check SIGNING_KEY_PASSWORD in setenv.bat
    echo   - If no password was set, leave SIGNING_KEY_PASSWORD= blank
    pause & exit /b 1
)
popd
echo.

rem ── Step 4: Package VSIX ──────────────────────────────────────────────────────
echo [4/4] Packaging as VSIX...

if not exist "!EXT_DIR!\package.json" (
    echo ERROR: Cannot find extension\package.json
    pause & exit /b 1
)

if not exist "!EXT_DIR!\node_modules\@vscode\vsce\vsce" (
    echo vsce not found -- running npm install...
    pushd "!EXT_DIR!"
    call npm install
    popd
)

pushd "!EXT_DIR!"
node node_modules\@vscode\vsce\vsce package --no-dependencies
if !ERRORLEVEL! neq 0 (
    popd
    echo.
    echo ERROR: vsce package failed.
    echo   - Run: cd extension ^&^& npm install
    echo   - Make sure publisher in extension\package.json is not "your-name"
    pause & exit /b 1
)
popd

rem ── Done ──────────────────────────────────────────────────────────────────────
echo.
echo =============================================
echo   BUILD COMPLETE
echo =============================================
echo.
for %%f in ("!EXT_DIR!\*.vsix") do (
    echo   Output: %%f
    echo   Size:   %%~zf bytes
)
echo.
echo Next steps:
echo   1. Install the .vsix in VS Code
echo   2. Generate license: cd tools ^&^& node license-gen.js generate --machine YOUR_ID --expires 2099-12-31 --name "Your Name"
echo   3. In VS Code: SDLC Agents: Import License  then  SDLC Agents: Activate
echo.
pause
