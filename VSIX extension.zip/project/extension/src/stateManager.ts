// stateManager.ts — Activation state machine
import * as vscode from 'vscode';
import * as fs     from 'fs';
import * as path   from 'path';
import { LicenseManager } from './licenseManager';
import { AgentManager   } from './agentManager';
import { UiManager      } from './uiManager';
import {
  ActivationState, ExpiryWarningLevel,
  ManifestPayload, ProductConfig,
} from './types';

const RECHECK_MS = 4 * 60 * 60 * 1000; // 4 hours

export class StateManager {
  private _state:   ActivationState = ActivationState.DORMANT;
  private _manifest: ManifestPayload | undefined;
  private _timer:   NodeJS.Timeout | undefined;
  private _ui:      UiManager | undefined;

  readonly licenseManager: LicenseManager;
  agentManager:            AgentManager;
  readonly productConfig:  ProductConfig;

  constructor(private readonly ctx: vscode.ExtensionContext) {
    this.productConfig  = this.loadConfig();
    this.licenseManager  = new LicenseManager(ctx, this.productConfig);
    // selfLearning is gated by the license feature flag — default false until license validated
    this.agentManager    = new AgentManager(ctx, this.productConfig, false);
  }

  setUiManager(ui: UiManager): void { this._ui = ui; }

  get currentState(): ActivationState        { return this._state;    }
  get manifest(): ManifestPayload | undefined { return this._manifest; }

  // ── Main activation flow ──────────────────────────────────────────────────

  async startActivationFlow(): Promise<void> {
    this.to(ActivationState.CHECKING_MANIFEST);
    try {

      // 1. Check manifest file exists in globalStorage
      this.to(ActivationState.CHECKING_MANIFEST);
      if (!await this.licenseManager.manifestFileExists()) {
        this.to(ActivationState.AWAITING_LICENSE);
        this._ui?.showActivationPanel();
        return;
      }

      // 2. Get or prompt for access code
      this.to(ActivationState.DERIVING_KEY);
      const code = await this.getOrPromptCode();
      if (!code) {
        this.to(ActivationState.AWAITING_LICENSE);
        this._ui?.showActivationPanel();
        return;
      }

      // 3. Validate license (decrypt manifest, check machine, check clock + expiry)
      this.to(ActivationState.DECRYPTING_MANIFEST);
      const machineId = vscode.env.machineId;
      const result    = await this.licenseManager.validateLicense(code, machineId);

      if (!result.valid) {
        this.handleFailure(result.state, machineId);
        return;
      }

      this._manifest = result.manifest;
      this.to(ActivationState.VALIDATING_LICENSE);

      // Re-initialise AgentManager with correct selfLearning flag from license
      const selfLearning = this._manifest!.features.selfLearning === true;
      this.agentManager  = new AgentManager(this.ctx, this.productConfig, selfLearning);

      // 4. Decrypt agent packs
      this.to(ActivationState.DECRYPTING_AGENTS);
      const packs = await this.licenseManager.decryptAgentPacks(this._manifest!);

      // 5. Inject agent files into workspace
      this.to(ActivationState.INJECTING);
      await this.agentManager.injectAgents(packs);

      // 6. Update clock anchor and go ACTIVE
      await this.licenseManager.updateLastVerifiedAt();
      this.to(ActivationState.ACTIVE);
      this._ui?.showActiveNotification(this._manifest!, result.expiryLevel!, result.daysRemaining!);
      this.startRecheckTimer();

    } catch (err) {
      if (typeof __IS_PRODUCTION__ !== 'undefined' && !__IS_PRODUCTION__) {
        console.error('[SDLC] activation error:', err);
      }
      vscode.window.showErrorMessage('SDLC Agents: Activation failed. Please try again.');
      this.to(ActivationState.DORMANT);
    }
  }

  async importLicenseFile(filePath: string): Promise<void> {
    try {
      await this.licenseManager.saveLicenseFile(filePath);
      vscode.window.showInformationMessage('License file imported. Activating...');
      await this.startActivationFlow();
    } catch {
      vscode.window.showErrorMessage('Failed to import license file. Please check the file is valid.');
    }
  }

  async injectAgentsIntoWorkspace(): Promise<void> {
    // No-op: agents are registered as chat participants in memory,
    // not injected as files, so workspace folder changes need no action.
  }

  async deactivate(): Promise<void> {
    this.to(ActivationState.DEACTIVATING);
    this.stopTimer();
    await this.agentManager.cleanupAgents();
    this._manifest = undefined;
  }

  clearAllLearnings(): void {
    // Access learningManager via agentManager — clear all known agent stores
    const lm = (this.agentManager as any).learningManager;
    if (lm && typeof lm.clear === 'function') {
      // We do not know agent IDs here without the manifest, so we clear via file system
      const storageDir = lm.storageDir as string;
      const fs = require('fs');
      const path = require('path');
      if (fs.existsSync(storageDir)) {
        for (const f of fs.readdirSync(storageDir)) {
          if (f.endsWith('.json')) {
            const agentId = path.basename(f, '.json');
            lm.clear(agentId);
          }
        }
      }
    }
  }

  async signOut(): Promise<void> {
    await this.licenseManager.clearCode();
    await this.deactivate();
    this.to(ActivationState.DORMANT);
  }

  // ── Private helpers ───────────────────────────────────────────────────────

  private async getOrPromptCode(): Promise<string | undefined> {
    const saved = await this.licenseManager.getSavedCode();
    if (saved) return saved;

    const prefix = this.productConfig.accessCodePrefix;
    const input  = await vscode.window.showInputBox({
      title:          `${this.productConfig.productName} — Enter Access Code`,
      prompt:         `Format: ${prefix}-XXXX-XXXX-XXXX`,
      placeHolder:    `${prefix}-XXXX-XXXX-XXXX`,
      ignoreFocusOut: true,
      validateInput: (v: string) => {
        const n = v.toUpperCase().trim();
        if (!n) return null;
        const ok = new RegExp(`^${prefix}-[A-F0-9]{4}-[A-F0-9]{4}-[A-F0-9]{4}$`).test(n);
        return ok ? null : `Format: ${prefix}-XXXX-XXXX-XXXX  (X = A-F or 0-9)`;
      },
    });
    if (!input) return undefined;
    const code = input.toUpperCase().trim();
    await this.licenseManager.saveCode(code);
    return code;
  }

  private handleFailure(state: ActivationState, machineId: string): void {
    this.to(state);
    switch (state) {
      case ActivationState.BLOCKED_WRONG_CODE:
        this.licenseManager.clearCode();
        vscode.window.showErrorMessage(
          'SDLC Agents: Access code is not valid. Please check your code.',
          'Try Again',
        ).then(c => { if (c === 'Try Again') this.startActivationFlow(); });
        break;
      case ActivationState.BLOCKED_CLOCK:
        vscode.window.showErrorMessage(
          'SDLC Agents: System clock issue detected. Check your date and time settings.',
          'Retry',
        ).then(c => { if (c === 'Retry') this.startActivationFlow(); });
        break;
      default:
        this._ui?.showBlocked(state, machineId);
    }
  }

  private startRecheckTimer(): void {
    this.stopTimer();
    this._timer = setInterval(async () => {
      if (this._state !== ActivationState.ACTIVE) return;
      const code = await this.licenseManager.getSavedCode();
      if (!code) {
        await this.deactivate();
        this.to(ActivationState.AWAITING_LICENSE);
        this._ui?.showActivationPanel();
        return;
      }
      const r = await this.licenseManager.validateLicense(code, vscode.env.machineId);
      if (!r.valid) {
        await this.deactivate();
        this.handleFailure(r.state, vscode.env.machineId);
      } else if (r.expiryLevel !== ExpiryWarningLevel.NONE) {
        this._ui?.showExpiryWarning(r.expiryLevel!, r.daysRemaining!);
      }
    }, RECHECK_MS);
  }

  private stopTimer(): void {
    if (this._timer) { clearInterval(this._timer); this._timer = undefined; }
  }

  private to(s: ActivationState): void {
    this._state = s;
    this._ui?.onStateChange(s);
  }

  private loadConfig(): ProductConfig {
    const p = path.join(__dirname, '..', 'product.config.json');
    return JSON.parse(fs.readFileSync(p, 'utf-8')) as ProductConfig;
  }
}

declare const __IS_PRODUCTION__: boolean;
