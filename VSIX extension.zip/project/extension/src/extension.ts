// extension.ts — VS Code extension entry point
import * as vscode from 'vscode';
import { StateManager } from './stateManager';
import { UiManager    } from './uiManager';
import { ActivationState } from './types';

let sm: StateManager | undefined;
let ui: UiManager    | undefined;

export async function activate(ctx: vscode.ExtensionContext): Promise<void> {
  sm = new StateManager(ctx);
  ui = new UiManager(ctx, sm);

  ctx.subscriptions.push(

    vscode.commands.registerCommand('sdlcAgents.activate', async () => {
      await sm!.startActivationFlow();
    }),

    vscode.commands.registerCommand('sdlcAgents.importLicense', async () => {
      const uris = await vscode.window.showOpenDialog({
        canSelectFiles: true, canSelectFolders: false, canSelectMany: false,
        title: 'Select Your License File',
        filters: { 'License Files': ['bin'], 'All Files': ['*'] },
      });
      if (uris && uris.length > 0) await sm!.importLicenseFile(uris[0].fsPath);
    }),

    vscode.commands.registerCommand('sdlcAgents.showStatus', () => {
      ui!.showStatusPanel();
    }),

    vscode.commands.registerCommand('sdlcAgents.signOut', async () => {
      const ans = await vscode.window.showWarningMessage(
        'Sign out clears your saved access code. Continue?', 'Sign Out', 'Cancel',
      );
      if (ans === 'Sign Out') {
        await sm!.signOut();
        vscode.window.showInformationMessage('Signed out. Run "SDLC Agents: Activate" to re-activate.');
      }
    }),

    vscode.commands.registerCommand('sdlcAgents.clearLearnings', async () => {
      const ans = await vscode.window.showWarningMessage(
        'Clear all accumulated learnings for all agents? This cannot be undone.',
        'Clear All', 'Cancel',
      );
      if (ans === 'Clear All') {
        sm!.clearAllLearnings();
        vscode.window.showInformationMessage('SDLC Agents: All learnings cleared.');
      }
    }),

    vscode.commands.registerCommand('sdlcAgents.showMachineId', async () => {
      const id  = vscode.env.machineId;
      const ans = await vscode.window.showInformationMessage(
        `Your Machine ID: ${id}`, 'Copy to Clipboard', 'Close',
      );
      if (ans === 'Copy to Clipboard') {
        await vscode.env.clipboard.writeText(id);
        vscode.window.showInformationMessage('Machine ID copied to clipboard.');
      }
    }),

    vscode.workspace.onDidChangeWorkspaceFolders(async () => {
      if (sm!.currentState === ActivationState.ACTIVE) {
        await sm!.injectAgentsIntoWorkspace();
      }
    }),

  );

  const cfg = vscode.workspace.getConfiguration('sdlcAgents');
  if (cfg.get<boolean>('autoActivate', true)) {
    setTimeout(() => sm!.startActivationFlow(), 1500);
  }
}

export async function deactivate(): Promise<void> {
  if (sm) await sm.deactivate();
  sm = undefined;
  ui = undefined;
}
