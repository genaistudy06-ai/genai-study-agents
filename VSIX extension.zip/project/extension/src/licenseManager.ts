// licenseManager.ts — All cryptographic operations
import * as vscode from 'vscode';
import * as crypto  from 'crypto';
import * as fs      from 'fs';
import * as path    from 'path';
import {
  ActivationState, ExpiryWarningLevel,
  ManifestPayload, LicenseValidationResult,
  FileVerificationResult, AgentPack, ProductConfig,
} from './types';

// ── Binary file layout ────────────────────────────────────────────────────────
// All bin files:
//   [0:4]   magic bytes  (4)
//   [4:6]   version      (2)
//   [6:8]   file type    (2)
//   [8:40]  HMAC-SHA256  (32) — covers bytes [40..EOF]
//   [40..]  covered data
//
// idx.bin covered data layout:
//   [40:72]  PBKDF2 salt (32)
//   [72:88]  AES nonce   (16)
//   [88..]   noise + payload + tag + noise + decoy
//
// Content bins (a7e2/b3f9/c1d4) covered data layout:
//   [40:56]  AES nonce   (16)
//   [56..]   noise + payload + tag + noise + decoy

const HMAC_START        = 8;
const DATA_START        = 40;
const IDX_SALT_OFF      = 40;
const IDX_NONCE_OFF     = 72;
const CONTENT_NONCE_OFF = 40;

const SECRET_KEY  = 'sdlc.accessCode';
const LV_KEY      = 'sdlc.lv';
const WARN_DAYS   = 14;
const URGENT_DAYS = 3;

// Injected by webpack DefinePlugin at compile time
declare const __BUILD_SECRET_A__: string;
declare const __IS_PRODUCTION__:  boolean;

export class LicenseManager {
  private readonly ctx:     vscode.ExtensionContext;
  private readonly cfg:     ProductConfig;
  private readonly extPath: string;
  private readonly storage: string;
  private readonly magic:   Buffer;
  private readonly hmacKey: Buffer;

  constructor(ctx: vscode.ExtensionContext, cfg: ProductConfig) {
    this.ctx     = ctx;
    this.cfg     = cfg;
    this.extPath = ctx.extensionPath;
    this.storage = ctx.globalStorageUri.fsPath;
    fs.mkdirSync(this.storage, { recursive: true });

    // ── Assemble crypto primitives ─────────────────────────────────────────
    const bA = __BUILD_SECRET_A__;

    // buildSecretB is stored as 4 hex-encoded fragments.
    // IMPORTANT: After running tools/init-config.js, replace the 12-char hex
    // strings below with the values it prints. Update BOTH occurrences in this
    // file (here in the constructor, and again in deriveManifestKey below).
    const _f1 = Buffer.from('706172744131', 'hex').toString(); // ← REPLACE
    const _f2 = Buffer.from('706172744132', 'hex').toString(); // ← REPLACE
    const _f3 = Buffer.from('706172744133', 'hex').toString(); // ← REPLACE
    const _f4 = Buffer.from('706172744134', 'hex').toString(); // ← REPLACE
    const bB  = _f1 + _f2 + _f3 + _f4;

    this.magic   = crypto.createHash('sha256').update('hdr'  + bA      ).digest().slice(0, 4);
    this.hmacKey = crypto.createHash('sha256').update('hmac' + bA + bB ).digest();
  }

  // ── Extension file verification ───────────────────────────────────────────

  async verifyExtensionFiles(): Promise<FileVerificationResult> {
    const sigPath = path.join(this.extPath, 'keys', 'sig.bin');
    const pkPath  = path.join(this.extPath, 'keys', 'pk.bin');

    // Development builds use placeholder 1-byte files — skip verification
    if (!fs.existsSync(sigPath) || !fs.existsSync(pkPath)) {
      return __IS_PRODUCTION__
        ? { valid: false, failed: 'Signature files missing' }
        : { valid: true };
    }
    const sig = fs.readFileSync(sigPath);
    if (sig.length <= 1) {
      return __IS_PRODUCTION__
        ? { valid: false, failed: 'Signature not generated — run sign-build.js' }
        : { valid: true };
    }

    try {
      const manifest = await this.buildFileManifest();
      const json     = JSON.stringify(Object.fromEntries(Object.entries(manifest).sort()));
      const pkDer    = fs.readFileSync(pkPath);
      const pubKey   = crypto.createPublicKey({ key: pkDer, format: 'der', type: 'spki' });
      const v        = crypto.createVerify('RSA-SHA256');
      v.update(json, 'utf-8');
      return v.verify(pubKey, sig)
        ? { valid: true }
        : { valid: false, failed: 'Signature mismatch — possible tampering' };
    } catch (e) {
      return { valid: false, failed: String(e) };
    }
  }

  private async buildFileManifest(): Promise<Record<string, string>> {
    const result: Record<string, string> = {};
    const files = ['dist/extension.js','dat/a7e2.bin','dat/b3f9.bin',
                   'dat/c1d4.bin','product.config.json'];
                   // package.json excluded: vsce normalizes it during packaging, breaking hash
    for (const rel of files) {
      const abs = path.join(this.extPath, rel);
      if (fs.existsSync(abs)) {
        result[rel.replace(/\\/g, '/')] =
          crypto.createHash('sha256').update(fs.readFileSync(abs)).digest('hex');
      }
    }
    return result;
  }

  // ── Manifest file helpers ─────────────────────────────────────────────────

  async manifestFileExists(): Promise<boolean> {
    const p = path.join(this.storage, 'idx.bin');
    return fs.existsSync(p) && fs.statSync(p).size > 1;
  }

  async saveLicenseFile(src: string): Promise<void> {
    fs.copyFileSync(src, path.join(this.storage, 'idx.bin'));
  }

  // ── Full license validation ───────────────────────────────────────────────

  async validateLicense(code: string, machineId: string): Promise<LicenseValidationResult> {
    const raw = fs.readFileSync(path.join(this.storage, 'idx.bin'));

    // 1. Check magic bytes
    if (!raw.slice(0, 4).equals(this.magic)) {
      return { valid: false, state: ActivationState.BLOCKED_TAMPERED };
    }

    // 2. Verify HMAC (tamper detection)
    if (!this.verifyHmac(raw)) {
      return { valid: false, state: ActivationState.BLOCKED_TAMPERED };
    }

    // 3. Derive key from access code + machineId and decrypt manifest
    const salt      = raw.slice(IDX_SALT_OFF, IDX_SALT_OFF + 32);
    const kManifest = this.deriveManifestKey(code, machineId, salt);

    let manifest: ManifestPayload;
    try {
      const dec = this.decryptBin(raw, kManifest, true);
      manifest  = JSON.parse(dec.toString('utf-8'));
    } catch {
      return { valid: false, state: ActivationState.BLOCKED_WRONG_CODE };
    }

    // 4. Check productId matches this extension
    if (manifest.productId !== this.cfg.productId) {
      return { valid: false, state: ActivationState.BLOCKED_WRONG_CODE };
    }

    // 5. Check machineId is in allowed list
    if (!manifest.allowedMachineIds.includes(machineId)) {
      return { valid: false, state: ActivationState.BLOCKED_MACHINE };
    }

    // 6. Check clock integrity (3 anchors)
    const clockFail = this.checkClock(manifest);
    if (clockFail) return { valid: false, state: clockFail };

    // 7. Calculate expiry level
    const expiryLevel   = this.calcExpiry(manifest);
    const daysRemaining = this.daysLeft(manifest);
    if (expiryLevel === ExpiryWarningLevel.EXPIRED) {
      return { valid: false, state: ActivationState.BLOCKED_EXPIRED };
    }

    return { valid: true, state: ActivationState.ACTIVE, manifest, expiryLevel, daysRemaining };
  }

  // ── Agent pack decryption ─────────────────────────────────────────────────

  async decryptAgentPacks(manifest: ManifestPayload): Promise<AgentPack[]> {
    const kContent = Buffer.from(manifest.contentKey, 'base64');
    const packs: AgentPack[] = [];

    for (const pc of this.cfg.agentPacks) {
      if (!manifest.features.agentPacks.includes(pc.packId)) continue;

      const binPath = path.join(this.extPath, 'dat', pc.file);
      const raw     = fs.readFileSync(binPath);

      if (raw.length <= 1) continue; // placeholder — not yet encoded

      if (!raw.slice(0, 4).equals(this.magic)) throw new Error(`Bad magic: ${pc.file}`);
      if (!this.verifyHmac(raw))               throw new Error(`HMAC fail: ${pc.file}`);

      const dec  = this.decryptBin(raw, kContent, false);
      packs.push(JSON.parse(dec.toString('utf-8')) as AgentPack);
    }
    return packs;
  }

  // ── Crypto primitives ─────────────────────────────────────────────────────

  private decryptBin(buf: Buffer, key: Buffer, isManifest: boolean): Buffer {
    const nonceOff = isManifest ? IDX_NONCE_OFF : CONTENT_NONCE_OFF;
    const nonce    = buf.slice(nonceOff, nonceOff + 16);
    let   off      = nonceOff + 16;
    const ln       = buf.readUInt32BE(off); off += 4 + ln;
    const plen     = buf.readUInt32BE(off); off += 4;
    const ct       = buf.slice(off, off + plen); off += plen;
    const tag      = buf.slice(off, off + 16);
    const d        = crypto.createDecipheriv('aes-256-gcm', key, nonce);
    d.setAuthTag(tag);
    return Buffer.concat([d.update(ct), d.final()]);
  }

  private verifyHmac(buf: Buffer): boolean {
    const stored   = buf.slice(HMAC_START, HMAC_START + 32);
    const covered  = buf.slice(DATA_START);
    const computed = crypto.createHmac('sha256', this.hmacKey).update(covered).digest();
    return stored.length === computed.length && crypto.timingSafeEqual(stored, computed);
  }

  private deriveManifestKey(code: string, machineId: string, salt: Buffer): Buffer {
    const bA = __BUILD_SECRET_A__;
    // Same fragments as constructor — must be updated together
    const _f1 = Buffer.from('706172744131', 'hex').toString(); // ← REPLACE (same values)
    const _f2 = Buffer.from('706172744132', 'hex').toString(); // ← REPLACE
    const _f3 = Buffer.from('706172744133', 'hex').toString(); // ← REPLACE
    const _f4 = Buffer.from('706172744134', 'hex').toString(); // ← REPLACE
    const bB  = _f1 + _f2 + _f3 + _f4;
    const pwd = crypto.createHash('sha256')
      .update(code.toUpperCase() + ':' + machineId + ':' + bA + bB).digest();
    return crypto.pbkdf2Sync(pwd, salt, 250_000, 32, 'sha256');
  }

  // ── Clock integrity (3 anchors) ───────────────────────────────────────────

  private checkClock(m: ManifestPayload): ActivationState | null {
    const now = Date.now();

    // Anchor 1: issuedAt floor — system clock must be AFTER license was issued
    if (now < new Date(m.issuedAt).getTime() - 60_000) {
      return ActivationState.BLOCKED_CLOCK;
    }

    // Anchor 2: lastVerifiedAt — detect clock roll-back after activation
    const lv = this.getLastVerifiedAt();
    if (lv > 0 && now < lv - 120_000) {
      return ActivationState.BLOCKED_CLOCK;
    }

    return null;
  }

  private calcExpiry(m: ManifestPayload): ExpiryWarningLevel {
    const d = this.daysLeft(m);
    if (d < -(m.gracePeriodHours / 24)) return ExpiryWarningLevel.EXPIRED;
    if (d < 0)             return ExpiryWarningLevel.GRACE;
    if (d <= URGENT_DAYS)  return ExpiryWarningLevel.URGENT;
    if (d <= WARN_DAYS)    return ExpiryWarningLevel.WARNING;
    return ExpiryWarningLevel.NONE;
  }

  private daysLeft(m: ManifestPayload): number {
    return Math.floor((new Date(m.expiresAt).getTime() - Date.now()) / 86_400_000);
  }

  // ── lastVerifiedAt timestamp (encrypted, stored in globalState) ───────────

  async updateLastVerifiedAt(): Promise<void> {
    const k   = this.hmacKey.slice(0, 32);
    const n   = crypto.randomBytes(12);
    const c   = crypto.createCipheriv('aes-256-gcm', k, n);
    const enc = Buffer.concat([c.update(Buffer.from(String(Date.now()))), c.final()]);
    const tag = c.getAuthTag();
    await this.ctx.globalState.update(
      LV_KEY, Buffer.concat([n, enc, tag]).toString('base64'),
    );
  }

  private getLastVerifiedAt(): number {
    const s = this.ctx.globalState.get<string>(LV_KEY);
    if (!s) return 0;
    try {
      const b = Buffer.from(s, 'base64');
      const k = this.hmacKey.slice(0, 32);
      const d = crypto.createDecipheriv('aes-256-gcm', k, b.slice(0, 12));
      d.setAuthTag(b.slice(b.length - 16));
      return parseInt(
        Buffer.concat([d.update(b.slice(12, b.length - 16)), d.final()]).toString(), 10,
      );
    } catch { return 0; }
  }

  // ── Access code storage (VS Code SecretStorage = OS keychain) ────────────

  async getSavedCode():     Promise<string | undefined> { return this.ctx.secrets.get(SECRET_KEY); }
  async saveCode(c: string): Promise<void>              { await this.ctx.secrets.store(SECRET_KEY, c); }
  async clearCode(): Promise<void> {
    await this.ctx.secrets.delete(SECRET_KEY);
    await this.ctx.globalState.update(LV_KEY, undefined);
  }
}
