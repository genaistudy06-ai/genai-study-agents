// learningManager.ts — Persists and retrieves per-agent learnings across sessions
// Learning extraction is done locally (no LM calls) to avoid doubling token usage.
import * as vscode from 'vscode';
import * as fs     from 'fs';
import * as path   from 'path';
import * as crypto from 'crypto';
import { AgentLearning, AgentLearningStore } from './types';

const STORE_VERSION = 1;
const MAX_LEARNINGS = 100;  // per agent — oldest pruned when exceeded
const TOP_K_RECALL  = 12;   // learnings injected per request

// ── Local extraction patterns (no LM call needed) ─────────────────────────────
// These match phrases in agent responses that signal a reusable insight.
const LEARNING_PATTERNS: Array<{ regex: RegExp; weight: number }> = [
  { regex: /\b(always|never|make sure|important(?:ly)?|note that|remember that|keep in mind)\b/i,   weight: 3 },
  { regex: /\b(best practice|recommended|prefer|avoid|don't use|use instead)\b/i,                   weight: 3 },
  { regex: /\b(the reason is|because|this is why|root cause|key insight)\b/i,                       weight: 2 },
  { regex: /\b(pattern|convention|standard|rule|guideline)\b/i,                                     weight: 2 },
  { regex: /\b(in this (project|codebase|repo)|your (setup|config|stack))\b/i,                      weight: 4 }, // project-specific = high value
  { regex: /\b(instead of|rather than|as opposed to)\b/i,                                           weight: 2 },
  { regex: /\b(common (mistake|pitfall|issue|error))\b/i,                                           weight: 3 },
];

// Sentences we don't want to store (too generic or conversational)
const SKIP_PATTERNS: RegExp[] = [
  /^(sure|okay|of course|absolutely|great|let me|i (will|can|would)|here('s| is))/i,
  /^(this|that|it) (is|was|seems|looks|appears)/i,
  /thank(s| you)/i,
  /\b(i|me|my|we|our)\b/i,   // first-person — not a reusable fact
];

export class LearningManager {
  readonly storageDir: string;   // readable by stateManager for clearAll
  private cache: Map<string, AgentLearningStore> = new Map();

  constructor(ctx: vscode.ExtensionContext) {
    this.storageDir = path.join(ctx.globalStorageUri.fsPath, 'learnings');
    fs.mkdirSync(this.storageDir, { recursive: true });
  }

  // ── Load store for an agent (cached in memory) ────────────────────────────
  load(agentId: string): AgentLearningStore {
    if (this.cache.has(agentId)) return this.cache.get(agentId)!;
    const p = this.storePath(agentId);
    if (fs.existsSync(p)) {
      try {
        const store = JSON.parse(fs.readFileSync(p, 'utf-8')) as AgentLearningStore;
        this.cache.set(agentId, store);
        return store;
      } catch { /* corrupt — start fresh */ }
    }
    const fresh: AgentLearningStore = { agentId, version: STORE_VERSION, learnings: [] };
    this.cache.set(agentId, fresh);
    return fresh;
  }

  // ── Recall top-K learnings (scored by recency + usage) ───────────────────
  recall(agentId: string): AgentLearning[] {
    const store = this.load(agentId);
    if (store.learnings.length === 0) return [];

    const now    = Date.now();
    const scored = store.learnings.map(l => {
      const ageMins   = (now - new Date(l.lastUsed).getTime()) / 60_000;
      const recency   = Math.exp(-ageMins / (7 * 24 * 60)); // decay over 1 week
      const frequency = Math.log1p(l.usageCount) / Math.log1p(MAX_LEARNINGS);
      return { l, score: 0.6 * recency + 0.4 * frequency };
    });

    scored.sort((a, b) => b.score - a.score);
    return scored.slice(0, TOP_K_RECALL).map(s => s.l);
  }

  // ── Mark recalled learnings as used ──────────────────────────────────────
  markUsed(learnings: AgentLearning[]): void {
    for (const l of learnings) {
      const store = this.cache.get(l.agentId);
      if (!store) continue;
      const entry = store.learnings.find(x => x.id === l.id);
      if (entry) { entry.usageCount++; entry.lastUsed = new Date().toISOString(); }
      this.persist(store);
    }
  }

  // ── Extract learnings locally from a response — ZERO extra LM calls ───────
  extractAndSave(agentId: string, userMessage: string, agentReply: string): void {
    // Split reply into sentences
    const sentences = agentReply
      .replace(/```[\s\S]*?```/g, '')          // strip code blocks — not reusable prose
      .split(/(?<=[.!?])\s+/)
      .map(s => s.trim())
      .filter(s => s.length > 40 && s.length < 300);  // skip too short/long

    for (const sentence of sentences) {
      // Skip non-insightful sentences
      if (SKIP_PATTERNS.some(p => p.test(sentence))) continue;

      // Score the sentence against learning patterns
      let score = 0;
      for (const { regex, weight } of LEARNING_PATTERNS) {
        if (regex.test(sentence)) score += weight;
      }
      if (score < 3) continue;  // not insightful enough

      // Derive a topic from the user message (first 8 words)
      const topic = userMessage
        .replace(/[^a-zA-Z0-9 ]/g, ' ')
        .split(/\s+/)
        .slice(0, 8)
        .join(' ')
        .trim();

      this.save(agentId, topic || 'General insight', sentence);
    }
  }

  // ── Save a single learning (with deduplication) ───────────────────────────
  save(agentId: string, topic: string, insight: string): void {
    const store = this.load(agentId);

    // Deduplicate — skip if a very similar insight already exists
    const duplicate = store.learnings.find(l =>
      l.topic.toLowerCase() === topic.toLowerCase() ||
      this.similarity(l.insight, insight) > 0.82,
    );
    if (duplicate) {
      duplicate.usageCount++;
      duplicate.lastUsed = new Date().toISOString();
      this.persist(store);
      return;
    }

    store.learnings.push({
      id:         crypto.randomBytes(6).toString('hex'),
      agentId,
      learnedAt:  new Date().toISOString(),
      topic,
      insight,
      usageCount: 0,
      lastUsed:   new Date().toISOString(),
    });

    // Prune oldest when over limit
    if (store.learnings.length > MAX_LEARNINGS) {
      store.learnings.sort(
        (a, b) => new Date(a.lastUsed).getTime() - new Date(b.lastUsed).getTime(),
      );
      store.learnings = store.learnings.slice(store.learnings.length - MAX_LEARNINGS);
    }

    this.persist(store);
  }

  // ── Clear all learnings for an agent ─────────────────────────────────────
  clear(agentId: string): void {
    const fresh: AgentLearningStore = { agentId, version: STORE_VERSION, learnings: [] };
    this.cache.set(agentId, fresh);
    this.persist(fresh);
  }

  // ── Stats for status panel ────────────────────────────────────────────────
  stats(agentId: string): { count: number; oldest?: string; newest?: string } {
    const store = this.load(agentId);
    if (store.learnings.length === 0) return { count: 0 };
    const dates = store.learnings.map(l => l.learnedAt).sort();
    return { count: store.learnings.length, oldest: dates[0], newest: dates[dates.length - 1] };
  }

  // ── Helpers ───────────────────────────────────────────────────────────────
  private persist(store: AgentLearningStore): void {
    try {
      fs.writeFileSync(
        this.storePath(store.agentId),
        JSON.stringify(store, null, 2),
        'utf-8',
      );
    } catch { /* best-effort */ }
  }

  private storePath(agentId: string): string {
    return path.join(this.storageDir, `${agentId}.json`);
  }

  private similarity(a: string, b: string): number {
    const words = (s: string) =>
      new Set(s.toLowerCase().split(/\W+/).filter(w => w.length > 3));
    const wa = words(a);
    const wb = words(b);
    if (wa.size === 0 || wb.size === 0) return 0;
    let shared = 0;
    for (const w of wa) if (wb.has(w)) shared++;
    return shared / Math.max(wa.size, wb.size);
  }
}
