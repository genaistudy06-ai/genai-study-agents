// uiManager.ts — Status bar, webview panels, notifications
import * as vscode from 'vscode';
import { ActivationState, ExpiryWarningLevel, ManifestPayload, ProductConfig } from './types';
import { StateManager } from './stateManager';

export class UiManager {
  private bar:   vscode.StatusBarItem;
  private panel: vscode.WebviewPanel | undefined;
  private readonly ctx: vscode.ExtensionContext;
  private readonly sm:  StateManager;
  private readonly cfg: ProductConfig;

  constructor(ctx: vscode.ExtensionContext, sm: StateManager) {
    this.ctx = ctx;
    this.sm  = sm;
    this.cfg = sm.productConfig;
    sm.setUiManager(this);

    this.bar = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 10);
    this.bar.command = 'sdlcAgents.showStatus';
    ctx.subscriptions.push(this.bar);
    this.updateBar(ActivationState.DORMANT);
    this.bar.show();
  }

  onStateChange(s: ActivationState): void { this.updateBar(s); }

  // ── Status bar ────────────────────────────────────────────────────────────

  private updateBar(s: ActivationState): void {
    const L = this.cfg.statusBarLabel;
    this.bar.backgroundColor = undefined;
    switch (s) {
      case ActivationState.ACTIVE:
        this.bar.text    = `$(check) ${L}`;
        this.bar.tooltip = `${this.cfg.productName}: Active — click for status`;
        this.bar.command = 'sdlcAgents.showStatus';
        break;
      case ActivationState.AWAITING_LICENSE:
        this.bar.text    = `$(key) ${L}: Activate`;
        this.bar.tooltip = `${this.cfg.productName}: Click to activate`;
        this.bar.command = 'sdlcAgents.importLicense';
        this.bar.backgroundColor = new vscode.ThemeColor('statusBarItem.warningBackground');
        break;
      case ActivationState.BLOCKED_TAMPERED:
      case ActivationState.BLOCKED_WRONG_CODE:
      case ActivationState.BLOCKED_MACHINE:
      case ActivationState.BLOCKED_CLOCK:
      case ActivationState.BLOCKED_EXPIRED:
        this.bar.text    = `$(error) ${L}: Inactive`;
        this.bar.tooltip = `${this.cfg.productName}: Click for details`;
        this.bar.command = 'sdlcAgents.showStatus';
        this.bar.backgroundColor = new vscode.ThemeColor('statusBarItem.errorBackground');
        break;
      default:
        this.bar.text    = `$(loading~spin) ${L}`;
        this.bar.tooltip = `${this.cfg.productName}: Activating...`;
    }
  }

  // ── Activation panel (no license yet) ────────────────────────────────────

  showActivationPanel(): void {
    this.disposePanel();
    const machineId = vscode.env.machineId;
    const p = vscode.window.createWebviewPanel(
      'sdlcActivation',
      `${this.cfg.productName} — Activation`,
      vscode.ViewColumn.One,
      { enableScripts: true },
    );
    p.webview.html = this.activationHtml(machineId);
    p.webview.onDidReceiveMessage(async (m: { command: string }) => {
      if (m.command === 'copy')   { await vscode.env.clipboard.writeText(machineId); vscode.window.showInformationMessage('Machine ID copied to clipboard.'); }
      if (m.command === 'import') { await vscode.commands.executeCommand('sdlcAgents.importLicense'); }
    }, undefined, this.ctx.subscriptions);
    this.panel = p;
    p.onDidDispose(() => { this.panel = undefined; });
  }

  // ── Blocked panel ─────────────────────────────────────────────────────────

  showBlocked(state: ActivationState, machineId?: string): void {
    this.disposePanel();
    const p = vscode.window.createWebviewPanel(
      'sdlcBlocked',
      `${this.cfg.productName} — Activation Issue`,
      vscode.ViewColumn.One,
      { enableScripts: true },
    );
    p.webview.html = this.blockedHtml(state, machineId);
    p.webview.onDidReceiveMessage(async (m: { command: string }) => {
      if (m.command === 'copy' && machineId) { await vscode.env.clipboard.writeText(machineId); vscode.window.showInformationMessage('Machine ID copied.'); }
      if (m.command === 'import') { p.dispose(); await vscode.commands.executeCommand('sdlcAgents.importLicense'); }
      if (m.command === 'retry')  { p.dispose(); await vscode.commands.executeCommand('sdlcAgents.activate'); }
    }, undefined, this.ctx.subscriptions);
    this.panel = p;
    p.onDidDispose(() => { this.panel = undefined; });
  }

  // ── Status panel (active) ─────────────────────────────────────────────────

  showStatusPanel(): void {
    const m = this.sm.manifest;
    if (!m) {
      vscode.window.showInformationMessage(
        `${this.cfg.productName} is not active.`, 'Activate',
      ).then(c => { if (c === 'Activate') vscode.commands.executeCommand('sdlcAgents.activate'); });
      return;
    }
    const exp = new Date(m.expiresAt).toLocaleDateString('en-GB', { day: '2-digit', month: 'long', year: 'numeric' });
    vscode.window.showInformationMessage(
      `${this.cfg.productName} — Active  |  ${m.customerName}  |  Expires: ${exp}  |  Agents: ${m.features.maxAgents}`,
    );
  }

  // ── Notifications ─────────────────────────────────────────────────────────

  showActiveNotification(m: ManifestPayload, lvl: ExpiryWarningLevel, days: number): void {
    if (lvl === ExpiryWarningLevel.NONE) {
      vscode.window.showInformationMessage(
        `$(check) ${this.cfg.productName} — ${m.features.maxAgents} agents ready.`,
      );
    } else {
      this.showExpiryWarning(lvl, days);
    }
  }

  showExpiryWarning(lvl: ExpiryWarningLevel, days: number): void {
    switch (lvl) {
      case ExpiryWarningLevel.WARNING:
        vscode.window.showWarningMessage(
          `${this.cfg.productName}: License expires in ${days} days. Contact your vendor to renew.`,
        );
        break;
      case ExpiryWarningLevel.URGENT:
        vscode.window.showWarningMessage(
          `${this.cfg.productName}: License expires in ${days} day${days !== 1 ? 's' : ''}!`,
          'Show Machine ID',
        ).then(c => { if (c === 'Show Machine ID') vscode.commands.executeCommand('sdlcAgents.showMachineId'); });
        break;
      case ExpiryWarningLevel.GRACE:
        vscode.window.showErrorMessage(
          `${this.cfg.productName}: License has expired — grace period active.`,
          'Show Machine ID', 'Import License',
        ).then(c => {
          if (c === 'Show Machine ID') vscode.commands.executeCommand('sdlcAgents.showMachineId');
          if (c === 'Import License')  vscode.commands.executeCommand('sdlcAgents.importLicense');
        });
        break;
    }
  }

  // ── HTML builders ─────────────────────────────────────────────────────────

  private activationHtml(machineId: string): string {
    return `<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><style>
body{font-family:var(--vscode-font-family);background:var(--vscode-editor-background);color:var(--vscode-editor-foreground);padding:32px;max-width:560px;margin:0 auto}
h1{font-size:22px;font-weight:600;margin-bottom:4px}
.sub{color:var(--vscode-descriptionForeground);margin-bottom:28px;font-size:14px}
.card{background:var(--vscode-input-background);border:1px solid var(--vscode-panel-border);border-radius:8px;padding:22px;margin:14px 0}
.lbl{font-size:11px;text-transform:uppercase;letter-spacing:.08em;color:var(--vscode-descriptionForeground);margin-bottom:8px}
.id{font-family:monospace;font-size:14px;background:var(--vscode-editor-background);padding:10px 14px;border-radius:4px;border:1px solid var(--vscode-panel-border);word-break:break-all;user-select:all;margin-bottom:10px}
ol{padding-left:20px}li{padding:6px 0;font-size:14px;line-height:1.5}
button{background:var(--vscode-button-background);color:var(--vscode-button-foreground);border:none;border-radius:4px;padding:9px 20px;cursor:pointer;font-size:13px;margin-right:8px;margin-top:8px}
button:hover{background:var(--vscode-button-hoverBackground)}
.sec{background:var(--vscode-button-secondaryBackground);color:var(--vscode-button-secondaryForeground)}
.sec:hover{background:var(--vscode-button-secondaryHoverBackground)}
</style></head><body>
<h1>${this.cfg.productName}</h1>
<p class="sub">Activation Required</p>
<div class="card">
  <div class="lbl">Your Machine ID — send this to your vendor</div>
  <div class="id">${machineId}</div>
  <button onclick="v.postMessage({command:'copy'})">Copy Machine ID</button>
</div>
<div class="card">
  <div class="lbl">How to activate</div>
  <ol>
    <li>Copy your Machine ID above and send it to your vendor.</li>
    <li>Your vendor sends you a <strong>license file (.bin)</strong> and an <strong>access code</strong> separately.</li>
    <li>Click <strong>Import License File</strong> below and select the .bin file.</li>
    <li>Enter the access code when prompted. Activation completes automatically.</li>
  </ol>
</div>
<button onclick="v.postMessage({command:'import'})">Import License File...</button>
<button class="sec" onclick="v.postMessage({command:'copy'})">Copy Machine ID</button>
<script>const v=acquireVsCodeApi();</script>
</body></html>`;
  }

  private blockedHtml(state: ActivationState, machineId?: string): string {
    type Msg = { icon:string; title:string; body:string; copy:boolean; imp:boolean; retry:boolean };
    const msgs: Record<string,Msg> = {
      [ActivationState.BLOCKED_TAMPERED]:  {icon:'⚠',  title:'Installation Issue',     body:'Extension files could not be verified. Please reinstall the extension.',                                                                                copy:false, imp:false, retry:true},
      [ActivationState.BLOCKED_WRONG_CODE]:{icon:'🔑', title:'Access Code Invalid',     body:'The access code is not valid. Please check your code and try again.',                                                                                   copy:false, imp:false, retry:true},
      [ActivationState.BLOCKED_CLOCK]:     {icon:'🕐', title:'System Clock Issue',       body:'Your system clock could not be verified. Please check your date and time settings.',                                                                    copy:false, imp:false, retry:true},
      [ActivationState.BLOCKED_MACHINE]:   {icon:'🖥', title:'Machine Not Authorised',  body:`Your Machine ID has changed or is not registered with your license.<br><br><strong>Your Machine ID:</strong><br><div class="id">${machineId||''}</div>Send this to your vendor to update your license.`, copy:true, imp:true, retry:false},
      [ActivationState.BLOCKED_EXPIRED]:   {icon:'📅', title:'License Expired',          body:`Your license has expired. Contact your vendor to renew it.<br><br><strong>Machine ID for renewal:</strong><br><div class="id">${machineId||''}</div>`,  copy:true, imp:true, retry:false},
    };
    const m = msgs[state] || {icon:'❌',title:'Activation Failed',body:'Please try again or contact your vendor.',copy:false,imp:false,retry:true};
    return `<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><style>
body{font-family:var(--vscode-font-family);background:var(--vscode-editor-background);color:var(--vscode-editor-foreground);padding:32px;max-width:540px;margin:0 auto}
.icon{font-size:44px;margin-bottom:14px}.title{font-size:20px;font-weight:600;margin-bottom:12px}
.body{line-height:1.7;font-size:14px;margin-bottom:22px}.id{font-family:monospace;background:var(--vscode-input-background);padding:9px 12px;border-radius:4px;border:1px solid var(--vscode-panel-border);margin:8px 0;word-break:break-all}
button{background:var(--vscode-button-background);color:var(--vscode-button-foreground);border:none;border-radius:4px;padding:9px 20px;cursor:pointer;font-size:13px;margin-right:8px}
button:hover{background:var(--vscode-button-hoverBackground)}
.sec{background:var(--vscode-button-secondaryBackground);color:var(--vscode-button-secondaryForeground)}
</style></head><body>
<div class="icon">${m.icon}</div>
<div class="title">${m.title}</div>
<div class="body">${m.body}</div>
<div>
${m.retry ? '<button onclick="v.postMessage({command:\'retry\'})">Retry</button>' : ''}
${m.copy  ? '<button onclick="v.postMessage({command:\'copy\'})">Copy Machine ID</button>' : ''}
${m.imp   ? '<button class="sec" onclick="v.postMessage({command:\'import\'})">Import Updated License</button>' : ''}
</div>
<script>const v=acquireVsCodeApi();</script>
</body></html>`;
  }

  private disposePanel(): void {
    if (this.panel) { this.panel.dispose(); this.panel = undefined; }
  }
}
