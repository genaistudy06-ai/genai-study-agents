// types.ts — All shared TypeScript interfaces and enums

export interface ManifestPayload {
  licenseId:          string;
  customerName:       string;
  productId:          string;
  productVersion:     number;
  accessCodeHash:     string;
  issuedAt:           string;
  expiresAt:          string;
  gracePeriodHours:   number;
  allowedMachineIds:  string[];
  features:           LicenseFeatures;
  contentKey:         string;
  contentKeyVersion:  number;
}

export interface LicenseFeatures {
  agentPacks:      string[];
  maxAgents:       number;
  selfLearning:    boolean;
  customStandards: boolean;
}

export enum ActivationState {
  DORMANT             = 'DORMANT',
  VERIFYING_FILES     = 'VERIFYING_FILES',
  CHECKING_MANIFEST   = 'CHECKING_MANIFEST',
  AWAITING_LICENSE    = 'AWAITING_LICENSE',
  DERIVING_KEY        = 'DERIVING_KEY',
  DECRYPTING_MANIFEST = 'DECRYPTING_MANIFEST',
  VALIDATING_LICENSE  = 'VALIDATING_LICENSE',
  DECRYPTING_AGENTS   = 'DECRYPTING_AGENTS',
  INJECTING           = 'INJECTING',
  ACTIVE              = 'ACTIVE',
  DEACTIVATING        = 'DEACTIVATING',
  BLOCKED_TAMPERED    = 'BLOCKED_TAMPERED',
  BLOCKED_WRONG_CODE  = 'BLOCKED_WRONG_CODE',
  BLOCKED_MACHINE     = 'BLOCKED_MACHINE',
  BLOCKED_CLOCK       = 'BLOCKED_CLOCK',
  BLOCKED_EXPIRED     = 'BLOCKED_EXPIRED',
}

export enum ExpiryWarningLevel {
  NONE    = 'NONE',
  WARNING = 'WARNING',
  URGENT  = 'URGENT',
  GRACE   = 'GRACE',
  EXPIRED = 'EXPIRED',
}

export interface ProductConfig {
  productId:          string;
  productName:        string;
  productVersion:     string;
  accessCodePrefix:   string;
  instructionsFile:   string;
  agentPacks:         AgentPackConfig[];
  agentDisplayNames:  Record<string, string>;
  statusBarLabel:     string;
  activationCommand:  string;
  importCommand:      string;
}

export interface AgentPackConfig {
  packId:      string;
  file:        string;
  featureFlag: string;
}

export interface LicenseValidationResult {
  valid:          boolean;
  state:          ActivationState;
  manifest?:      ManifestPayload;
  expiryLevel?:   ExpiryWarningLevel;
  daysRemaining?: number;
}

export interface FileVerificationResult {
  valid:   boolean;
  failed?: string;
}

export interface AgentContent {
  agentId:        string;
  displayName:    string;
  frontmatter:    string;
  body:           string;
  shieldInjected: boolean;
}

export interface AgentPack {
  packId:        string;
  agents:        AgentContent[];
  instructions?: string;
}

// ── Self-learning types ────────────────────────────────────────────────────────

export interface AgentLearning {
  id:          string;   // unique uuid-like id
  agentId:     string;
  learnedAt:   string;   // ISO timestamp
  topic:       string;   // short title, e.g. "Error handling in async flows"
  insight:     string;   // the actual learning (1-3 sentences)
  usageCount:  number;   // how many times this learning has been recalled
  lastUsed:    string;   // ISO timestamp of last recall
}

export interface AgentLearningStore {
  agentId:   string;
  version:   number;
  learnings: AgentLearning[];
}
