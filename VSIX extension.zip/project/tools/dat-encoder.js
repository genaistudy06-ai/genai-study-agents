#!/usr/bin/env node
/**
 * dat-encoder.js — Encrypts agents.md into three encrypted .bin files.
 *
 * Usage:
 *   node dat-encoder.js --agents ../agents.md [--instructions ../instructions.md]
 *
 * Outputs: ../extension/dat/a7e2.bin, b3f9.bin, c1d4.bin
 * Run this whenever agents.md changes.  Never ship this tool.
 */
'use strict';
const crypto = require('crypto');
const fs     = require('fs');
const path   = require('path');

// ── Load config ───────────────────────────────────────────────────────────────

const CFG_PATH   = path.join(__dirname, 'config.json');
const PACKS_PATH = path.join(__dirname, 'packs.config.json');
const DAT_DIR    = path.join(__dirname, '..', 'extension', 'dat');

if (!fs.existsSync(CFG_PATH)) {
  console.error('\nERROR: config.json not found.');
  console.error('Run: node init-config.js first\n');
  process.exit(1);
}

const cfg    = JSON.parse(fs.readFileSync(CFG_PATH,   'utf-8'));
const packs  = JSON.parse(fs.readFileSync(PACKS_PATH, 'utf-8'));

const K_CONTENT = Buffer.from(cfg.contentKey, 'base64');
const HMAC_KEY  = Buffer.from(cfg.hmacKey,    'hex');
const MAGIC     = Buffer.from(cfg.magicBytes, 'hex');

// ── Parse CLI args ────────────────────────────────────────────────────────────

const args = {};
for (let i = 2; i < process.argv.length; i++) {
  if (process.argv[i].startsWith('--') && process.argv[i + 1]) {
    args[process.argv[i].slice(2)] = process.argv[++i];
  }
}

if (!args.agents) {
  console.error('\nUsage: node dat-encoder.js --agents <path> [--instructions <path>]\n');
  process.exit(1);
}
if (!fs.existsSync(args.agents)) {
  console.error(`\nERROR: agents file not found: ${args.agents}\n`);
  process.exit(1);
}

// ── Read source files ─────────────────────────────────────────────────────────

console.log('\n╔═════════════════════════════════════════╗');
console.log('║  SDLC Agents — Dat Encoder               ║');
console.log('╚═════════════════════════════════════════╝\n');

const agentsRaw = fs.readFileSync(args.agents, 'utf-8');
const instrRaw  = args.instructions && fs.existsSync(args.instructions)
  ? fs.readFileSync(args.instructions, 'utf-8')
  : '';

if (!instrRaw) {
  console.log('Note: No instructions file provided (--instructions flag omitted).');
}

// ── Parse agents ──────────────────────────────────────────────────────────────

console.log('\nParsing agent definitions...');
const agents = parseAgents(agentsRaw);
console.log(`  Found ${agents.length} agent definitions\n`);

if (agents.length === 0) {
  console.error('ERROR: No agents found in agents.md');
  console.error('Check the file uses ## AGENT N headings with ```markdown code blocks\n');
  process.exit(1);
}

// ── Encode each pack ──────────────────────────────────────────────────────────

fs.mkdirSync(DAT_DIR, { recursive: true });
console.log('Encoding packs...');

for (const [packId, agentIds] of Object.entries(packs.packs)) {
  const packAgents = agentIds.map(id => {
    const found = agents.find(a => a.agentId === id);
    if (!found) console.warn(`  WARNING: Agent '${id}' not found in agents.md`);
    return found;
  }).filter(Boolean);

  const packData = {
    packId,
    agents:       packAgents,
    instructions: packId === 'core' ? instrRaw : undefined,
  };

  const payload  = Buffer.from(JSON.stringify(packData), 'utf-8');
  const fileType = packs.fileTypes[packId];
  const fileName = packs.packFiles[packId];
  const outPath  = path.join(DAT_DIR, fileName);
  const bin      = buildBin(payload, fileType, K_CONTENT, HMAC_KEY, MAGIC);

  fs.writeFileSync(outPath, bin);
  const kb = (bin.length / 1024).toFixed(1);
  console.log(`  ${packId.padEnd(12)} → ${fileName}  (${kb} KB, ${packAgents.length} agents)`);
}

console.log('\n✓ All packs encoded successfully.\n');
console.log('Next: run build.bat\n');

// ═══════════════════════════════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Parse agents.md into individual agent objects.
 * Expects sections starting with:  ## AGENT N — agent-name
 * Each section contains a ```markdown code block with YAML frontmatter + body.
 */
function parseAgents(raw) {
  const agents   = [];
  // Split on any "## AGENT N" heading (with optional suffix)
  const sections = raw.split(/^## AGENT \d+[^\n]*/m).filter(s => s.trim().length > 0);

  for (const section of sections) {
    // Find ```markdown ... ``` block
    const codeMatch = section.match(/```markdown\s*\n([\s\S]*?)```/);
    if (!codeMatch) continue;

    const codeContent = codeMatch[1];

    // Split frontmatter (---...---) from body
    const fmMatch = codeContent.match(/^(---[\s\S]*?---)\n([\s\S]*)$/);
    if (!fmMatch) continue;

    const frontmatter = fmMatch[1];
    const body        = fmMatch[2].trim();

    // Extract agent ID from `name:` field in frontmatter
    const idMatch = frontmatter.match(/^name:\s*(.+)$/m);
    if (!idMatch) continue;

    const agentId    = idMatch[1].trim();
    const descMatch  = frontmatter.match(/^description:\s*[>|]?\s*\n?\s*(.+)$/m);
    const displayName = descMatch ? descMatch[1].trim().replace(/^>?\s*/, '') : agentId;

    agents.push({ agentId, displayName, frontmatter, body, shieldInjected: false });
  }
  return agents;
}

/**
 * Build a single encrypted .bin file.
 *
 * Layout:
 *   [0:4]   magic bytes  (4)  — non-descriptive, derived from buildSecret
 *   [4:6]   version      (2)  — 0x0300
 *   [6:8]   file type    (2)  — 0x02 / 0x03 / 0x04
 *   [8:40]  HMAC-SHA256  (32) — covers bytes [40..EOF]
 *   [40:56] AES nonce    (16)
 *   [56:60] lead noise len(4)
 *   [60:N]  lead noise   (random bytes)
 *   [N:N+4] payload len  (4)
 *   [...]   AES-256-GCM ciphertext
 *   [...]   GCM auth tag (16)
 *   [...]   tail noise len (4)
 *   [...]   tail noise
 *   [...]   decoy block
 */
function buildBin(payload, fileType, kContent, hmacKey, magic) {
  const VERSION  = Buffer.from([0x03, 0x00]);
  const FTYPE    = Buffer.alloc(2); FTYPE.writeUInt16BE(fileType, 0);

  // Random nonce for AES-GCM
  const nonce = crypto.randomBytes(16);

  // Lead noise — random size 512–2048 bytes
  const leadLen = 512 + Math.floor(Math.random() * 1537);
  const leadBuf = Buffer.alloc(4); leadBuf.writeUInt32BE(leadLen, 0);
  const lead    = crypto.randomBytes(leadLen);

  // Encrypt payload
  const cipher  = crypto.createCipheriv('aes-256-gcm', kContent, nonce);
  const enc     = Buffer.concat([cipher.update(payload), cipher.final()]);
  const authTag = cipher.getAuthTag();                   // 16 bytes
  const plenBuf = Buffer.alloc(4); plenBuf.writeUInt32BE(enc.length, 0);

  // Tail noise — random size 256–1024 bytes
  const tailLen = 256 + Math.floor(Math.random() * 769);
  const tailBuf = Buffer.alloc(4); tailBuf.writeUInt32BE(tailLen, 0);
  const tail    = crypto.randomBytes(tailLen);

  // Decoy block — convincing-looking fake metadata to mislead hex editors
  const decoyMagic = Buffer.from([0xDE, 0xAD, 0xBE, 0xEF]);
  const decoyData  = Buffer.from(JSON.stringify({
    v: 2,
    ts: Date.now() - Math.floor(Math.random() * 1_000_000),
    checksum: crypto.randomBytes(16).toString('hex'),
    meta:     crypto.randomBytes(24).toString('base64'),
  }));
  const decoyLen   = Buffer.alloc(4); decoyLen.writeUInt32BE(decoyData.length, 0);
  const decoy      = Buffer.concat([decoyMagic, decoyLen, decoyData]);

  // The HMAC covers everything from offset 40 to EOF
  const covered = Buffer.concat([
    nonce, leadBuf, lead, plenBuf, enc, authTag, tailBuf, tail, decoy,
  ]);

  const hmac = crypto.createHmac('sha256', hmacKey).update(covered).digest();

  return Buffer.concat([magic, VERSION, FTYPE, hmac, covered]);
}
