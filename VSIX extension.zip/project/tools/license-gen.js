#!/usr/bin/env node
/**
 * license-gen.js — Generate and manage per-customer idx.bin license files.
 *
 * Commands:
 *   generate    --machine ID [--code CODE] --expires YYYY-MM-DD --name "Name"
 *   renew       --id LIC_ID --expires YYYY-MM-DD
 *   add-machine --id LIC_ID --machine NEW_MACHINE_ID
 *   revoke      --id LIC_ID
 *   inspect     --file path/to/idx.bin
 *   list        [--status active|expired|revoked]
 *
 * Never ship this file. Never share config.json.
 */
'use strict';

const crypto   = require('crypto');
const fs       = require('fs');
const path     = require('path');
const readline = require('readline');

// ── Load config ───────────────────────────────────────────────────────────────
const CFG_PATH  = path.join(__dirname, 'config.json');
const DB_PATH   = path.join(__dirname, 'license-records.json');
const OUT_DIR   = path.join(__dirname, 'output');

if (!fs.existsSync(CFG_PATH)) {
  console.error('\nERROR: config.json not found.\nRun: node tools/init-config.js first.\n');
  process.exit(1);
}

const cfg    = JSON.parse(fs.readFileSync(CFG_PATH, 'utf-8'));
const HMAC_K = Buffer.from(cfg.hmacKey,    'hex');
const MAGIC  = Buffer.from(cfg.magicBytes, 'hex');
fs.mkdirSync(OUT_DIR, { recursive: true });

// ── Helpers ───────────────────────────────────────────────────────────────────
function loadDb()    { return fs.existsSync(DB_PATH) ? JSON.parse(fs.readFileSync(DB_PATH)) : { licenses: [], nextId: 1 }; }
function saveDb(d)   { fs.writeFileSync(DB_PATH, JSON.stringify(d, null, 2)); }
function newId(d)    { const id = `lic_${String(d.nextId).padStart(3,'0')}`; d.nextId++; return id; }
function sha256(s)   { return crypto.createHash('sha256').update(s).digest('hex'); }
function safeName(s) { return s.replace(/[^a-zA-Z0-9]/g,'_').toLowerCase(); }
function dateStamp() { return new Date().toISOString().slice(0,10).replace(/-/g,''); }

function genCode() {
  const prefix = (cfg.accessCodePrefix || 'SDLC').toUpperCase();
  const raw    = crypto.randomBytes(6).toString('hex').toUpperCase();
  return `${prefix}-${raw.slice(0,4)}-${raw.slice(4,8)}-${raw.slice(8,12)}`;
}

function deriveKey(code, machineId, salt) {
  const pwd = crypto.createHash('sha256')
    .update(code.toUpperCase() + ':' + machineId + ':' + cfg.buildSecretA + cfg.buildSecretB)
    .digest();
  return crypto.pbkdf2Sync(pwd, salt, 250_000, 32, 'sha256');
}

function buildManifestObj(rec, machineId) {
  return {
    licenseId:          rec.id,
    customerName:       rec.customer,
    productId:          cfg.productId || 'sdlc-agents',
    productVersion:     cfg.contentKeyVersion || 1,
    accessCodeHash:     sha256(rec.code),
    issuedAt:           rec.issuedAt,
    expiresAt:          rec.expiresAt,
    gracePeriodHours:   24,
    allowedMachineIds:  rec.machineIds,
    features: {
      agentPacks:       ['core','engineering','governance'],
      maxAgents:        17,
      selfLearning:     true,
      customStandards:  true,
    },
    contentKey:         cfg.contentKey,
    contentKeyVersion:  cfg.contentKeyVersion || 1,
  };
}

function buildIdxBin(manifest, salt, key) {
  const VERSION  = Buffer.from([0x03, 0x00]);
  const FTYPE    = Buffer.from([0x00, 0x01]);
  const nonce    = crypto.randomBytes(16);
  const payload  = Buffer.from(JSON.stringify(manifest), 'utf-8');

  // Lead noise 512–2048 bytes
  const lnLen    = 512 + Math.floor(Math.random() * 1537);
  const noise1   = crypto.randomBytes(lnLen);
  const lnBuf    = Buffer.alloc(4); lnBuf.writeUInt32BE(lnLen, 0);

  // Encrypt
  const ci       = crypto.createCipheriv('aes-256-gcm', key, nonce);
  const enc      = Buffer.concat([ci.update(payload), ci.final()]);
  const tag      = ci.getAuthTag();
  const plenBuf  = Buffer.alloc(4); plenBuf.writeUInt32BE(enc.length, 0);

  // Tail noise 256–1024 bytes
  const tnLen    = 256 + Math.floor(Math.random() * 769);
  const noise2   = crypto.randomBytes(tnLen);
  const tnBuf    = Buffer.alloc(4); tnBuf.writeUInt32BE(tnLen, 0);

  // Decoy block (misleads hex editor analysis)
  const dm       = Buffer.from([0xDE, 0xAD, 0xBE, 0xEF]);
  const dd       = Buffer.from(JSON.stringify({ ts: Date.now(), p: crypto.randomBytes(8).toString('hex') }));
  const dl       = Buffer.alloc(4); dl.writeUInt32BE(dd.length, 0);
  const decoy    = Buffer.concat([dm, dl, dd]);

  // idx.bin covered region: salt(32) + nonce(16) + noise + payload + noise + decoy
  const covered  = Buffer.concat([salt, nonce, lnBuf, noise1, plenBuf, enc, tag, tnBuf, noise2, decoy]);
  const hmac     = crypto.createHmac('sha256', HMAC_K).update(covered).digest();
  return Buffer.concat([MAGIC, VERSION, FTYPE, hmac, covered]);
}

function writeIdxBin(rec, machineId, suffix) {
  const m       = buildManifestObj(rec, machineId);
  const salt    = crypto.randomBytes(32);
  const key     = deriveKey(rec.code, machineId, salt);
  const bin     = buildIdxBin(m, salt, key);
  const outFile = path.join(OUT_DIR, `idx_${safeName(rec.customer)}_${suffix || dateStamp()}.bin`);
  fs.writeFileSync(outFile, bin);
  return outFile;
}

function verifyHmac(buf) {
  const stored   = buf.slice(8, 40);
  const covered  = buf.slice(40);
  const computed = crypto.createHmac('sha256', HMAC_K).update(covered).digest();
  if (stored.length !== computed.length) return false;
  return crypto.timingSafeEqual(stored, computed);
}

// ── Parse CLI args ────────────────────────────────────────────────────────────
const command = process.argv[2];
const args    = {};
for (let i = 3; i < process.argv.length; i++) {
  if (process.argv[i].startsWith('--') && process.argv[i+1] && !process.argv[i+1].startsWith('--')) {
    args[process.argv[i].slice(2)] = process.argv[++i];
  } else if (process.argv[i].startsWith('--')) {
    args[process.argv[i].slice(2)] = true;
  }
}

// ── Commands ──────────────────────────────────────────────────────────────────

if (command === 'generate') {
  if (!args.machine || !args.expires) {
    console.error('\nRequired: --machine MACHINE_ID --expires YYYY-MM-DD\n');
    console.error('Example:');
    console.error('  node license-gen.js generate --machine "abc-123" --expires "2026-12-31" --name "Acme Corp"\n');
    process.exit(1);
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(args.expires)) {
    console.error('\n--expires must be YYYY-MM-DD format (e.g. 2026-12-31)\n');
    process.exit(1);
  }

  const code = (args.code ? args.code.toUpperCase() : genCode());
  const d    = loadDb();
  const rec  = {
    id:         newId(d),
    customer:   args.name || 'Customer',
    machineIds: [args.machine],
    code,
    issuedAt:   new Date().toISOString(),
    expiresAt:  new Date(args.expires + 'T23:59:59Z').toISOString(),
    status:     'active',
  };

  const outFile = writeIdxBin(rec, args.machine);
  d.licenses.push({ ...rec, outputFile: outFile });
  saveDb(d);

  console.log('\n✓ License generated successfully\n');
  console.log(`  License ID:   ${rec.id}`);
  console.log(`  Customer:     ${rec.customer}`);
  console.log(`  Machine ID:   ${args.machine}`);
  console.log(`  Access Code:  ${code}`);
  console.log(`  Expires:      ${args.expires}`);
  console.log(`  Output file:  ${outFile}\n`);
  console.log('  ─────────────────────────────────────────────────────');
  console.log('  ACTION REQUIRED:');
  console.log(`  1. Email the .bin file as attachment:  ${outFile}`);
  console.log(`  2. Send access code SEPARATELY (email/chat): ${code}`);
  console.log('  ─────────────────────────────────────────────────────\n');
}

else if (command === 'renew') {
  if (!args.id || !args.expires) { console.error('\nRequired: --id LIC_ID --expires YYYY-MM-DD\n'); process.exit(1); }
  const d   = loadDb();
  const rec = d.licenses.find(l => l.id === args.id);
  if (!rec) { console.error(`\nLicense '${args.id}' not found.\n`); process.exit(1); }

  rec.expiresAt = new Date(args.expires + 'T23:59:59Z').toISOString();
  rec.status    = 'active';

  const files = rec.machineIds.map(mid => writeIdxBin(rec, mid, 'renewed_' + dateStamp()));
  saveDb(d);

  console.log(`\n✓ License ${args.id} renewed until ${args.expires}`);
  files.forEach(f => console.log(`  File: ${f}`));
  console.log('  Same access code — customer just imports the new .bin file.\n');
}

else if (command === 'add-machine') {
  if (!args.id || !args.machine) { console.error('\nRequired: --id LIC_ID --machine NEW_MACHINE_ID\n'); process.exit(1); }
  const d   = loadDb();
  const rec = d.licenses.find(l => l.id === args.id);
  if (!rec) { console.error(`\nLicense '${args.id}' not found.\n`); process.exit(1); }

  if (!rec.machineIds.includes(args.machine)) rec.machineIds.push(args.machine);

  const outFile = writeIdxBin(rec, args.machine, 'newmachine_' + dateStamp());
  saveDb(d);

  console.log(`\n✓ Machine added to ${args.id}`);
  console.log(`  File: ${outFile}`);
  console.log('  Same access code. Customer imports the new .bin file.\n');
}

else if (command === 'revoke') {
  if (!args.id) { console.error('\nRequired: --id LIC_ID\n'); process.exit(1); }
  const d   = loadDb();
  const rec = d.licenses.find(l => l.id === args.id);
  if (!rec) { console.error(`\nLicense '${args.id}' not found.\n`); process.exit(1); }

  // Set expiry to yesterday — immediately fails expiry check when imported
  rec.expiresAt = new Date(Date.now() - 86_400_000).toISOString();
  rec.status    = 'revoked';

  const files = rec.machineIds.map(mid => writeIdxBin(rec, mid, 'REVOKED'));
  saveDb(d);

  console.log(`\n✓ License ${args.id} revoked.`);
  files.forEach(f => console.log(`  Revocation file: ${f}`));
  console.log('  Option A: Send the revocation .bin file to customer — blocks on import.');
  console.log('  Option B: Do nothing — license blocks when it reaches its natural expiry date.\n');
}

else if (command === 'inspect') {
  if (!args.file || !fs.existsSync(args.file)) {
    console.error('\nRequired: --file path/to/idx.bin\n');
    process.exit(1);
  }

  const raw = fs.readFileSync(args.file);
  console.log(`\n  File: ${args.file}`);
  console.log(`  Size: ${raw.length} bytes`);
  console.log(`  HMAC: ${verifyHmac(raw) ? '✓ VALID' : '✗ TAMPERED OR INVALID'}`);

  if (!verifyHmac(raw)) {
    console.error('  Cannot inspect — file may have been modified.\n');
    process.exit(1);
  }

  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  rl.question('\n  Enter access code:  ', code => {
    rl.question('  Enter machine ID:   ', machineId => {
      rl.close();
      try {
        const salt  = raw.slice(40, 72);
        const nonce = raw.slice(72, 88);
        const key   = deriveKey(code.trim().toUpperCase(), machineId.trim(), salt);

        let off = 88;
        const lnLen = raw.readUInt32BE(off); off += 4 + lnLen;
        const pLen  = raw.readUInt32BE(off); off += 4;
        const ct    = raw.slice(off, off + pLen); off += pLen;
        const tag   = raw.slice(off, off + 16);

        const dc = crypto.createDecipheriv('aes-256-gcm', key, nonce);
        dc.setAuthTag(tag);
        const m = JSON.parse(Buffer.concat([dc.update(ct), dc.final()]).toString('utf-8'));

        console.log('\n  ─── License Contents ─────────────────');
        console.log(`  License ID:   ${m.licenseId}`);
        console.log(`  Customer:     ${m.customerName}`);
        console.log(`  Product:      ${m.productId}`);
        console.log(`  Machine IDs:  ${m.allowedMachineIds.join(', ')}`);
        console.log(`  Issued:       ${m.issuedAt}`);
        console.log(`  Expires:      ${m.expiresAt}`);
        console.log(`  Grace (hrs):  ${m.gracePeriodHours}`);
        console.log(`  Packs:        ${m.features.agentPacks.join(', ')}`);
        console.log(`  Key version:  ${m.contentKeyVersion}`);
        console.log('  ──────────────────────────────────────\n');
      } catch {
        console.error('\n  Decryption failed — wrong access code or machine ID.\n');
      }
    });
  });
}

else if (command === 'list') {
  const d   = loadDb();
  const all = args.status ? d.licenses.filter(l => l.status === args.status) : d.licenses;

  if (all.length === 0) {
    console.log('\n  No licenses found.\n');
    process.exit(0);
  }

  console.log('\n  ID          Customer              Machine ID (first)      Code               Issued      Expires      Status');
  console.log('  ─────────── ──────────────────── ─────────────────────── ────────────────── ─────────── ──────────── ────────');
  for (const l of all) {
    const cust  = (l.customer   || '').padEnd(20).slice(0, 20);
    const mid   = (l.machineIds && l.machineIds[0] || '').padEnd(23).slice(0, 23);
    const code  = (l.code       || '').padEnd(18).slice(0, 18);
    const iss   = (l.issuedAt   || '').slice(0, 10);
    const exp   = (l.expiresAt  || '').slice(0, 10);
    const stat  = l.status === 'active' ? 'ACTIVE' : l.status === 'revoked' ? 'REVOKED' : 'EXPIRED';
    console.log(`  ${l.id.padEnd(11)} ${cust} ${mid} ${code} ${iss} ${exp} ${stat}`);
  }
  console.log('');
}

else {
  console.log('\nUsage: node license-gen.js <command> [options]');
  console.log('\nCommands:');
  console.log('  generate    --machine MACHINE_ID --expires YYYY-MM-DD --name "Name" [--code CODE]');
  console.log('  renew       --id LIC_ID --expires YYYY-MM-DD');
  console.log('  add-machine --id LIC_ID --machine NEW_MACHINE_ID');
  console.log('  revoke      --id LIC_ID');
  console.log('  inspect     --file path/to/idx.bin');
  console.log('  list        [--status active|expired|revoked]');
  console.log('\nExamples:');
  console.log('  node license-gen.js generate --machine "abc-123" --expires "2026-12-31" --name "Acme Corp"');
  console.log('  node license-gen.js renew --id lic_001 --expires "2027-06-30"');
  console.log('  node license-gen.js list\n');
}
