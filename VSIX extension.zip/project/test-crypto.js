#!/usr/bin/env node
/**
 * test-crypto.js — Verify the full encryption round-trip before building.
 * Run from the project root after init-config.js and updating licenseManager.ts.
 *
 * Usage: node test-crypto.js
 * Must show 15 passed before running build.bat.
 */
'use strict';

const crypto   = require('crypto');
const fs       = require('fs');
const path     = require('path');

const CFG_PATH = path.join(__dirname, 'tools', 'config.json');

if (!fs.existsSync(CFG_PATH)) {
  console.log('\n✗ config.json not found. Run: node tools/init-config.js first.\n');
  process.exit(1);
}

const cfg   = JSON.parse(fs.readFileSync(CFG_PATH, 'utf-8'));
const KC    = Buffer.from(cfg.contentKey,  'base64');
const HK    = Buffer.from(cfg.hmacKey,     'hex');
const MAGIC = Buffer.from(cfg.magicBytes,  'hex');

let passed = 0, failed = 0;

function test(name, fn) {
  try   { fn(); console.log(`  ✓  ${name}`); passed++; }
  catch (e) { console.log(`  ✗  ${name}\n     → ${e.message}`); failed++; }
}
function assert(ok, msg) { if (!ok) throw new Error(msg || 'Assertion failed'); }

console.log('\n╔══════════════════════════════════════════╗');
console.log('║  SDLC Agents — Crypto Self-Test (15)     ║');
console.log('╚══════════════════════════════════════════╝\n');

// 1 ── config structure
test('config.json has all required fields', () => {
  const req = ['contentKey','buildSecretA','buildSecretB','magicBytes','hmacKey',
               'buildSecretB_fragment1','buildSecretB_fragment2',
               'buildSecretB_fragment3','buildSecretB_fragment4'];
  for (const f of req) assert(cfg[f] && cfg[f] !== 'REPLACE', `Missing: ${f}`);
});

// 2 ── key sizes
test('K_content is 32 bytes (AES-256)', () => assert(KC.length === 32, `Got ${KC.length}`));
test('Magic bytes are 4 bytes',          () => assert(MAGIC.length === 4, `Got ${MAGIC.length}`));
test('HMAC key is 32 bytes',             () => assert(HK.length === 32, `Got ${HK.length}`));

// 5 ── fragment reassembly
test('buildSecretB fragments reassemble correctly', () => {
  const b = Buffer.from(cfg.buildSecretB_fragment1,'hex').toString()
          + Buffer.from(cfg.buildSecretB_fragment2,'hex').toString()
          + Buffer.from(cfg.buildSecretB_fragment3,'hex').toString()
          + Buffer.from(cfg.buildSecretB_fragment4,'hex').toString();
  assert(b === cfg.buildSecretB, 'Fragments do not match buildSecretB — update _f1/_f2/_f3/_f4 in licenseManager.ts');
});

// 6 ── derivation determinism
test('Magic bytes are derived deterministically', () => {
  const exp = crypto.createHash('sha256').update('hdr' + cfg.buildSecretA).digest().slice(0,4).toString('hex');
  assert(exp === cfg.magicBytes, `Expected ${exp}, got ${cfg.magicBytes}`);
});
test('HMAC key is derived deterministically', () => {
  const exp = crypto.createHash('sha256').update('hmac' + cfg.buildSecretA + cfg.buildSecretB).digest().toString('hex');
  assert(exp === cfg.hmacKey, `Expected ${exp}`);
});

// 8 ── AES-256-GCM round-trip
test('AES-256-GCM encrypt → decrypt round-trip', () => {
  const pt    = Buffer.from(JSON.stringify({ hello: 'world', n: 42 }));
  const nonce = crypto.randomBytes(16);
  const ci    = crypto.createCipheriv('aes-256-gcm', KC, nonce);
  const enc   = Buffer.concat([ci.update(pt), ci.final()]);
  const tag   = ci.getAuthTag();
  const dc    = crypto.createDecipheriv('aes-256-gcm', KC, nonce);
  dc.setAuthTag(tag);
  assert(Buffer.concat([dc.update(enc), dc.final()]).equals(pt), 'Decrypted !== original');
});

// 9 ── HMAC detects tampering
test('HMAC detects any byte modification', () => {
  const data  = crypto.randomBytes(256);
  const h1    = crypto.createHmac('sha256', HK).update(data).digest();
  const tamp  = Buffer.from(data); tamp[100] ^= 0xFF;
  const h2    = crypto.createHmac('sha256', HK).update(tamp).digest();
  assert(!h1.equals(h2), 'HMAC unchanged after tampering');
});

// 10 ── PBKDF2 determinism
test('PBKDF2 produces same key for same inputs', () => {
  const salt = crypto.randomBytes(32);
  function k() {
    const p = crypto.createHash('sha256').update('CODE:MACHINE:' + cfg.buildSecretA + cfg.buildSecretB).digest();
    return crypto.pbkdf2Sync(p, salt, 250_000, 32, 'sha256');
  }
  assert(k().equals(k()), 'Different keys for same inputs');
});

// 11 ── machine binding
test('PBKDF2 produces different key for different machineId', () => {
  const salt = crypto.randomBytes(32);
  function k(mid) {
    const p = crypto.createHash('sha256').update(`CODE:${mid}:${cfg.buildSecretA}${cfg.buildSecretB}`).digest();
    return crypto.pbkdf2Sync(p, salt, 250_000, 32, 'sha256');
  }
  assert(!k('machineAAA').equals(k('machineBBB')), 'Same key for different machines — CRITICAL BUG');
});

// 12 ── content bin round-trip
test('Content bin encode/decode round-trip (dat-encoder ↔ licenseManager)', () => {
  const orig    = { packId:'test', agents:[{ agentId:'test-agent', body:'hello' }] };
  const payload = Buffer.from(JSON.stringify(orig));
  const nonce   = crypto.randomBytes(16);
  const ln      = 512; const noise1 = crypto.randomBytes(ln); const lnB = Buffer.alloc(4); lnB.writeUInt32BE(ln,0);
  const ci      = crypto.createCipheriv('aes-256-gcm', KC, nonce);
  const enc     = Buffer.concat([ci.update(payload), ci.final()]); const tag = ci.getAuthTag();
  const plB     = Buffer.alloc(4); plB.writeUInt32BE(enc.length,0);
  const tn      = 256; const noise2 = crypto.randomBytes(tn); const tnB = Buffer.alloc(4); tnB.writeUInt32BE(tn,0);
  const VERSION = Buffer.from([0x03,0x00]); const FTYPE = Buffer.alloc(2); FTYPE.writeUInt16BE(2,0);
  const covered = Buffer.concat([nonce,lnB,noise1,plB,enc,tag,tnB,noise2]);
  const hmac    = crypto.createHmac('sha256',HK).update(covered).digest();
  const bin     = Buffer.concat([MAGIC,VERSION,FTYPE,hmac,covered]);

  // Decode (content bin: nonce at offset 40)
  const st = bin.slice(8,40); const cv = bin.slice(40);
  assert(crypto.timingSafeEqual(st, crypto.createHmac('sha256',HK).update(cv).digest()), 'HMAC fail');
  const dn = bin.slice(40,56); let off=56;
  const rln=bin.readUInt32BE(off);off+=4+rln;
  const rpl=bin.readUInt32BE(off);off+=4;
  const rct=bin.slice(off,off+rpl);off+=rpl;
  const rtg=bin.slice(off,off+16);
  const dc=crypto.createDecipheriv('aes-256-gcm',KC,dn);dc.setAuthTag(rtg);
  const decoded=JSON.parse(Buffer.concat([dc.update(rct),dc.final()]).toString());
  assert(decoded.packId===orig.packId,'packId mismatch');
});

// 13 ── manifest (idx.bin) round-trip
test('Manifest encode/decode round-trip (license-gen ↔ licenseManager)', () => {
  const code='SDLC-TEST-0001-ABCD', machineId='test-machine-abc';
  const manifest={licenseId:'lic_t',customerName:'Test',productId:cfg.productId||'sdlc-agents',
    issuedAt:new Date().toISOString(),expiresAt:'2099-12-31T23:59:59Z',
    gracePeriodHours:24,allowedMachineIds:[machineId],
    features:{agentPacks:['core'],maxAgents:4},contentKey:cfg.contentKey,contentKeyVersion:1};

  const salt=crypto.randomBytes(32);
  function deriveK(c,m,s){
    const p=crypto.createHash('sha256').update(c+':'+m+':'+cfg.buildSecretA+cfg.buildSecretB).digest();
    return crypto.pbkdf2Sync(p,s,250_000,32,'sha256');
  }
  const key=deriveK(code,machineId,salt);
  const payload=Buffer.from(JSON.stringify(manifest));
  const nonce=crypto.randomBytes(16);
  const ln=512;const noise1=crypto.randomBytes(ln);const lnB=Buffer.alloc(4);lnB.writeUInt32BE(ln,0);
  const ci=crypto.createCipheriv('aes-256-gcm',key,nonce);
  const enc=Buffer.concat([ci.update(payload),ci.final()]);const tag=ci.getAuthTag();
  const plB=Buffer.alloc(4);plB.writeUInt32BE(enc.length,0);
  const tn=256;const noise2=crypto.randomBytes(tn);const tnB=Buffer.alloc(4);tnB.writeUInt32BE(tn,0);
  const VERSION=Buffer.from([0x03,0x00]);const FTYPE=Buffer.from([0x00,0x01]);
  // idx.bin: covered = salt(32)+nonce(16)+noise+payload+noise
  const covered=Buffer.concat([salt,nonce,lnB,noise1,plB,enc,tag,tnB,noise2]);
  const hmac=crypto.createHmac('sha256',HK).update(covered).digest();
  const bin=Buffer.concat([MAGIC,VERSION,FTYPE,hmac,covered]);

  // Decode (idx.bin: salt@40, nonce@72)
  assert(crypto.timingSafeEqual(bin.slice(8,40),crypto.createHmac('sha256',HK).update(bin.slice(40)).digest()),'HMAC fail');
  const dSalt=bin.slice(40,72);const dNonce=bin.slice(72,88);
  let off=88;const rln=bin.readUInt32BE(off);off+=4+rln;
  const rpl=bin.readUInt32BE(off);off+=4;
  const rct=bin.slice(off,off+rpl);off+=rpl;const rtg=bin.slice(off,off+16);
  const key2=deriveK(code,machineId,dSalt);
  assert(key.equals(key2),'Key re-derivation mismatch');
  const dc=crypto.createDecipheriv('aes-256-gcm',key2,dNonce);dc.setAuthTag(rtg);
  const decoded=JSON.parse(Buffer.concat([dc.update(rct),dc.final()]).toString());
  assert(decoded.licenseId===manifest.licenseId,'licenseId mismatch');
  assert(decoded.contentKey===manifest.contentKey,'contentKey mismatch');
});

// 14 ── wrong code fails
test('Wrong access code fails to decrypt manifest', () => {
  const salt=crypto.randomBytes(32);
  function k(code){
    const p=crypto.createHash('sha256').update(code+':machine:'+cfg.buildSecretA+cfg.buildSecretB).digest();
    return crypto.pbkdf2Sync(p,salt,250_000,32,'sha256');
  }
  const nonce=crypto.randomBytes(16);
  const ci=crypto.createCipheriv('aes-256-gcm',k('SDLC-GOOD-AAAA-BBBB'),nonce);
  const enc=Buffer.concat([ci.update(Buffer.from('secret')),ci.final()]);
  const tag=ci.getAuthTag();
  let threw=false;
  try{const dc=crypto.createDecipheriv('aes-256-gcm',k('SDLC-BAAD-CCCC-DDDD'),nonce);dc.setAuthTag(tag);Buffer.concat([dc.update(enc),dc.final()]);}
  catch{threw=true;}
  assert(threw,'Wrong key should throw on GCM auth tag check');
});

// 15 ── different machine fails
test('Different machineId cannot decrypt (machine binding verified)', () => {
  const salt=crypto.randomBytes(32);
  function k(m){
    const p=crypto.createHash('sha256').update('CODE:'+m+':'+cfg.buildSecretA+cfg.buildSecretB).digest();
    return crypto.pbkdf2Sync(p,salt,250_000,32,'sha256');
  }
  assert(!k('machine-A').equals(k('machine-B')),'Keys should differ');
  const nonce=crypto.randomBytes(16);
  const ci=crypto.createCipheriv('aes-256-gcm',k('machine-A'),nonce);
  const enc=Buffer.concat([ci.update(Buffer.from('content')),ci.final()]);
  const tag=ci.getAuthTag();
  let threw=false;
  try{const dc=crypto.createDecipheriv('aes-256-gcm',k('machine-B'),nonce);dc.setAuthTag(tag);Buffer.concat([dc.update(enc),dc.final()]);}
  catch{threw=true;}
  assert(threw,'Machine B should not decrypt machine A content');
});

// ── Results ───────────────────────────────────────────────────────────────────
console.log('');
if (failed === 0) {
  console.log(`Results: ${passed} passed, 0 failed\n`);
  console.log('╔══════════════════════════════════════════╗');
  console.log('║  ALL TESTS PASSED ✓                      ║');
  console.log('║  Crypto setup is correct.                ║');
  console.log('║  You can now run build.bat               ║');
  console.log('╚══════════════════════════════════════════╝\n');
} else {
  console.log(`Results: ${passed} passed, ${failed} FAILED\n`);
  console.log('╔══════════════════════════════════════════╗');
  console.log(`║  ${failed} TEST(S) FAILED ✗                       ║`);
  console.log('║  Most likely cause: _f1/_f2/_f3/_f4      ║');
  console.log('║  not updated in licenseManager.ts        ║');
  console.log('║  (must appear in BOTH locations)         ║');
  console.log('╚══════════════════════════════════════════╝\n');
  process.exit(1);
}
