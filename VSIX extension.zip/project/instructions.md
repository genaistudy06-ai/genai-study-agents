# Copilot Workspace Instructions v3.0
# Deployed to: .github/copilot-instructions.md
# Auto-injected into every agent and chat in this workspace.

---

## INITIALIZATION ORDER — Every agent, every invocation

```
1. .github/agent-memory/project.config.json       (project identity and tech stack)
2. .github/agent-standards/coding-standards.md    (your team coding standards)
3. .github/agent-standards/component-library.md   (your component library)
4. .github/agent-standards/api-standards.md       (your API conventions)
5. .github/agent-standards/security-standards.md  (your security requirements)
6. .github/agent-memory/global.memory.json        (workspace-wide learnings)
7. .github/agent-memory/{agent-name}.memory.json  (this agent's session history)
```

Missing file → use industry defaults and note the gap.
Present file → its rules OVERRIDE defaults. User standards always win.

---

## CUSTOM STANDARDS PROTOCOL

Create files in `.github/agent-standards/` and agents apply them automatically.

**`coding-standards.md`** — your team's coding rules in plain language.
Examples: "Use constructor injection only", "All API responses use { data, meta, errors } envelope",
"No abbreviations in variable names", "Branch naming: feat/JIRA-123-description"

**`component-library.md`** — your component library so agents never recreate what exists.
Include: package name, available components, import paths, prop interfaces, design tokens,
usage examples, anti-patterns. Agents will import from your library before writing new components.

**`api-standards.md`** — your API conventions.
Examples: response envelope format, pagination style, error format, versioning strategy.

**`security-standards.md`** — your org-specific security requirements.
Examples: "All auth via our internal AuthService", "Secrets via vault://path", "@PIIField annotation"

---

## FRAMEWORK DETECTION — Frontend agents read package.json

```
React/Next.js:    "react" or "next" in dependencies
Angular:          "@angular/core" in dependencies
Vue 3:            "vue" >= 3 in dependencies
State mgmt:       @reduxjs/toolkit | zustand | @ngrx/store | @tanstack/react-query
Forms:            react-hook-form | formik | @angular/forms
Validation:       zod | yup
Styling:          tailwindcss | *.module.css | styled-components | @emotion/react
Testing:          vitest | jest | playwright | @testing-library/react
```

Never mix paradigms. Detect first, then generate.

---

## SELF-LEARNING MEMORY SYSTEM

### Three mandatory phases — every invocation

**PHASE 1 — Load (silent, before first word of output)**
Read: project.config.json, all agent-standards files, global.memory.json, {agent}.memory.json
Apply everything found. The agent should behave as if it has worked on this project before.

**PHASE 2 — Generate**
Apply learned project conventions, user corrections, successful patterns.
Never repeat a pattern flagged in quality_escalations.
Check global.memory.json for security findings before generating any code.

**PHASE 3 — Write (end of every response)**
```json
{
  "session_timestamp": "ISO-8601",
  "task": "one-line description",
  "user_corrections": ["exact corrections received"],
  "patterns_that_worked": ["what produced good output"],
  "patterns_to_avoid": ["what user rejected and why"],
  "new_project_conventions": ["discovered this session"],
  "security_findings": ["any vulnerabilities found — also write to global"],
  "standards_applied": ["which user standards rules applied"],
  "component_library_used": ["which library components used"]
}
```

Write to `global.memory.json` anything that affects ALL agents:
security issues, architectural decisions, shared conventions, recurring bugs.

---

## SECURITY MANDATE — OWASP ASVS Level 2 (baseline for all code)

### OWASP Top 10 (2021) — Enforced in every code output

| Risk | Enforcement |
|------|-------------|
| A01 Broken Access Control | @PreAuthorize on every endpoint. Resource ownership check before returning data. |
| A02 Cryptographic Failures | TLS 1.2+. AES-256 at rest. BCrypt(12). No MD5/SHA1 for passwords. |
| A03 Injection | Parameterised queries only. Input validation at every boundary. Output encoding on render. |
| A04 Insecure Design | Threat model per feature. Defence in depth. Fail securely. Least privilege. |
| A05 Security Misconfiguration | No default creds. Security headers set. Debug disabled in prod. Errors safe for API response. |
| A06 Vulnerable Components | Snyk + OWASP Dependency Check in CI. No CVSS >= 7.0 in production. |
| A07 Auth Failures | JWT expiry enforced. Refresh token rotation. Rate limiting on /auth. MFA on admin. |
| A08 Data Integrity | Code signing. SBOM generated. Validate all deserialized input. |
| A09 Logging Failures | Structured logs with correlation ID. NO PII/secrets in logs. Audit every mutation. |
| A10 SSRF | URLs from config only — never from user-controlled input. Block internal IP ranges. |

### SANS CWE Top 25 — Developers prevent, reviewers verify

CWE-79 XSS | CWE-89 SQLi | CWE-20 Input Validation | CWE-78 OS Injection |
CWE-22 Path Traversal | CWE-352 CSRF | CWE-434 Unrestricted Upload |
CWE-502 Unsafe Deserialization | CWE-287 Broken Auth | CWE-798 Hardcoded Credentials |
CWE-862 Missing Authz | CWE-863 Incorrect Authz | CWE-200 Info Exposure |
CWE-611 XXE | CWE-918 SSRF | CWE-522 Weak Credentials | CWE-190 Integer Overflow

---

## UNIVERSAL ENGINEERING PRINCIPLES

### SOLID (applied as internalized craft, not a checklist)

**S — Single Responsibility:** One class, one reason to change.
Controllers route. Services contain business logic. Repositories query. Never mix.

**O — Open/Closed:** Add features via new implementations of interfaces, never by modifying working code.

**L — Liskov Substitution:** Every implementation of an interface must honour the full contract.
A test mock must behave identically to the real implementation — just without I/O.

**I — Interface Segregation:** Narrow interfaces over fat ones.
Clients depend only on methods they use.

**D — Dependency Inversion:** Depend on abstractions, not concretions.
Inject via constructor — never `new()` inside business logic.

### Clean Architecture — Dependency rule is absolute

```
Domain (innermost)     → no framework imports
Application Use Cases  → imports domain only
Infrastructure         → implements application interfaces
Interface (controllers, consumers) → calls application use cases only
```

### 12-Factor App

Config in env vars. Stateless processes. Fast startup and graceful shutdown.
Logs as event streams. Dev/prod parity. Explicit dependency declarations.

### Code Quality Rules

```
Function length:      max 20 lines
Class length:         max 300 lines
Parameters:           max 4 (use parameter object beyond 4)
Nesting depth:        max 3 levels
Cyclomatic complexity: max 10, target <= 5
Magic numbers:        zero tolerance — named constants only
Abbreviations:        none (except HTTP, URL, ID, DTO, API, SQL, UI)
```

---

## QUALITY GATES — Single authoritative source

| Gate | Tool | Threshold | On Fail |
|------|------|-----------|---------|
| Line coverage | JaCoCo / Istanbul | >= 80% | Block CI |
| Branch coverage | JaCoCo / Istanbul | >= 80% | Block CI |
| Mutation score | PITest / Stryker | >= 70% | Warn PR |
| Code smells | SonarQube | A rating | Block CI |
| Security hotspots | SonarQube | 0 unreviewed | Block CI |
| SAST | CodeQL | 0 new CRIT/HIGH | Block CI |
| Dependency CVEs | Snyk + OWASP DC | 0 CVSS >= 7.0 | Block CI |
| Secret scan | TruffleHog + GitLeaks | 0 verified findings | Block all |
| Container CVEs | Trivy | 0 CRITICAL | Block deploy |
| Bundle size (FE) | Bundlesize | Per budget in config | Warn PR |
| Lighthouse perf | Lighthouse CI | >= 90 | Warn PR |
| WCAG accessibility | axe-core | 0 violations | Block UI PR |
| API contract | Pact broker | 0 broken contracts | Block CI |

---

## PROACTIVE SIGNALS — Every agent emits these

At the end of every response, include a `## Proactive Signals` section listing
issues noticed that were NOT part of the original request. This is what a senior
engineer actually does — they answer your question AND flag what else they noticed.

Examples:
- "Noticed: This endpoint has no rate limiting — OWASP A07 risk"
- "Noticed: Kafka consumer has no dead letter queue — messages will be lost on failure"
- "Noticed: React component re-fetches on every render — missing dependency array"
- "Noticed: Your component library has a Modal — PaymentModal.tsx is not using it"

---

## OUTPUT FORMAT — Every code response must include

1. **Standards applied** — which user standards rules were used
2. **Component library** — which library components were used (frontend only)
3. **Complete implementation** — zero TODOs, zero placeholders
4. **Tests** — all required scenarios implemented, not stubs
5. **Security checklist** — OWASP items verified
6. **Flyway / migration** — if schema changed
7. **Audit log** — if state-changing operation
8. **Memory write** — what this session taught the agent
9. **Handoff block** — next agent's inputs (pipeline mode only)
10. **Proactive signals** — issues spotted outside the request

---

## AGENT INVOCATION MODES

**Solo** — any agent independently without a chain:
`@security-architect review AuthService.java`
`@senior-frontend-engineer implement PaymentForm`

**Partial chain** — feature or domain specific:
```
Feature:  @enterprise-architect → @solution-architect → @senior-backend-engineer → @qa-automation-engineer → @code-reviewer
Hotfix:   @security-architect → @senior-backend-engineer → @code-reviewer → @devops-engineer
Release:  @performance-engineer → @security-architect → @architecture-review-board → @devops-engineer
```

**Full pipeline:**
`@sdlc-orchestrator start project "ProjectName"`
Routes automatically through all agents in sequence.

**Parallel:**
`@sdlc-orchestrator parallel: ServiceA + ServiceB + ServiceC`
Each service runs its own agent chain. Merge at code-reviewer and ARB.
