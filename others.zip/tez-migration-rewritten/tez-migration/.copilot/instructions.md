# Global Copilot Instructions — Tez-to-Spark Migration

## Purpose
Drive a safe, restartable Tez-to-Spark migration using the repository as the sole source of truth.
All agents inherit the rules in this file — they are not repeated in individual agent files.

---

## Working Model
- Discover all evidence directly from the repository. Never require a separate input folder.
- Persist all artifacts under `migration-artifacts/runs/{run_id}/`.
- Never modify Java business-logic classes (processors, combiners, partitioners, helpers) unless the user explicitly confirms a code change after review.
- Every claim must point to repository evidence or an upstream artifact. Never fabricate metrics or config values. Mark inferred values explicitly.

## Run ID Format
`TEZ2SPK-YYYYMMDD-HHMM-ABCD`  
Generate one at pipeline start if the user has not supplied one.

## Artifact Layout
```
migration-artifacts/
  runs/
    {run_id}/
      audit.json
      pre-benchmark.json
      report-initial.json
      sparkconf.json
      interop-plan.json
      spark-plan.json
      optimized-spark-plan.json
      plan-diff.json
      execution-report.json
      data-contract-results.json
      benchmark-results.json
      review.json
      report-final.json
      failures.log
```

## Canonical Agent Pipeline
| # | Agent file | Output artifact |
|---|---|---|
| 0 | audit-agent.md | audit.json |
| 1 | pre-conversion-benchmark-agent.md | pre-benchmark.json |
| 2 | report-agent.md | report-initial.json |
| 3 | config-agent.md | sparkconf.json |
| 4 | java-interop-agent.md | interop-plan.json |
| 5 | conversion-agent.md | spark-plan.json |
| 6 | optimization-agent.md | optimized-spark-plan.json |
| 7 | plan-diff-agent.md | plan-diff.json |
| 8 | execution-agent.md | execution-report.json |
| 9 | data-contract-agent.md | data-contract-results.json |
| 10 | benchmark-agent.md | benchmark-results.json |
| 11 | review-agent.md | review.json |
| 12 | report-agent.md | report-final.json |

## Approval Gates (pipeline pauses here for human GO / NO-GO)
- After Phase 2 (report-initial.json): GO / NO-GO before migration build begins.
- After Phase 11 (review.json): Cutover approval before final report.

---

## Rules All Agents Must Follow

### Repository Discovery
Before any analysis:
1. Scan the repo for the minimum file set relevant to this agent.
2. Record each discovered file: `path`, `file_type`, `reason`, `evidence_excerpt`.
3. If required evidence cannot be found, emit `NEEDS_REVIEW` and stop (do not proceed on guesses).

Priority targets:
- `tez-site.xml`, `hive-site.xml`, `core-site.xml`, `mapred-site.xml`
- DAG construction code, `org.apache.tez` imports, `Processor`, `Vertex`, `Edge`, `DAG`, `TezConfiguration`
- Custom UDF, UDAF, SerDe, partitioner, combiner classes
- `pom.xml`, `build.gradle`, dependency lock files
- Shell scripts, Airflow, Oozie, scheduler configs
- SQL files, Hive scripts, ETL jobs
- YARN, ATS, Tez, Spark, and job logs
- Test baselines and golden output fixtures

### Handoff Verification
Before consuming any upstream artifact:
- Confirm file exists and is non-empty.
- Confirm `run_id` matches.
- Confirm required fields are present and free of placeholder values.
- Confirm upstream `status` is `SUCCESS`.
- On failure → emit `INVALID_HANDOFF`, state `rollback_to`, and stop.

### Resume and Rollback
- If the target output artifact already exists and is valid → set `resume_mode: true` and reuse it.
- If it exists but is corrupt or incomplete → regenerate.
- Always include `rollback_to` in output.

### Standard Output Contract (every agent)
```json
{
  "run_id": "TEZ2SPK-YYYYMMDD-HHMM-ABCD",
  "generated_by": "<agent-name>",
  "status": "SUCCESS | FAILED | NEEDS_REVIEW | BLOCKED",
  "validation_passed": true,
  "resume_mode": false,
  "repo_scan_paths": [],
  "artifacts_consumed": [],
  "artifacts_produced": [],
  "blocking_issues": [],
  "warnings": [],
  "confidence_score": 0.0,
  "rollback_to": "<agent-name>",
  "next_agent": "<agent-name>"
}
```

### Failure Logging
Append to `migration-artifacts/runs/{run_id}/failures.log`:
```
[TIMESTAMP] AGENT={agent} STATE={state} FAILURE={type} REASON={exact_reason} ROLLBACK_TO={agent}
```

### Hard Stops — Do not continue if:
- No credible Tez evidence in the repo
- Upstream artifact validation fails
- Critical data mismatch found
- Rollback plan is missing
- Performance regression exceeds agreed threshold

---

## How to Start
Invoke the master agent with a single prompt:

```
#file:copilot-agents/master-agent.md
Start Tez-to-Spark migration pipeline.
```

The master agent generates the run ID, drives the pipeline, pauses at approval gates, and emits the exact next prompt after each phase.
