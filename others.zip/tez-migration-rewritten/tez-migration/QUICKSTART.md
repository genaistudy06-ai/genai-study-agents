# QUICKSTART — Tez-to-Spark Migration

## Setup (one-time)
1. Open the source repository in VS Code.
2. Ensure `.copilot/instructions.md` and all files in `copilot-agents/` are present.
3. Create the output root: `migration-artifacts/runs/`

---

## Start a full migration run — one prompt

Paste this into GitHub Copilot Chat:

```
#file:copilot-agents/master-agent.md
Start Tez-to-Spark migration pipeline.
```

The master agent will:
- Generate a run ID automatically
- Run Phases 0–2 (audit → benchmark → initial report)
- **Pause and ask for GO / NO-GO**
- On GO, run Phases 3–11 (config → conversion → execution → validation → review)
- **Pause and ask for cutover approval**
- On FINALIZE, produce the final report

You type **3 prompts total** for a full pipeline run:
1. `#file:copilot-agents/master-agent.md` → Start
2. `GO {run_id}` → Approve migration build
3. `FINALIZE {run_id}` → Approve final report

---

## Supply your own run ID (optional)

```
#file:copilot-agents/master-agent.md
Start Tez-to-Spark migration pipeline. Run ID: TEZ2SPK-20260414-1030-A1B2
```

---

## Run a single agent standalone

Each agent is self-contained and will emit the next prompt at completion:

```
#file:copilot-agents/audit-agent.md
Run ID: TEZ2SPK-20260414-1030-A1B2. Run this agent.
```

After completion, copy the exact prompt the agent emits and paste it to continue.

---

## Resume an interrupted run

```
#file:copilot-agents/master-agent.md
Resume migration pipeline. Run ID: TEZ2SPK-20260414-1030-A1B2
```

The master agent will check which artifacts exist, validate them, and continue from the next incomplete phase.

---

## Retry a failed agent

```
#file:copilot-agents/{failed-agent}.md
Run ID: {run_id}. Retry this agent.
```

---

## Output location
All artifacts are written to:
```
migration-artifacts/runs/{run_id}/
```

See `.copilot/instructions.md` for the full artifact layout, agent pipeline table, and global rules.

---

## Best first test
Start with one bounded Tez workflow:
- One DAG or small DAG family
- Limited custom Java
- Known output schema
- Stable test fixtures or golden outputs if available
