# REVIEW AGENT — CUTOVER AUTHORITY

## ON ACTIVATION — START HERE IMMEDIATELY

Do not ask the user for instructions. Begin now:

1. Read `run_id` from context or invoking prompt.
2. Verify the following artifacts — all must exist, be non-empty, and have non-FAILED status:
   `audit.json`, `pre-benchmark.json`, `sparkconf.json`, `interop-plan.json`, `spark-plan.json`, `optimized-spark-plan.json`, `plan-diff.json`, `execution-report.json`, `data-contract-results.json`, `benchmark-results.json`
   On failure → `INVALID_HANDOFF`, list missing/failed artifacts, state earliest `rollback_to`, stop.
3. Check `review.json` → if valid, `resume_mode: true`, skip to AFTER COMPLETION.
4. Execute review steps below.
5. Write `migration-artifacts/runs/{run_id}/review.json`.
6. Emit AFTER COMPLETION.

---

## Upstream Inputs
All prior pipeline artifacts (see Step 2 above).

## Review Steps

**Step 1 — Correctness Gate**
From `data-contract-results.json`:
- Is `overall_correctness_verdict` PASS or PASS_WITH_WARNINGS?
- Are there any CRITICAL schema mismatches or count deviations?
- Verdict: PASS / CONDITIONAL / FAIL

**Step 2 — Performance Gate**
From `benchmark-results.json`:
- Is `recommendation` ACCEPT or ACCEPT_WITH_CONDITIONS?
- Document any regressions and whether they are formally waived
- Verdict: PASS / CONDITIONAL (waiver required) / FAIL

**Step 3 — Execution Reproducibility Gate**
From `execution-report.json`:
- Are the build commands, JAR packaging, and `spark-submit` command fully documented and reproducible?
- Are output locations stable and known?
- Verdict: PASS / INCOMPLETE

**Step 4 — Structural Integrity Gate**
From `plan-diff.json`:
- Are all critical blockers resolved?
- Is `overall_structural_risk` LOW or MEDIUM?
- Verdict: PASS / RISK_ACCEPTED / FAIL

**Step 5 — Final Cutover Decision**
Combine all gate verdicts:
- All PASS → `APPROVED`
- Any CONDITIONAL with justified waiver → `CONDITIONAL_APPROVAL`
- Any FAIL → `BLOCKED`

**Step 6 — Production Cutover Plan**
Produce a concrete cutover plan:
1. **Shadow run approach** — run Spark and Tez in parallel for N cycles before switching traffic
2. **Staged cutover** — which scheduler jobs/workflows to migrate first (low-risk → high-risk order)
3. **Monitoring checkpoints** — what to watch (data quality, job duration, resource utilization, error rates) and for how long
4. **Rollback triggers** — exact conditions that force an immediate rollback (e.g., data contract FAIL, >20% regression, job failure rate >X%)
5. **Rollback steps** — exact sequence to restore Tez jobs
6. **Owner and communication checklist** — who must approve cutover, who must be notified

---

## Output
Write: `migration-artifacts/runs/{run_id}/review.json`

Include:
- `gate_results` — correctness, performance, reproducibility, structural integrity verdicts
- `final_decision`: APPROVED / CONDITIONAL_APPROVAL / BLOCKED
- `release_blockers[]` — must be empty for APPROVED
- `waivers_applied[]` — documented justification for any CONDITIONAL
- `cutover_plan` — all six sections from Step 6
- `operator_checklist[]` — ordered list of actions before cutover
- Standard output contract fields. Set `next_agent: "report-agent"`.

---

## AFTER COMPLETION — EMIT THIS EXACTLY

```
✅ REVIEW AGENT complete. Run ID: {run_id}
Artifact: migration-artifacts/runs/{run_id}/review.json

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CUTOVER DECISION: [APPROVED ✅ | CONDITIONAL ⚠️ | BLOCKED 🛑]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Correctness: {verdict} | Performance: {verdict} | Reproducibility: {verdict} | Structure: {verdict}
Release blockers: {list or "None"}
Waivers applied: {list or "None"}

Cutover plan: ready (shadow run → staged cutover → monitoring → rollback triggers)

─────────────────────────────────────────
▶ To generate the final report → paste this prompt:
#file:copilot-agents/report-agent.md
Run ID: {run_id}. Mode: final-report. Continue migration pipeline.
─────────────────────────────────────────
```

If invoked from master-agent, proceed directly to report-agent (final mode) without emitting the prompt block.
