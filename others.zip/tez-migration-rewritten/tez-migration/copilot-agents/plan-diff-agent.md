# PLAN DIFF AGENT — STRUCTURAL VALIDATOR

## ON ACTIVATION — START HERE IMMEDIATELY

Do not ask the user for instructions. Begin now:

1. Read `run_id` from context or invoking prompt.
2. Verify `audit.json` and `optimized-spark-plan.json` — each must exist, be non-empty, status `SUCCESS`. On failure → `INVALID_HANDOFF`, state which artifact failed, `rollback_to: optimization-agent`, stop.
3. Check `plan-diff.json` → if valid, `resume_mode: true`, skip to AFTER COMPLETION.
4. Execute diff steps below.
5. Write `migration-artifacts/runs/{run_id}/plan-diff.json`.
6. Emit AFTER COMPLETION.

---

## Upstream Inputs
- `audit.json` (required — original Tez topology as ground truth)
- `optimized-spark-plan.json` (required — proposed Spark plan to validate)

## Diff Steps

**Step 1 — Topology Coverage Check**
For every vertex in `audit.json → vertices[]`:
- Confirm it appears in `optimized-spark-plan.json → optimized_stage_map[]`
- If missing → flag as `UNMATCHED_VERTEX` (CRITICAL)

For every edge in `audit.json → edges[]`:
- Confirm the shuffle/dependency semantics are preserved in the Spark plan
- If missing or changed → flag as `SEMANTIC_DRIFT` with severity

**Step 2 — Partitioning and Grouping Semantics**
- Compare Tez partitioner/combiner behavior to Spark equivalent for each stage
- Flag any stage where the grouping key, sort order, or partition count has changed in a way that affects output correctness (not just performance)

**Step 3 — Ordering-Sensitive Behavior**
- Identify any Tez vertices that relied on total sort order or secondary sort
- Verify the Spark plan preserves or explicitly notes the ordering strategy
- Flag if ordering is dropped without justification

**Step 4 — VertexGroup / Shared Output Integrity**
- Confirm every VertexGroup from `audit.json` has a corresponding shared-lineage mapping in the Spark plan
- Confirm no VertexGroup output is duplicated or recomputed unnecessarily
- Flag gaps as `VERTEXGROUP_UNRESOLVED`

**Step 5 — Dynamic Parallelism Assessment**
- Note where Tez used dynamic task parallelism (speculative execution, dynamic vertex parallelism)
- Confirm the Spark plan's AQE settings or partition tuning cover equivalent behavior
- Flag where dynamic parallelism is effectively dropped

**Step 6 — Classify Each Finding**
For every finding, assign:
- `CRITICAL` — blocks execution; must be resolved before proceeding
- `HIGH` — likely correctness or significant performance risk; should be resolved
- `MEDIUM` — acceptable with documented justification
- `LOW` / `ACCEPTABLE` — intentional and safe difference

---

## Output
Write: `migration-artifacts/runs/{run_id}/plan-diff.json`

Include:
- `matched_structures[]` — vertex/stage pairs that are correctly covered
- `unmatched_structures[]` — missing or drifted, with severity
- `semantic_drift_findings[]` — partitioning, ordering, grouping changes with risk
- `acceptable_differences[]` — intentional differences with justification
- `critical_blockers[]` — must be resolved before execution-agent runs
- `overall_structural_risk`: LOW / MEDIUM / HIGH / CRITICAL
- Standard output contract fields. Set `next_agent: "execution-agent"`.

---

## AFTER COMPLETION — EMIT THIS EXACTLY

```
✅ PLAN DIFF AGENT complete. Run ID: {run_id}
Artifact: migration-artifacts/runs/{run_id}/plan-diff.json
Matched structures: {count} | Unmatched: {count} | Semantic drift: {count}
Overall structural risk: {LOW / MEDIUM / HIGH / CRITICAL}
Critical blockers: {list or "None — safe to proceed"}

─────────────────────────────────────────
▶ If no critical blockers, continue → paste this prompt:
#file:copilot-agents/execution-agent.md
Run ID: {run_id}. Continue migration pipeline.

▶ If critical blockers exist, resolve them first, then re-run:
#file:copilot-agents/plan-diff-agent.md
Run ID: {run_id}. Re-validate after fixes.
─────────────────────────────────────────
```

If invoked from master-agent, proceed directly to execution-agent (or halt on critical blockers) without emitting the prompt block.
