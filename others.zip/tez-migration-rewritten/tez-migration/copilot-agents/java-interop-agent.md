# JAVA INTEROP AGENT — BUSINESS LOGIC PRESERVER

## ON ACTIVATION — START HERE IMMEDIATELY

Do not ask the user for instructions. Begin now:

1. Read `run_id` from context or invoking prompt.
2. Verify `audit.json` — exists, non-empty, status `SUCCESS`. On failure → `INVALID_HANDOFF`, `rollback_to: audit-agent`, stop.
3. Check `interop-plan.json` → if valid, `resume_mode: true`, skip to AFTER COMPLETION.
4. Execute analysis steps below.
5. Write `migration-artifacts/runs/{run_id}/interop-plan.json`.
6. Emit AFTER COMPLETION.

---

## Upstream Inputs
- `audit.json` (required — provides `java_classes[]` inventory)

## Analysis Steps

**Step 1 — Classify Every Java Class**
From `audit.json → java_classes[]`, classify each class:
- Type: `Processor`, `Combiner`, `Partitioner`, `UDF`, `SerDe`, `Helper`, `Other`
- Callable from Spark as-is? (YES / WRAPPER_NEEDED / REFACTOR_NEEDED)
- Serialization risk: (NONE / LOW / HIGH — annotate why)
- Captured state risk for lambdas/inner classes

**Step 2 — Inner and Anonymous Class Handling**
For every anonymous class, inner class, lambda, or nested class found:
- Assess callability from Spark executor context
- Assess whether outer state capture causes serialization failure
- Determine: needs wrapper, needs adapter, or is safe as-is

**Step 3 — Stateful and High-Risk Classes**
Flag as HIGH RISK if the class:
- Has mutable shared state
- Requires a non-serializable outer context
- Uses reflection without test coverage
- Holds references to Tez-specific context objects that have no Spark equivalent

For each high-risk class: describe the exact risk, the mitigation strategy, and whether a safe Spark-compatible wrapper can be written without altering business logic.

**Step 4 — Classpath and Packaging**
- Identify which JARs need to be distributed to Spark executors
- Note any transitive dependency conflicts with Spark's classpath
- Propose packaging strategy (fat JAR, `--jars`, `--packages`, shade rules)

---

## Output
Write: `migration-artifacts/runs/{run_id}/interop-plan.json`

Include:
- `callable_class_inventory[]` — each class with type, callability, risks, wrapper strategy
- `high_risk_classes[]` — risk description, mitigation, safe wrapper feasibility
- `inner_anonymous_class_findings[]`
- `classpath_packaging_notes`
- `wrapper_stubs_required[]` — list of wrappers that must be written before conversion proceeds
- Standard output contract fields. Set `next_agent: "conversion-agent"`.

---

## AFTER COMPLETION — EMIT THIS EXACTLY

```
✅ JAVA INTEROP AGENT complete. Run ID: {run_id}
Artifact: migration-artifacts/runs/{run_id}/interop-plan.json
Classes inventoried: {count} | High risk: {count} | Wrappers needed: {count}
High-risk summary: {one-line per high-risk class or "None"}
Wrapper stubs required before conversion: {list or "None"}

─────────────────────────────────────────
▶ To continue → paste this prompt:
#file:copilot-agents/conversion-agent.md
Run ID: {run_id}. Continue migration pipeline.
─────────────────────────────────────────
```

If invoked from master-agent, proceed directly to conversion-agent without emitting the prompt block.
