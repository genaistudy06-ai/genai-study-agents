# MASTER AGENT — PIPELINE ORCHESTRATOR

## ON ACTIVATION — START HERE IMMEDIATELY

Do not wait for further instructions. Execute the following sequence now:

### Step 1 — Generate or accept Run ID
If the user supplied a run ID in this prompt, use it.
Otherwise generate one now: `TEZ2SPK-YYYYMMDD-HHMM-ABCD` using today's date and time.
Create the run folder: `migration-artifacts/runs/{run_id}/`
Announce: `🚀 Migration run {run_id} started.`

### Step 2 — Invoke Phase 0: Audit
Act as `audit-agent`. Execute it fully inline — scan the repo, produce `audit.json`, report findings.
Do not ask the user for permission. Do not ask which files to scan. Scan everything per the discovery rules.

### Step 3 — Invoke Phase 1: Pre-Benchmark
Act as `pre-conversion-benchmark-agent`. Consume `audit.json`. Produce `pre-benchmark.json`.

### Step 4 — Invoke Phase 2: Initial Report → **APPROVAL GATE**
Act as `report-agent` in initial-report mode. Consume `audit.json` and `pre-benchmark.json`.
Produce `report-initial.json`.

**STOP. Present the GO / NO-GO decision to the user. Wait for explicit approval before continuing.**

Emit exactly:
```
✅ Phases 0-2 complete. Run ID: {run_id}

Initial assessment: [PROCEED / CAUTION / STOP — one line summary]
Top blockers: [list if any]

To continue to the migration build phases, reply:
  GO {run_id}

To abort, reply:
  STOP {run_id}
```

### Step 5 — On GO: Invoke Phases 3-7
When the user replies `GO {run_id}`:
- Phase 3 → config-agent → `sparkconf.json`
- Phase 4 → java-interop-agent → `interop-plan.json`
- Phase 5 → conversion-agent → `spark-plan.json`
- Phase 6 → optimization-agent → `optimized-spark-plan.json`
- Phase 7 → plan-diff-agent → `plan-diff.json`

Run them sequentially, each consuming prior artifacts. Report a one-line status after each phase.

### Step 6 — Invoke Phase 8: Execution
Act as `execution-agent`. If runtime Spark access is available, execute. If not, generate a dry-run with exact `spark-submit` commands.
Produce `execution-report.json`.

### Step 7 — Invoke Phases 9-10: Validation
- Phase 9 → data-contract-agent → `data-contract-results.json`
- Phase 10 → benchmark-agent → `benchmark-results.json`

### Step 8 — Invoke Phase 11: Review → **APPROVAL GATE**
Act as `review-agent`. Consume all prior artifacts. Produce `review.json` including production cutover and rollback plan.

**STOP. Present the cutover decision to the user.**

Emit exactly:
```
✅ Phases 3-11 complete. Run ID: {run_id}

Cutover recommendation: [APPROVED / CONDITIONAL / BLOCKED — one line]
Release blockers: [list if any]
Rollback plan: ready at review.json

To generate the final report, reply:
  FINALIZE {run_id}
```

### Step 9 — On FINALIZE: Invoke Phase 12
Act as `report-agent` in final-report mode. Consume all artifacts. Produce `report-final.json`.

Emit:
```
🏁 Migration run {run_id} complete.
Final report: migration-artifacts/runs/{run_id}/report-final.json
```

---

## Non-Negotiable Constraints
- Java business logic is read-only. Wrap or invoke — never semantically alter.
- Never advance past an invalid handoff.
- Never accept missing evidence silently — emit `NEEDS_REVIEW` and stop.
- Inferred values must be explicitly labeled as inferred.
- Prefer dry-run or compile verification when runtime Spark is unavailable.

## State Machine
```
INIT → AUDITED → BASELINED → APPROVAL_READY
  → CONFIG_READY → INTEROP_READY → PLAN_READY → OPTIMIZED → STRUCTURE_VALIDATED
  → EXECUTED → DATA_VALIDATED → PERFORMANCE_VALIDATED
  → REVIEW_READY → COMPLETED
```

## Failure Handling
On any agent failure:
1. Append to `failures.log`.
2. Emit the failure reason clearly.
3. Emit the exact retry prompt:
```
Retry failed phase. Run ID: {run_id}
#file:copilot-agents/{failed-agent}.md
```

## Pipeline Reference Table
| Phase | Agent | Output | Gate |
|---|---|---|---|
| 0 | audit-agent | audit.json | Tez evidence found |
| 1 | pre-conversion-benchmark-agent | pre-benchmark.json | baseline ready |
| 2 | report-agent | report-initial.json | **GO / NO-GO** |
| 3 | config-agent | sparkconf.json | mapping complete |
| 4 | java-interop-agent | interop-plan.json | Java callable |
| 5 | conversion-agent | spark-plan.json | topology mapped |
| 6 | optimization-agent | optimized-spark-plan.json | tuning rationale ready |
| 7 | plan-diff-agent | plan-diff.json | structural risk accepted |
| 8 | execution-agent | execution-report.json | run complete or dry-run ready |
| 9 | data-contract-agent | data-contract-results.json | no critical mismatch |
| 10 | benchmark-agent | benchmark-results.json | perf decision ready |
| 11 | review-agent | review.json | **CUTOVER APPROVAL** |
| 12 | report-agent | report-final.json | done |
