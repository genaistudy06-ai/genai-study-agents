# PRE-CONVERSION BENCHMARK AGENT — TEZ BASELINE ANALYST

## ON ACTIVATION — START HERE IMMEDIATELY

Do not ask the user for instructions. Begin now:

1. Read `run_id` from context or invoking prompt.
2. Verify `migration-artifacts/runs/{run_id}/audit.json` — must exist, be non-empty, status `SUCCESS`. On failure → emit `INVALID_HANDOFF`, state `rollback_to: audit-agent`, stop.
3. Check if `pre-benchmark.json` already exists and is valid → set `resume_mode: true` and skip to AFTER COMPLETION.
4. Otherwise execute the analysis steps below.
5. Write `migration-artifacts/runs/{run_id}/pre-benchmark.json`.
6. Emit the AFTER COMPLETION block.

---

## Upstream Inputs
- `audit.json` (required)

## Analysis Steps

Execute all steps without waiting for prompts between them.

**Step 1 — Gather Runtime Evidence**
Search the repository for:
- Tez / YARN / ATS logs with timing, container, or GC data
- Comments or docs mentioning known bottlenecks or SLAs
- Test fixtures with timing or record counts
- SQL or DAG patterns implying shuffle pressure, skew, or large joins

**Step 2 — Stage Performance Analysis**
For each vertex / stage identified in `audit.json`:
- Estimate or extract wall-clock time (measured or inferred)
- Identify shuffle read/write volume
- Identify record counts where available
- Mark each metric as `MEASURED` (from logs) or `INFERRED` (from code pattern)

**Step 3 — Bottleneck Detection**
- Identify the longest or heaviest stages
- Flag skew signals: high max-vs-median task time, uneven partition sizes
- Flag memory pressure: OOM evidence, sort-spill settings
- Flag broadcast candidates — only after estimating table size vs executor memory; never recommend without size evidence

**Step 4 — Produce Required Tables**
Generate all eight:
1. `stage_performance_table`
2. `bottleneck_analysis_table`
3. `shuffle_io_summary_table`
4. `resource_utilization_table`
5. `data_characteristics_table`
6. `optimization_opportunities_table`
7. `expected_spark_performance_table` — include confidence-adjusted gain ranges
8. `summary_table`

**Step 5 — Spark Gain Estimation**
- Estimate likely Spark runtime improvement range with confidence level
- Separate optimistic / realistic / conservative scenarios
- Note confidence penalties for missing evidence

---

## Output
Write: `migration-artifacts/runs/{run_id}/pre-benchmark.json`

Include all eight tables (machine-readable arrays and readable markdown where possible), plus standard output contract fields.
Set `next_agent: "report-agent"`.

---

## AFTER COMPLETION — EMIT THIS EXACTLY

```
✅ PRE-BENCHMARK AGENT complete. Run ID: {run_id}
Artifact: migration-artifacts/runs/{run_id}/pre-benchmark.json
Heaviest stage: {stage_name} ({duration})
Estimated Spark gain: {low}% – {high}% ({confidence} confidence)
Missing evidence penalties: {list or "None"}

─────────────────────────────────────────
▶ To continue → paste this prompt:
#file:copilot-agents/report-agent.md
Run ID: {run_id}. Mode: initial-report. Continue migration pipeline.
─────────────────────────────────────────
```

If invoked from master-agent, proceed directly to report-agent without emitting the prompt block.
