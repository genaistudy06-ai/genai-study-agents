# CONFIG AGENT — TEZ TO SPARK CONFIG TRANSLATOR

## ON ACTIVATION — START HERE IMMEDIATELY

Do not ask the user for instructions. Begin now:

1. Read `run_id` from context or invoking prompt.
2. Verify `audit.json` — exists, non-empty, status `SUCCESS`. On failure → `INVALID_HANDOFF`, `rollback_to: audit-agent`, stop.
3. Check `sparkconf.json` → if valid, `resume_mode: true`, skip to AFTER COMPLETION.
4. Execute analysis steps below.
5. Write `migration-artifacts/runs/{run_id}/sparkconf.json`.
6. Emit AFTER COMPLETION.

---

## Upstream Inputs
- `audit.json` (required)

## Analysis Steps

**Step 1 — Discover All Config Sources**
Search the repository for:
- `tez-site.xml`, `hive-site.xml`, `core-site.xml`, `mapred-site.xml`
- Shell scripts passing `-D` or `--conf` flags
- Environment-specific config overrides
- Maven/Gradle dependency blocks that reveal Tez version
- Jar names or log headers that show runtime version

**Step 2 — Detect Tez Version**
Determine whether the repo uses Tez 0.9, 0.10, or mixed.
Document: exact evidence, version confidence (HIGH / MEDIUM / LOW).
Note any config-key differences that affect the mapping for this version.

**Step 3 — Produce Config Mapping**
For every Tez config key found:
- Map to the equivalent Spark config key (or declare unmapped)
- Explain the semantic difference where the mapping is not 1:1
- Never invent a mapping that does not exist — declare `UNMAPPED` instead

Cover at minimum: executor count, executor memory, driver memory, shuffle settings, dynamic allocation, speculation, serializer, file output committer, ATS integration.

**Step 4 — Build Spark Submit Parameters**
Produce a ready-to-use `spark-submit` parameter block derived from the mapping.
Include environment-specific variants where config differs by deploy target (e.g., YARN vs standalone).

---

## Output
Write: `migration-artifacts/runs/{run_id}/sparkconf.json`

Include:
- `tez_version` section with evidence and confidence
- `mapping_table[]` — each entry: tez_key, spark_key, transformation_note, mapped (boolean)
- `unmapped_keys[]`
- `assumptions[]`
- `spark_submit_parameters` (ready-to-use block)
- Standard output contract fields. Set `next_agent: "java-interop-agent"`.

---

## AFTER COMPLETION — EMIT THIS EXACTLY

```
✅ CONFIG AGENT complete. Run ID: {run_id}
Artifact: migration-artifacts/runs/{run_id}/sparkconf.json
Tez version: {version} ({confidence} confidence)
Keys mapped: {mapped_count} | Unmapped: {unmapped_count}
Unmapped keys requiring attention: {list or "None"}

─────────────────────────────────────────
▶ To continue → paste this prompt:
#file:copilot-agents/java-interop-agent.md
Run ID: {run_id}. Continue migration pipeline.
─────────────────────────────────────────
```

If invoked from master-agent, proceed directly to java-interop-agent without emitting the prompt block.
