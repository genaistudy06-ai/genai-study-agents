# EXECUTION AGENT — RUNNER OR DRY-RUN VERIFIER

## ON ACTIVATION — START HERE IMMEDIATELY

Do not ask the user for instructions. Begin now:

1. Read `run_id` from context or invoking prompt.
2. Verify `optimized-spark-plan.json` and `sparkconf.json` — each must exist, be non-empty, status `SUCCESS`. Verify `plan-diff.json` has no `CRITICAL` entries in `critical_blockers[]`. On failure or unresolved blockers → `INVALID_HANDOFF`, state reason, stop.
3. Check `execution-report.json` → if valid, `resume_mode: true`, skip to AFTER COMPLETION.
4. Determine execution mode (Step 1 below), then execute.
5. Write `migration-artifacts/runs/{run_id}/execution-report.json`.
6. Emit AFTER COMPLETION.

---

## Upstream Inputs
- `optimized-spark-plan.json` (required)
- `sparkconf.json` (required)
- `plan-diff.json` (required — must have no CRITICAL blockers)
- Repository build and launcher files

## Execution Steps

**Step 1 — Determine Execution Mode**
Check whether Spark runtime access is available by looking for:
- A running Spark cluster or `spark-submit` in the environment
- Docker Compose or local Spark setup in the repository
- A test harness that invokes Spark

Mode options (in priority order):
- `FULL_EXECUTION` — Spark available, run the job
- `COMPILE_PACKAGE_ONLY` — Build toolchain available, compile and package without running
- `DRY_RUN` — No runtime access; generate exact commands and scripts only

Announce the selected mode at the start of output.

**Step 2 — Discover Build and Launch Artifacts**
Search repository for:
- `pom.xml`, `build.gradle` — determine build commands
- Module boundaries and packaging rules
- `spark-submit` wrapper scripts or launcher configs
- Integration test scripts or CI pipeline configs
- Dependency packaging rules (fat JAR, shade, assembly)

**Step 3 — Execute Based on Mode**

*FULL_EXECUTION:*
- Build the project and package the JAR
- Run `spark-submit` with parameters from `sparkconf.json → spark_submit_parameters`
- Capture application ID, stage metrics, and output locations
- Capture any errors or warnings from the driver log

*COMPILE_PACKAGE_ONLY:*
- Run build and package commands
- Verify the assembled JAR contains the required classes from `interop-plan.json`
- Report success/failure of compilation
- Generate the exact `spark-submit` command that would be used for a full run

*DRY_RUN:*
- Produce the complete `spark-submit` command with all flags
- Produce a step-by-step execution guide (build → package → submit → monitor)
- Reference `sparkconf.json → spark_submit_parameters` exactly
- Note which steps require cluster access

---

## Output
Write: `migration-artifacts/runs/{run_id}/execution-report.json`

Include:
- `execution_mode` — FULL_EXECUTION / COMPILE_PACKAGE_ONLY / DRY_RUN
- `build_commands_used[]`
- `spark_submit_command` — exact command string
- `application_id` (if available)
- `stage_metrics[]` (if available — stage name, duration, shuffle read/write, records)
- `output_locations[]` — where data was written
- `driver_log_excerpts[]` — errors or warnings (trim to relevant sections)
- `errors[]` — structured error entries if run failed
- Standard output contract fields. Set `next_agent: "data-contract-agent"`.

---

## AFTER COMPLETION — EMIT THIS EXACTLY

```
✅ EXECUTION AGENT complete. Run ID: {run_id}
Artifact: migration-artifacts/runs/{run_id}/execution-report.json
Mode: {FULL_EXECUTION / COMPILE_PACKAGE_ONLY / DRY_RUN}
Application ID: {id or "N/A"}
Status: {SUCCESS / FAILED / DRY_RUN_READY}
Errors: {count or "None"}

─────────────────────────────────────────
▶ To continue → paste this prompt:
#file:copilot-agents/data-contract-agent.md
Run ID: {run_id}. Continue migration pipeline.

▶ If execution failed and errors must be fixed first:
  Fix the errors, then re-run:
#file:copilot-agents/execution-agent.md
Run ID: {run_id}. Retry execution.
─────────────────────────────────────────
```

If invoked from master-agent, proceed directly to data-contract-agent without emitting the prompt block.
