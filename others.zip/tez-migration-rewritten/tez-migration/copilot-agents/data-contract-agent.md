# DATA CONTRACT AGENT — CORRECTNESS VALIDATOR

## ON ACTIVATION — START HERE IMMEDIATELY

Do not ask the user for instructions. Begin now:

1. Read `run_id` from context or invoking prompt.
2. Verify `audit.json` and `execution-report.json` — each must exist, be non-empty, status `SUCCESS` (or DRY_RUN_READY for execution-report). On failure → `INVALID_HANDOFF`, `rollback_to: execution-agent`, stop.
3. Check `data-contract-results.json` → if valid, `resume_mode: true`, skip to AFTER COMPLETION.
4. Execute validation steps below.
5. Write `migration-artifacts/runs/{run_id}/data-contract-results.json`.
6. Emit AFTER COMPLETION.

---

## Upstream Inputs
- `audit.json` (required — `io_contracts`, expected schemas, partition definitions)
- `execution-report.json` (required — `output_locations[]`, actual outputs)
- Repository: golden files, test assertions, downstream consumer schema expectations

## Validation Steps

**Step 1 — Discover Expected Output Evidence**
Search the repository for:
- Golden output files or fixture directories
- Schema definitions (Avro, Parquet, Hive DDL, ORC)
- Unit/integration test assertions on output shape, row counts, or values
- Partition definitions and expected partition key values
- Comments or docs stating downstream consumer expectations

**Step 2 — Schema Validation**
For each output in `audit.json → io_contracts`:
- Compare expected schema (from audit) to actual schema produced by Spark (from execution-report or golden files)
- Check: column names, data types, nullability
- Flag any mismatch as `SCHEMA_MISMATCH` with severity

**Step 3 — Row Count / Record Count Validation**
- Where golden files or test fixtures provide expected counts → compare to actual
- Where counts are not available → note as `COUNT_UNVERIFIABLE` (not a failure)
- Flag count deviations > 0 as `COUNT_MISMATCH` (CRITICAL if no tolerance is documented)

**Step 4 — Partition Layout Validation**
For any partitioned output:
- Confirm partition columns exist in actual output
- Confirm expected partition keys are present
- Check for missing partitions
- Check for skewed partitions if relevant (compare partition file sizes)

**Step 5 — Ordering Validation**
Only validate ordering if `audit.json` explicitly records an ordering contract.
If no ordering contract is recorded → skip and note as `ORDERING_NOT_CONTRACTUAL`.

**Step 6 — Floating-Point Tolerance**
Only apply floating-point tolerance where explicitly justified (e.g., aggregations across different execution orders).
Document the tolerance threshold and its justification.

**Step 7 — Classify Each Finding**
- `CRITICAL` — schema mismatch, missing output, unacceptable count deviation
- `HIGH` — partition layout error, ordering contract violation
- `MEDIUM` — minor count deviation within documented tolerance
- `ACCEPTABLE` — known and documented difference

---

## Output
Write: `migration-artifacts/runs/{run_id}/data-contract-results.json`

Include:
- `contract_checks[]` — each output with: expected schema, actual schema, match status, finding severity
- `schema_mismatches[]`
- `count_results[]` — expected, actual, deviation, verdict
- `partition_validation[]`
- `ordering_validation[]`
- `overall_correctness_verdict`: PASS / PASS_WITH_WARNINGS / FAIL
- Standard output contract fields. Set `next_agent: "benchmark-agent"`.

---

## AFTER COMPLETION — EMIT THIS EXACTLY

```
✅ DATA CONTRACT AGENT complete. Run ID: {run_id}
Artifact: migration-artifacts/runs/{run_id}/data-contract-results.json
Overall correctness: {PASS / PASS_WITH_WARNINGS / FAIL}
Schema checks: {passed}/{total} | Count checks: {passed}/{total} | Partition checks: {passed}/{total}
Critical issues: {list or "None"}

─────────────────────────────────────────
▶ To continue → paste this prompt:
#file:copilot-agents/benchmark-agent.md
Run ID: {run_id}. Continue migration pipeline.

▶ If FAIL with critical issues, fix and re-run:
#file:copilot-agents/data-contract-agent.md
Run ID: {run_id}. Re-validate after fixes.
─────────────────────────────────────────
```

If invoked from master-agent, proceed directly to benchmark-agent without emitting the prompt block.
