# Java → Python Migration Pipeline — QUICKSTART

Read once. Never need to read again.

---

## 1. How to Start

Paste this single prompt into GitHub Copilot Chat:

```
#file:copilot-agents/master-agent.md
Start Java-to-Python migration pipeline. Java source path: <path-to-your-java-project>
```

Replace `<path-to-your-java-project>` with the root folder of your Java project (where `pom.xml` or `build.gradle` lives).

The pipeline runs automatically through Phase 0–3, then pauses for your approval.

---

## 2. Approval Gates (the only times you type something)

### GATE 1 — After Go/No-Go Report (Phase 3)
The agent presents a risk/complexity table. You reply:

| Reply | Meaning |
|-------|---------|
| `GO J2PY-YYYYMMDD-HHMM-XXXX` | Proceed with conversion |
| `STOP J2PY-YYYYMMDD-HHMM-XXXX` | Abort — too risky |

### GATE 2 — After Validation (Phase 7)
The agent presents pytest results and health status. You reply:

| Reply | Meaning |
|-------|---------|
| `FINALIZE J2PY-YYYYMMDD-HHMM-XXXX` | Proceed to cutover plan |
| `ABORT J2PY-YYYYMMDD-HHMM-XXXX` | Stop — get repair guide |

---

## 3. How to Resume a Failed Run

If any agent fails or Copilot session times out mid-pipeline:

```
#file:copilot-agents/master-agent.md
Run ID: J2PY-YYYYMMDD-HHMM-XXXX. Resume Java-to-Python migration pipeline.
```

The master agent will detect which phase completed last and resume from the next one.
No work is repeated. No artifacts are overwritten.

To resume from a specific phase directly:

```
#file:copilot-agents/agent-05-conversion-executor.md
Run ID: J2PY-YYYYMMDD-HHMM-XXXX. Continue migration pipeline.
```

---

## 4. Where to Find Your Output

All outputs are in: `migration-artifacts/runs/{run_id}/`

| What you want               | Where to find it                                    |
|-----------------------------|-----------------------------------------------------|
| Converted Python source     | `05-conversion/src/`                                |
| pytest test files           | `06-tests/tests/`                                   |
| requirements.txt            | `02-dependency-map/requirements.txt`                |
| pyproject.toml              | `02-dependency-map/pyproject.toml`                  |
| Go/No-Go report             | `03-go-nogo/go-nogo-report.json`                    |
| Validation results          | `07-validation/validation-report.json`              |
| pytest output log           | `07-validation/pytest-output.txt`                   |
| Cutover plan                | `08-review/cutover-plan.md`                         |
| Rollback plan               | `08-review/rollback-plan.md`                        |
| Final report                | `09-final-report/final-report.md`                   |
| Pipeline log                | `pipeline.log`                                      |

---

## 5. Pipeline Phases at a Glance

```
Phase 0  Audit          → Scan project, detect build system, frameworks, complexity
Phase 1  Java Parser    → Deep parse: classes, methods, types, patterns, dependencies
Phase 2  Dep Mapper     → Map Maven/Gradle deps → Python packages + requirements.txt
Phase 3  Go/No-Go       → Risk assessment + effort estimate ──► GATE 1 (you decide)
Phase 4  Type Strategy  → Plan type mapping, OOP strategy, DI, routes, entities
Phase 5  Conversion     → Write all Python files (the main event)
Phase 6  Test Generator → Convert JUnit → pytest, generate skeletons for coverage
Phase 7  Validator      → Syntax check + mypy + ruff + pytest run ──► GATE 2 (you decide)
Phase 8  Reviewer       → Cutover plan, rollback plan, quality score
Phase 9  Final Reporter → Full report + next steps
```

---

## 6. Quick Reference — Python Project Setup After Migration

```bash
cd migration-artifacts/runs/{run_id}

# Install dependencies
pip install -r 02-dependency-map/requirements.txt
pip install -r 02-dependency-map/requirements-test.txt

# Configure environment
cp 08-review/cutover-plan.md .   # contains .env.template
# Fill in .env with your actual values

# Run DB migrations (if JPA/Hibernate was used)
alembic upgrade head

# Run tests
pytest 06-tests/tests/ -v

# Start the server
uvicorn src.main:app --reload --port 8080
```

---

*That's it. One start prompt. Two gate replies. One resume prompt if needed.*
