# Java → Python Migration Pipeline — Global Instructions
# Inherited automatically by ALL agents. Do not duplicate any rule below in agent files.

---

## Run ID Format

`J2PY-YYYYMMDD-HHMM-XXXX`
Example: `J2PY-20260423-0930-A1B2`

- Generate at pipeline start if not supplied by the user.
- Use as the folder name under `migration-artifacts/runs/{run_id}/`.
- Every artifact, log entry, and output file must carry this run_id.

---

## Artifact Folder Layout

```
migration-artifacts/
  runs/
    {run_id}/
      00-audit/
        audit-report.json
        file-inventory.json
      01-java-parse/
        class-map.json
        dependency-graph.json
      02-dependency-map/
        dependency-mapping.json
        requirements.txt
        pyproject.toml
      03-go-nogo/
        go-nogo-report.json
      04-type-strategy/
        type-mapping.json
        pattern-strategy.json
      05-conversion/
        src/                   ← converted Python source files (mirror of Java package structure)
        conversion-log.json
      06-tests/
        tests/                 ← generated pytest files
        test-plan.json
      07-validation/
        validation-report.json
        pytest-output.txt
      08-review/
        review-report.json
        cutover-plan.md
        rollback-plan.md
      09-final-report/
        final-report.md
        final-summary.json
```

---

## Canonical Agent Pipeline

| Phase | Agent File                        | Key Output Artifact             |
|-------|-----------------------------------|---------------------------------|
| 0     | agent-00-auditor.md               | audit-report.json, file-inventory.json |
| 1     | agent-01-java-parser.md           | class-map.json, dependency-graph.json |
| 2     | agent-02-dependency-mapper.md     | dependency-mapping.json, requirements.txt |
| 3     | agent-03-go-nogo-reporter.md      | go-nogo-report.json → **GATE 1** |
| 4     | agent-04-type-strategy-planner.md | type-mapping.json, pattern-strategy.json |
| 5     | agent-05-conversion-executor.md   | converted Python source files  |
| 6     | agent-06-test-generator.md        | pytest test files, test-plan.json |
| 7     | agent-07-validator.md             | validation-report.json → **GATE 2** |
| 8     | agent-08-reviewer.md              | review-report.json, cutover-plan.md |
| 9     | agent-09-final-reporter.md        | final-report.md                 |

---

## Approval Gates

### GATE 1 — After Go/No-Go Report (Phase 3)
```
STOP. Display GO/NO-GO summary to user.
Emit: "Reply GO {run_id} to begin conversion or STOP {run_id} to abort."
Do not proceed until explicit user reply is received.
```

### GATE 2 — After Validation (Phase 7)
```
STOP. Display validation pass/fail summary to user.
Emit: "Reply FINALIZE {run_id} to proceed to review and cutover, or ABORT {run_id} to stop."
Do not proceed until explicit user reply is received.
```

---

## Repository Discovery Rules

When scanning a Java project, agents must look for:

| What to Find                | File Patterns                                |
|-----------------------------|----------------------------------------------|
| Java source files           | `**/*.java`                                  |
| Maven build descriptor      | `pom.xml`                                    |
| Gradle build descriptor     | `build.gradle`, `build.gradle.kts`, `settings.gradle` |
| Test sources                | `**/test/**/*.java`, `**/*Test.java`, `**/*Tests.java`, `**/*Spec.java` |
| Resource / config files     | `**/resources/**`, `application.properties`, `application.yml` |
| Spring boot config          | `**/application*.properties`, `**/application*.yml` |
| Dockerfile                  | `Dockerfile*`                                |
| CI configs                  | `.github/`, `.gitlab-ci.yml`, `Jenkinsfile`  |
| README                      | `README.md`, `README.txt`                    |

---

## Handoff Verification (Every Agent Must Do This Before Proceeding)

Before consuming any upstream artifact:
1. File exists at the expected path and is non-empty.
2. `run_id` field matches the current run_id.
3. Required top-level fields are present and not placeholder/null values.
4. Upstream `status` field equals `SUCCESS`.

On any failure:
- Set own status to `BLOCKED`.
- Emit `INVALID_HANDOFF` with `rollback_to` pointing to the failed upstream agent.
- Stop immediately. Do not attempt to proceed or guess missing data.

---

## Resume Logic (Every Agent Must Check This First)

```
1. Check if own output artifact already exists at the canonical path.
2. If it exists AND is valid AND run_id matches:
   → Set resume_mode: true
   → Skip all execution steps
   → Jump directly to AFTER COMPLETION block
3. If it does not exist OR is corrupt OR run_id mismatch:
   → Regenerate from scratch
```

This makes every pipeline run restartable from any agent without re-running completed phases.

---

## Standard Output Contract (JSON — Every Agent Produces This)

```json
{
  "run_id": "J2PY-YYYYMMDD-HHMM-XXXX",
  "generated_by": "<agent-file-name>",
  "timestamp": "<ISO8601>",
  "status": "SUCCESS | FAILED | NEEDS_REVIEW | BLOCKED",
  "validation_passed": true,
  "resume_mode": false,
  "artifacts_consumed": ["path/to/upstream/artifact.json"],
  "artifacts_produced": ["path/to/this/artifact.json"],
  "blocking_issues": [],
  "warnings": [],
  "confidence_score": 0.0,
  "rollback_to": "<agent-file-name or null>",
  "next_agent": "<agent-file-name>"
}
```

---

## Java → Python Conversion Standards

All agents must apply these standards consistently:

### Package / Module Mapping
- Java package `com.example.service` → Python module `example/service/`
- Java `src/main/java/` → Python `src/`
- Java `src/test/java/` → Python `tests/`
- Each Java class becomes a `.py` file with snake_case filename.
- `MyClass.java` → `my_class.py`
- Method names: `camelCase` → `snake_case`
- Constants: `UPPER_CASE` stays `UPPER_CASE`

### Type Mapping
| Java Type           | Python Equivalent            |
|---------------------|------------------------------|
| `int`, `Integer`    | `int`                        |
| `long`, `Long`      | `int`                        |
| `double`, `Double`  | `float`                      |
| `float`, `Float`    | `float`                      |
| `boolean`, `Boolean`| `bool`                       |
| `String`            | `str`                        |
| `char`, `Character` | `str` (single char)          |
| `byte[]`            | `bytes`                      |
| `void`              | `None`                       |
| `Object`            | `Any` (from typing)          |
| `List<T>`           | `list[T]`                    |
| `Map<K,V>`          | `dict[K, V]`                 |
| `Set<T>`            | `set[T]`                     |
| `Optional<T>`       | `T \| None` or `Optional[T]` |
| `T[]`               | `list[T]`                    |
| `Callable<T>`       | `Callable[..., T]`           |

### OOP Pattern Mapping
| Java Pattern           | Python Pattern                                    |
|------------------------|---------------------------------------------------|
| `interface`            | `Protocol` (typing) or ABC                        |
| `abstract class`       | `ABC` with `@abstractmethod`                      |
| `enum`                 | `Enum` from `enum` module                         |
| `implements`           | Inherit from Protocol/ABC                         |
| `extends`              | Normal inheritance                                |
| Generics `<T>`         | `TypeVar` from typing                             |
| `static` method        | `@staticmethod`                                   |
| `static` field         | Class-level variable                              |
| `final` field          | Convention: no reassignment + type hint           |
| `synchronized`         | `threading.Lock()`                                |
| `instanceof`           | `isinstance()`                                    |
| Constructor overloading| `@classmethod` factory methods or default args    |

### Framework Mapping
| Java Framework         | Python Equivalent                                 |
|------------------------|---------------------------------------------------|
| Spring Boot (REST)     | FastAPI or Flask                                  |
| Spring DI / IoC        | dependency-injector or manual DI                  |
| Spring Data JPA        | SQLAlchemy + Alembic                              |
| Spring Security        | FastAPI auth / python-jose                        |
| Spring Kafka           | confluent-kafka-python or aiokafka                |
| Hibernate              | SQLAlchemy ORM                                    |
| JUnit 5                | pytest                                            |
| Mockito                | pytest-mock / unittest.mock                       |
| Log4j / SLF4J          | Python `logging` module                           |
| Jackson (JSON)         | `json` stdlib or `pydantic`                       |
| Lombok `@Data`         | `@dataclass` or pydantic `BaseModel`              |
| Lombok `@Builder`      | `@dataclass` with builder pattern                 |

---

## Failure Logging Format

Every agent must append failures to `migration-artifacts/runs/{run_id}/pipeline.log`:

```
[TIMESTAMP] [AGENT: agent-XX-name] [SEVERITY: ERROR|WARN|INFO] <message>
[TIMESTAMP] [AGENT: agent-XX-name] [HANDOFF: INVALID] upstream=<agent> reason=<reason>
```

---

## Hard Stops — Always Block Progress

These conditions must halt any agent immediately with status `BLOCKED`:

1. **Invalid handoff** — upstream artifact missing, corrupt, or status ≠ SUCCESS.
2. **Zero Java files found** — audit found no `.java` files in the specified path.
3. **Build system undetected** — neither `pom.xml` nor `build.gradle` found AND no `.java` files in root.
4. **Circular dependency detected** — agent-01 detected a cycle that cannot be broken without manual intervention.
5. **Conversion confidence < 0.5** — agent-05 produced output with confidence below threshold → flag NEEDS_REVIEW on every file, do not auto-approve.
6. **All validation tests fail** — 0 pytest tests pass → hard stop before Gate 2.

---

## How to Start

```
#file:copilot-agents/master-agent.md
Start Java-to-Python migration pipeline. Java source path: <path>
```

That is the only prompt the user needs to type.
