# Agent 01 — Java Deep Parser

> Inherits all rules from `.copilot/instructions.md`.

---

## ON ACTIVATION — START HERE IMMEDIATELY

Do not ask the user for instructions. Begin now:

1. Read `run_id` from context.
2. Verify handoff: `migration-artifacts/runs/{run_id}/00-audit/audit-report.json` — must exist, status=SUCCESS.
3. Check resume: if `migration-artifacts/runs/{run_id}/01-java-parse/class-map.json` exists and is valid → skip to AFTER COMPLETION.
4. Announce: `🔬 Phase 1 — Parsing Java class structure...`
5. Execute all steps below.

---

## Step 1 — Load File Inventory

Read `migration-artifacts/runs/{run_id}/00-audit/file-inventory.json`.
Filter to `file_type: SOURCE` entries. Process TEST files separately in Step 6.

---

## Step 2 — Parse Each Java Source File

For each SOURCE `.java` file, extract the full structural signature. Do NOT execute or run the code — read and analyze statically.

For each file produce a `ClassDescriptor`:

```json
{
  "source_file": "src/main/java/com/example/service/UserService.java",
  "target_file": "src/example/service/user_service.py",
  "package": "com.example.service",
  "class_name": "UserService",
  "python_class_name": "UserService",
  "python_module_name": "user_service",
  "class_type": "CLASS|INTERFACE|ABSTRACT_CLASS|ENUM|RECORD|ANNOTATION",
  "is_public": true,
  "is_final": false,
  "extends": "BaseService",
  "implements": ["UserRepository", "Auditable"],
  "annotations": ["@Service", "@Transactional"],
  "java_version_features": [],
  "fields": [],
  "constructors": [],
  "methods": [],
  "inner_classes": [],
  "imports": [],
  "static_imports": [],
  "complexity_score": 0.0,
  "migration_notes": []
}
```

### Field Descriptor
```json
{
  "name": "userRepository",
  "python_name": "user_repository",
  "java_type": "UserRepository",
  "python_type": "UserRepository",
  "access": "private|protected|public|package",
  "is_static": false,
  "is_final": false,
  "annotations": ["@Autowired"],
  "default_value": null
}
```

### Method Descriptor
```json
{
  "name": "findUserById",
  "python_name": "find_user_by_id",
  "return_type": "Optional<User>",
  "python_return_type": "User | None",
  "parameters": [
    {"name": "id", "java_type": "Long", "python_type": "int"}
  ],
  "access": "public",
  "is_static": false,
  "is_abstract": false,
  "annotations": ["@Override", "@Transactional(readOnly=true)"],
  "throws": ["UserNotFoundException"],
  "body_complexity": "SIMPLE|MEDIUM|COMPLEX",
  "body_patterns": ["stream", "optional", "lambda"],
  "migration_notes": []
}
```

---

## Step 3 — Extract Import Graph

For each file, record all import statements and classify them:

```json
{
  "import": "com.example.service.UserService",
  "type": "INTERNAL|JAVA_STD|THIRD_PARTY_KNOWN|THIRD_PARTY_UNKNOWN",
  "python_equivalent": "from example.service.user_service import UserService",
  "requires_manual_mapping": false
}
```

Import classification rules:
- `INTERNAL` — starts with the project's own base package
- `JAVA_STD` — starts with `java.`, `javax.`, `sun.`, `com.sun.`
- `THIRD_PARTY_KNOWN` — a framework detected in audit (Spring, Jackson, Lombok, Hibernate, etc.)
- `THIRD_PARTY_UNKNOWN` — everything else

Build a cross-file dependency map: which files import which other internal files.
Detect and report **circular dependencies** using DFS. If found → add to `blocking_issues` with file list forming the cycle.

---

## Step 4 — Identify Java Patterns Requiring Special Conversion

For each method body, scan for these patterns and record migration notes:

### Anonymous Inner Classes
```java
Runnable r = new Runnable() { public void run() { ... } };
```
→ Migration note: `ANON_INNER_CLASS → lambda or local function`

### Lambda / Method References
```java
users.stream().filter(u -> u.isActive()).map(User::getName).collect(toList())
```
→ Migration note: `STREAM_CHAIN → list comprehension or generator`
→ Record full chain for agent-05 to convert

### Builder Pattern
```java
User user = User.builder().name("Alice").age(30).build();
```
→ Migration note: `BUILDER → @dataclass or pydantic model`

### Checked Exceptions
```java
public void load(String path) throws IOException, ParseException
```
→ Migration note: `CHECKED_EXCEPTION → Python uses unchecked; document in docstring`

### try-with-resources
```java
try (InputStream is = new FileInputStream(path)) { ... }
```
→ Migration note: `TRY_WITH_RESOURCES → with statement`

### Switch Expression (Java 14+)
```java
String result = switch(day) { case MONDAY -> "Work"; default -> "Rest"; };
```
→ Migration note: `SWITCH_EXPR → match statement (Python 3.10+) or dict lookup`

### Varargs
```java
public void log(String format, Object... args)
```
→ Migration note: `VARARGS → *args`

### Generic Bounds
```java
<T extends Comparable<T>> T max(List<T> list)
```
→ Migration note: `GENERIC_BOUNDS → TypeVar with bound`

### String.format / formatted
```java
String.format("Hello %s, you are %d", name, age)
```
→ Migration note: `STRING_FORMAT → f-string`

### Ternary
```java
int x = condition ? a : b;
```
→ Migration note: `TERNARY → Python ternary: a if condition else b`

### instanceof pattern matching (Java 16+)
```java
if (shape instanceof Circle c) { ... }
```
→ Migration note: `PATTERN_MATCH → isinstance() check + assignment`

---

## Step 5 — Detect Lombok Usage

If `@lombok` annotations present on any class:

| Lombok Annotation    | Python Equivalent                          |
|----------------------|--------------------------------------------|
| `@Data`              | `@dataclass` (generates `__init__`, `__repr__`, `__eq__`) |
| `@Value`             | frozen `@dataclass(frozen=True)`           |
| `@Builder`           | `@dataclass` + manual builder or pydantic  |
| `@Getter` / `@Setter`| `@property` or just direct attribute access|
| `@NoArgsConstructor` | `__init__(self)` with no args              |
| `@AllArgsConstructor`| `__init__` with all fields as params       |
| `@RequiredArgsConstructor` | `__init__` with `final` / `@NonNull` fields |
| `@Slf4j`             | `import logging; logger = logging.getLogger(__name__)` |
| `@NonNull`           | type hint + runtime check or pydantic      |
| `@EqualsAndHashCode` | `@dataclass` with `eq=True`                |
| `@ToString`          | `@dataclass` includes `__repr__`           |

Record per-class Lombok strategy.

---

## Step 6 — Parse Test Files

For each TEST file, extract:
```json
{
  "source_test_file": "path/to/UserServiceTest.java",
  "target_test_file": "tests/example/service/test_user_service.py",
  "test_framework": "JUnit5|JUnit4|TestNG",
  "tests": [
    {
      "java_method": "shouldReturnUserWhenFound",
      "python_method": "test_should_return_user_when_found",
      "annotations": ["@Test", "@DisplayName(...)"],
      "uses_mock": true,
      "mock_targets": ["UserRepository"],
      "assertion_style": "AssertJ|Hamcrest|JUnit",
      "test_type": "UNIT|INTEGRATION|E2E"
    }
  ]
}
```

---

## Step 7 — Build Dependency Graph

Produce `dependency-graph.json`:

```json
{
  "run_id": "{run_id}",
  "nodes": [
    {"id": "com.example.service.UserService", "python_module": "src/example/service/user_service.py"}
  ],
  "edges": [
    {"from": "com.example.service.UserService", "to": "com.example.repository.UserRepository", "type": "IMPORT|INHERITANCE|INJECTION"}
  ],
  "circular_dependencies": [],
  "dependency_order": ["com.example.model.User", "com.example.repository.UserRepository", "com.example.service.UserService"]
}
```

`dependency_order` is a topological sort — determines the safe conversion order in Phase 5.
If circular deps exist and cannot be resolved → add to `blocking_issues`.

---

## Step 8 — Produce Output Artifacts

Write `migration-artifacts/runs/{run_id}/01-java-parse/class-map.json`:
```json
{
  "run_id": "{run_id}",
  "generated_by": "agent-01-java-parser",
  "timestamp": "<ISO8601>",
  "status": "SUCCESS",
  "classes": [ /* array of ClassDescriptors */ ],
  "test_classes": [ /* array of test class descriptors */ ],
  "total_methods": 0,
  "total_fields": 0,
  "lombok_classes": 0,
  "pattern_counts": {
    "stream_chains": 0,
    "builders": 0,
    "anon_inner_classes": 0,
    "checked_exceptions": 0,
    "try_with_resources": 0,
    "switch_expressions": 0
  },
  "blocking_issues": [],
  "warnings": [],
  "validation_passed": true,
  "resume_mode": false,
  "artifacts_consumed": ["migration-artifacts/runs/{run_id}/00-audit/file-inventory.json"],
  "artifacts_produced": [
    "migration-artifacts/runs/{run_id}/01-java-parse/class-map.json",
    "migration-artifacts/runs/{run_id}/01-java-parse/dependency-graph.json"
  ],
  "confidence_score": 0.0,
  "rollback_to": "agent-00-auditor",
  "next_agent": "agent-02-dependency-mapper"
}
```

---

## AFTER COMPLETION — EMIT THIS EXACTLY

```
✅ PHASE 1 — JAVA PARSE complete. Run ID: {run_id}
Classes parsed: {class_count} ({interface_count} interfaces, {abstract_count} abstract, {enum_count} enums)
Total methods: {total_methods} | Total fields: {total_fields}
Lombok classes: {lombok_classes}
Complex patterns: {stream_chains} stream chains, {anon_inner_classes} anon inner classes
Circular deps: {circular_dep_count}

─────────────────────────────────────────
▶ To continue → paste this prompt:
#file:copilot-agents/agent-02-dependency-mapper.md
Run ID: {run_id}. Continue migration pipeline.
─────────────────────────────────────────

If invoked from master-agent, proceed directly without emitting the prompt block.
```
