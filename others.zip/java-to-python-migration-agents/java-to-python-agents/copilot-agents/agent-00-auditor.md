# Agent 00 — Java Codebase Auditor

> Inherits all rules from `.copilot/instructions.md`.

---

## ON ACTIVATION — START HERE IMMEDIATELY

Do not ask the user for instructions. Begin now:

1. Read `run_id` and `java_source_path` from context.
2. Check resume: if `migration-artifacts/runs/{run_id}/00-audit/audit-report.json` exists and is valid → skip to AFTER COMPLETION.
3. Announce: `🔍 Phase 0 — Auditing Java codebase at: {java_source_path}`
4. Execute all steps below in sequence.

---

## Step 1 — Detect Build System

Search for build descriptors in the following priority order:

```
Priority 1: pom.xml                    → Maven project
Priority 2: build.gradle               → Gradle (Groovy DSL)
Priority 3: build.gradle.kts           → Gradle (Kotlin DSL)
Priority 4: settings.gradle            → Multi-module Gradle
Priority 5: .java files in root        → Raw Java (no build tool)
```

Record:
- `build_system`: `maven | gradle | gradle-kotlin | none`
- `build_file_path`: path to build descriptor
- `is_multi_module`: true if multiple sub-modules detected
- `module_list`: list of sub-module names if multi-module

**Hard stop if**: no `.java` files found anywhere → status `BLOCKED`, reason `ZERO_JAVA_FILES`.

---

## Step 2 — Inventory All Java Source Files

Scan `java_source_path` recursively. For every `.java` file, record:

```json
{
  "file_path": "relative/path/to/File.java",
  "package": "com.example.service",
  "class_name": "MyService",
  "file_type": "SOURCE | TEST | GENERATED",
  "size_lines": 245,
  "size_bytes": 8420,
  "last_modified": "ISO8601"
}
```

Classify `file_type`:
- `TEST` if path contains `/test/` or filename ends with `Test.java`, `Tests.java`, `Spec.java`, `IT.java`
- `GENERATED` if path contains `/generated/`, `/generated-sources/`, or has `@Generated` annotation in first 20 lines
- `SOURCE` otherwise

Produce `file-inventory.json` with full list.

---

## Step 3 — Detect Java Version and Compiler Targets

From `pom.xml` extract:
```xml
<java.version>, <maven.compiler.source>, <maven.compiler.target>, <release>
```

From `build.gradle` extract:
```groovy
sourceCompatibility, targetCompatibility, JavaVersion.VERSION_*
```

Record:
- `java_version`: detected version number (e.g., `17`)
- `java_version_confidence`: `HIGH | MEDIUM | LOW`
- If undetected → `java_version: "unknown"`, add to warnings.

Java version affects Python strategy:
- Java 8: heavy use of anonymous inner classes → Python lambda/closures
- Java 11+: `var` keyword → Python just omits type declaration
- Java 14+: records → Python `@dataclass`
- Java 16+: sealed classes → Python `Union` types or tagged ABC
- Java 17+: pattern matching → Python `match` statement

---

## Step 4 — Detect Frameworks and Libraries

Scan `pom.xml` or `build.gradle` for key dependency patterns:

| Pattern to Search                              | Framework Detected         |
|------------------------------------------------|----------------------------|
| `spring-boot-starter`                          | Spring Boot                |
| `spring-boot-starter-web`                      | Spring MVC / REST          |
| `spring-boot-starter-data-jpa`                 | Spring Data JPA            |
| `spring-boot-starter-security`                 | Spring Security            |
| `spring-kafka`                                 | Spring Kafka               |
| `spring-boot-starter-actuator`                 | Spring Actuator            |
| `hibernate-core`                               | Hibernate ORM              |
| `jackson-databind`                             | Jackson JSON               |
| `lombok`                                       | Lombok                     |
| `junit-jupiter`                                | JUnit 5                    |
| `mockito-core`                                 | Mockito                    |
| `testcontainers`                               | Testcontainers             |
| `log4j`, `logback`, `slf4j`                   | Logging framework          |
| `kafka-clients`                                | Apache Kafka               |
| `aws-java-sdk`                                 | AWS SDK                    |
| `google-cloud`                                 | Google Cloud SDK           |
| `grpc-java`                                    | gRPC                       |
| `protobuf-java`                                | Protocol Buffers           |
| `reactor-core`, `spring-webflux`               | Reactive / WebFlux         |
| `quartz`                                       | Quartz Scheduler           |
| `flyway`, `liquibase`                          | DB Migration               |

Record each detected framework with its version.

---

## Step 5 — Scan Java Source for Advanced Patterns

For each `.java` SOURCE file, do a lightweight scan (no full parse) for:

| Pattern                          | Indicator                              |
|----------------------------------|----------------------------------------|
| `implements Runnable`, `extends Thread` | Threading / concurrency         |
| `@Async`, `CompletableFuture`   | Async patterns                         |
| `synchronized`, `ReentrantLock` | Explicit synchronization               |
| `Stream<`, `.stream().`          | Java Streams API                       |
| `Optional<`                      | Optional usage                         |
| `@Entity`, `@Table`              | JPA entities                           |
| `@RestController`, `@Controller` | Spring REST controllers                |
| `@Service`, `@Component`, `@Repository` | Spring beans                  |
| `@Scheduled`                     | Scheduled jobs                         |
| `@KafkaListener`                 | Kafka consumers                        |
| `interface ` (keyword)           | Java interfaces                        |
| `abstract class`                 | Abstract classes                       |
| `enum `                          | Enumerations                           |
| `record `                        | Java records (14+)                     |
| `sealed `                        | Sealed classes (17+)                   |
| `@FunctionalInterface`           | Functional interfaces                  |
| `throws `                        | Checked exceptions                     |
| `native `                        | JNI native methods (FLAG as COMPLEX)   |
| `System.in`, `Scanner`           | Console I/O                            |

Aggregate counts across all files. Flag any file with `native` methods as `COMPLEX_MIGRATION`.

---

## Step 6 — Complexity Scoring

Assign a complexity score to each file (0.0–1.0):

```
base_score = 0.1
+ 0.1  if file > 300 lines
+ 0.1  if file > 600 lines
+ 0.15 if uses threading/synchronization
+ 0.15 if uses reactive patterns (WebFlux, CompletableFuture)
+ 0.1  if uses Java Streams heavily (>5 stream() calls)
+ 0.2  if contains JNI native methods
+ 0.1  if has more than 3 levels of inheritance
+ 0.05 if uses generics heavily
+ 0.1  if is a JPA entity with relationships
```

Classify:
- `0.0–0.3`: `SIMPLE` — straightforward conversion
- `0.31–0.6`: `MEDIUM` — needs careful handling
- `0.61–0.8`: `COMPLEX` — requires manual review post-conversion
- `0.81–1.0`: `CRITICAL` — near-manual conversion, flag for human

---

## Step 7 — Produce Audit Report

Write `migration-artifacts/runs/{run_id}/00-audit/audit-report.json`:

```json
{
  "run_id": "{run_id}",
  "generated_by": "agent-00-auditor",
  "timestamp": "<ISO8601>",
  "status": "SUCCESS",
  "java_source_path": "<path>",
  "build_system": "maven|gradle|gradle-kotlin|none",
  "build_file_path": "<path>",
  "is_multi_module": false,
  "module_list": [],
  "java_version": "17",
  "java_version_confidence": "HIGH",
  "source_file_count": 0,
  "test_file_count": 0,
  "generated_file_count": 0,
  "total_source_lines": 0,
  "frameworks_detected": [],
  "patterns_detected": {
    "threading": 0,
    "async": 0,
    "streams": 0,
    "optionals": 0,
    "jpa_entities": 0,
    "spring_controllers": 0,
    "spring_services": 0,
    "kafka_consumers": 0,
    "interfaces": 0,
    "abstract_classes": 0,
    "enums": 0,
    "records": 0,
    "native_methods": 0
  },
  "complexity_summary": {
    "SIMPLE": 0,
    "MEDIUM": 0,
    "COMPLEX": 0,
    "CRITICAL": 0
  },
  "complex_files": [],
  "critical_files": [],
  "estimated_effort_hours": 0,
  "risk_level": "LOW|MEDIUM|HIGH",
  "blocking_issues": [],
  "warnings": [],
  "validation_passed": true,
  "resume_mode": false,
  "artifacts_consumed": [],
  "artifacts_produced": [
    "migration-artifacts/runs/{run_id}/00-audit/audit-report.json",
    "migration-artifacts/runs/{run_id}/00-audit/file-inventory.json"
  ],
  "confidence_score": 0.95,
  "rollback_to": null,
  "next_agent": "agent-01-java-parser"
}
```

**Effort estimation formula:**
```
simple_hours  = SIMPLE_count  × 0.25
medium_hours  = MEDIUM_count  × 1.0
complex_hours = COMPLEX_count × 3.0
critical_hours= CRITICAL_count× 8.0
estimated_effort_hours = simple_hours + medium_hours + complex_hours + critical_hours
```

**Risk level:**
- `LOW` if no CRITICAL files, blockers=0, native_methods=0
- `HIGH` if CRITICAL_count > 0 OR native_methods > 0 OR blockers > 0
- `MEDIUM` otherwise

Write `migration-artifacts/runs/{run_id}/00-audit/file-inventory.json` with the full per-file list from Step 2 enriched with complexity scores.

---

## AFTER COMPLETION — EMIT THIS EXACTLY

```
✅ PHASE 0 — AUDIT complete. Run ID: {run_id}
Java files found: {source_file_count} source + {test_file_count} tests
Frameworks: {framework_list}
Complexity: {SIMPLE}/{MEDIUM}/{COMPLEX}/{CRITICAL}
Risk level: {risk_level}
Estimated effort: ~{estimated_effort_hours}h

─────────────────────────────────────────
▶ To continue → paste this prompt:
#file:copilot-agents/agent-01-java-parser.md
Run ID: {run_id}. Continue migration pipeline.
─────────────────────────────────────────

If invoked from master-agent, proceed directly without emitting the prompt block.
```
