# Agent 06 — Test Generator

> Inherits all rules from `.copilot/instructions.md`.

---

## ON ACTIVATION — START HERE IMMEDIATELY

Do not ask the user for instructions. Begin now:

1. Read `run_id` from context.
2. Verify handoff: `migration-artifacts/runs/{run_id}/05-conversion/conversion-log.json` — must exist, status=SUCCESS or NEEDS_REVIEW.
3. Check resume: if `migration-artifacts/runs/{run_id}/06-tests/test-plan.json` exists and is valid → skip to AFTER COMPLETION.
4. Announce: `🧪 Phase 6 — Generating pytest test suite...`
5. Execute all steps below.

---

## Step 1 — Load Test Descriptors

Read `migration-artifacts/runs/{run_id}/01-java-parse/class-map.json`, field `test_classes`.
Read `migration-artifacts/runs/{run_id}/05-conversion/conversion-log.json` for the list of successfully converted Python files.

For each Java test file that has a corresponding converted Python source file → generate a Python test.
For converted Python files with NO Java test counterpart → generate skeleton tests covering public method signatures.

---

## Step 2 — Set Up Test Directory Structure

```
migration-artifacts/runs/{run_id}/06-tests/
  tests/
    __init__.py
    conftest.py            ← shared fixtures
    unit/
      __init__.py
      services/
        test_user_service.py
      repositories/
        test_user_repository.py
      utils/
        test_string_utils.py
    integration/
      __init__.py
      api/
        test_user_router.py
    e2e/
      __init__.py
  pytest.ini
```

---

## Step 3 — Generate conftest.py

```python
"""
Shared pytest fixtures.
Migrated from: Java @BeforeEach / @BeforeAll / Spring Test configuration.
Run ID: {run_id}
"""

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from fastapi.testclient import TestClient
from unittest.mock import MagicMock

# Import app and DB
from src.main import app
from src.database import Base, get_db

# ── In-memory SQLite for tests ─────────────────────────────────────────────
TEST_DATABASE_URL = "sqlite:///:memory:"

@pytest.fixture(scope="session")
def engine():
    """Create test database engine (in-memory SQLite)."""
    _engine = create_engine(
        TEST_DATABASE_URL,
        connect_args={"check_same_thread": False},
    )
    Base.metadata.create_all(bind=_engine)
    yield _engine
    Base.metadata.drop_all(bind=_engine)

@pytest.fixture(scope="function")
def db_session(engine):
    """Provide a transactional scope for each test — rolled back after."""
    connection = engine.connect()
    transaction = connection.begin()
    TestingSessionLocal = sessionmaker(bind=connection)
    session = TestingSessionLocal()

    yield session

    session.close()
    transaction.rollback()
    connection.close()

@pytest.fixture(scope="function")
def client(db_session):
    """Provide FastAPI test client with overridden DB dependency."""
    def override_get_db():
        try:
            yield db_session
        finally:
            pass

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as c:
        yield c
    app.dependency_overrides.clear()

@pytest.fixture
def mock_user_repository():
    """Mock for UserRepository."""
    return MagicMock()

# Add additional mocks for each detected @Repository / @Service here
```

---

## Step 4 — Convert JUnit Tests → pytest

For each Java test class, apply these conversions:

### Class-Level Mappings

| Java (JUnit 5)              | Python (pytest)                                     |
|-----------------------------|-----------------------------------------------------|
| `@ExtendWith(MockitoExtension.class)` | `# no annotation needed; use pytest-mock`  |
| `@SpringBootTest`           | `# use FastAPI TestClient + conftest fixtures`       |
| `@DataJpaTest`              | `# use db_session fixture from conftest`             |
| `@WebMvcTest`               | `# use client fixture from conftest`                 |
| `@BeforeEach`               | `@pytest.fixture(autouse=True)` or setup in test    |
| `@BeforeAll` (static)       | `@pytest.fixture(scope="class")`                    |
| `@AfterEach`                | `yield` fixture teardown                            |
| `@AfterAll` (static)        | `yield` fixture with class scope teardown           |

### Test Method Mappings

```python
# Java:
# @Test
# @DisplayName("should return user when found")
# void shouldReturnUserWhenFound() {
#     when(userRepo.findById(1L)).thenReturn(Optional.of(user));
#     Optional<User> result = userService.findById(1L);
#     assertThat(result).isPresent();
#     assertThat(result.get().getName()).isEqualTo("Alice");
# }

# Python:
def test_should_return_user_when_found(mock_user_repository):
    """Should return user when found.
    
    Migrated from: UserServiceTest.shouldReturnUserWhenFound()
    """
    # Arrange
    mock_user = User(id=1, name="Alice")
    mock_user_repository.find_by_id.return_value = mock_user

    service = UserService(user_repository=mock_user_repository)

    # Act
    result = service.find_by_id(1)

    # Assert
    assert result is not None
    assert result.name == "Alice"
    mock_user_repository.find_by_id.assert_called_once_with(1)
```

### AssertJ / Hamcrest → pytest assert

| Java Assertion                              | Python Assertion                              |
|---------------------------------------------|-----------------------------------------------|
| `assertThat(x).isEqualTo(y)`               | `assert x == y`                               |
| `assertThat(x).isNotEqualTo(y)`            | `assert x != y`                               |
| `assertThat(x).isNull()`                   | `assert x is None`                            |
| `assertThat(x).isNotNull()`                | `assert x is not None`                        |
| `assertThat(x).isTrue()`                   | `assert x is True`                            |
| `assertThat(x).isFalse()`                  | `assert x is False`                           |
| `assertThat(list).isNotEmpty()`            | `assert len(list) > 0`                        |
| `assertThat(list).hasSize(n)`              | `assert len(list) == n`                       |
| `assertThat(list).contains(x)`             | `assert x in list`                            |
| `assertThat(list).containsExactly(...)`    | `assert list == [...]`                        |
| `assertThat(str).startsWith(prefix)`       | `assert str.startswith(prefix)`               |
| `assertThat(str).contains(sub)`            | `assert sub in str`                           |
| `assertThat(n).isGreaterThan(m)`           | `assert n > m`                                |
| `assertThat(n).isLessThanOrEqualTo(m)`     | `assert n <= m`                               |
| `assertThat(x).isInstanceOf(Cls.class)`    | `assert isinstance(x, Cls)`                   |
| `assertThrows(Ex.class, () -> action())`   | `with pytest.raises(Ex): action()`            |
| `assertDoesNotThrow(() -> action())`       | `action()  # no raises = pass`                |

### Mockito → unittest.mock / pytest-mock

| Java (Mockito)                              | Python (pytest-mock / unittest.mock)          |
|---------------------------------------------|-----------------------------------------------|
| `mock(UserRepo.class)`                      | `MagicMock()` or `mocker.Mock()`              |
| `when(x.method(arg)).thenReturn(val)`       | `x.method.return_value = val`                 |
| `when(x.method()).thenThrow(Ex.class)`      | `x.method.side_effect = Ex()`                 |
| `verify(x).method(arg)`                     | `x.method.assert_called_once_with(arg)`       |
| `verify(x, times(2)).method()`              | `assert x.method.call_count == 2`             |
| `verify(x, never()).method()`               | `x.method.assert_not_called()`                |
| `ArgumentCaptor`                            | `mock.call_args` / `mock.call_args_list`      |
| `@InjectMocks UserService svc`             | `svc = UserService(user_repo=mock_repo)`      |
| `@Mock UserRepository repo`                | `mock_repo = MagicMock()`                     |
| `@Spy`                                      | `unittest.mock.patch` or `MagicMock(wraps=real)` |
| `doNothing().when(x).method()`             | `x.method.return_value = None`                |

---

## Step 5 — Generate API Integration Tests

For each FastAPI router found in the conversion output:

```python
"""
Integration tests for UserRouter.
Migrated from: UserControllerTest.java
Run ID: {run_id}
"""

import pytest
from fastapi.testclient import TestClient

class TestUserRouter:
    """Integration tests for /api/users endpoints."""

    def test_get_user_returns_200_when_exists(self, client, db_session):
        """GET /api/users/{id} returns 200 for existing user."""
        # Arrange: insert test user
        user = User(name="Alice", email="alice@example.com")
        db_session.add(user)
        db_session.flush()

        # Act
        response = client.get(f"/api/users/{user.id}")

        # Assert
        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "Alice"
        assert data["email"] == "alice@example.com"

    def test_get_user_returns_404_when_not_found(self, client):
        """GET /api/users/{id} returns 404 for non-existent user."""
        response = client.get("/api/users/99999")
        assert response.status_code == 404

    def test_create_user_returns_201(self, client):
        """POST /api/users creates a user and returns 201."""
        payload = {"name": "Bob", "email": "bob@example.com", "age": 30}
        response = client.post("/api/users", json=payload)
        assert response.status_code == 201
        data = response.json()
        assert data["name"] == "Bob"
        assert "id" in data

    def test_create_user_returns_422_for_invalid_input(self, client):
        """POST /api/users returns 422 for validation failure."""
        payload = {"name": "", "email": "not-an-email"}
        response = client.post("/api/users", json=payload)
        assert response.status_code == 422
```

---

## Step 6 — Generate Skeleton Tests for Untested Source Files

For any converted Python file with no corresponding Java test:

```python
"""
Auto-generated skeleton tests.
Source: {python_file}
Migrated from: {java_file} (no Java test found)
Run ID: {run_id}

⚠️  SKELETON: These tests are stubs. Implement the test bodies.
"""

import pytest

class Test{ClassName}:
    """Tests for {ClassName}."""

    def test_{method_name}_happy_path(self):
        """Happy path for {method_name}. IMPLEMENT ME."""
        # TODO: arrange
        # TODO: act
        # TODO: assert
        pytest.skip("Skeleton test — not yet implemented")

    def test_{method_name}_edge_case(self):
        """Edge case for {method_name}. IMPLEMENT ME."""
        pytest.skip("Skeleton test — not yet implemented")
```

---

## Step 7 — Generate pytest.ini

```ini
[pytest]
testpaths = tests
python_files = test_*.py
python_classes = Test*
python_functions = test_*
asyncio_mode = auto
log_cli = true
log_cli_level = INFO
addopts = -v --tb=short
```

---

## Step 8 — Write Output Artifacts

Write `migration-artifacts/runs/{run_id}/06-tests/test-plan.json`:

```json
{
  "run_id": "{run_id}",
  "generated_by": "agent-06-test-generator",
  "timestamp": "<ISO8601>",
  "status": "SUCCESS",
  "total_test_files": 0,
  "total_test_cases": 0,
  "migrated_tests": 0,
  "skeleton_tests": 0,
  "unit_tests": 0,
  "integration_tests": 0,
  "test_files": [],
  "blocking_issues": [],
  "warnings": [],
  "validation_passed": true,
  "resume_mode": false,
  "artifacts_consumed": [
    "migration-artifacts/runs/{run_id}/01-java-parse/class-map.json",
    "migration-artifacts/runs/{run_id}/05-conversion/conversion-log.json"
  ],
  "artifacts_produced": [
    "migration-artifacts/runs/{run_id}/06-tests/tests/",
    "migration-artifacts/runs/{run_id}/06-tests/test-plan.json"
  ],
  "confidence_score": 0.0,
  "rollback_to": "agent-05-conversion-executor",
  "next_agent": "agent-07-validator"
}
```

---

## AFTER COMPLETION — EMIT THIS EXACTLY

```
✅ PHASE 6 — TEST GENERATION complete. Run ID: {run_id}
Test files generated: {total_test_files}
Test cases: {total_test_cases} ({migrated_tests} migrated, {skeleton_tests} skeletons)
Unit: {unit_tests} | Integration: {integration_tests}

─────────────────────────────────────────
▶ To continue → paste this prompt:
#file:copilot-agents/agent-07-validator.md
Run ID: {run_id}. Continue migration pipeline.
─────────────────────────────────────────

If invoked from master-agent, proceed directly without emitting the prompt block.
```
