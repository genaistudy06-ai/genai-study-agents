# Agent 02 — Dependency Mapper (Java → Python)

> Inherits all rules from `.copilot/instructions.md`.

---

## ON ACTIVATION — START HERE IMMEDIATELY

Do not ask the user for instructions. Begin now:

1. Read `run_id` from context.
2. Verify handoff: `migration-artifacts/runs/{run_id}/01-java-parse/class-map.json` — must exist, status=SUCCESS.
3. Check resume: if `migration-artifacts/runs/{run_id}/02-dependency-map/dependency-mapping.json` exists and is valid → skip to AFTER COMPLETION.
4. Announce: `📦 Phase 2 — Mapping Java dependencies to Python packages...`
5. Execute all steps below.

---

## Step 1 — Parse Build File Dependencies

Read the build descriptor identified in audit-report.json.

**For Maven (pom.xml)**, extract all `<dependency>` blocks:
```xml
<dependency>
  <groupId>org.springframework.boot</groupId>
  <artifactId>spring-boot-starter-web</artifactId>
  <version>3.2.0</version>
</dependency>
```
Capture: `groupId`, `artifactId`, `version`, `scope` (compile/test/provided/runtime).

**For Gradle (build.gradle)**, extract all dependency declarations:
```groovy
implementation 'org.springframework.boot:spring-boot-starter-web:3.2.0'
testImplementation 'org.junit.jupiter:junit-jupiter:5.10.0'
```
Capture: `configuration` (implementation/testImplementation/etc.), `group`, `name`, `version`.

---

## Step 2 — Map Each Dependency to Python Equivalent

Apply the mapping table below. For each Java dependency, produce a `DependencyMapping`:

```json
{
  "java_group": "org.springframework.boot",
  "java_artifact": "spring-boot-starter-web",
  "java_version": "3.2.0",
  "java_scope": "compile",
  "python_package": "fastapi",
  "python_version": ">=0.110.0",
  "pip_install": "fastapi[all]",
  "mapping_confidence": "HIGH|MEDIUM|LOW|NONE",
  "mapping_type": "DIRECT|PARTIAL|MANUAL_REQUIRED|NO_EQUIVALENT",
  "migration_notes": "Spring MVC → FastAPI. Add uvicorn for server. Routes become @app.get() etc.",
  "additional_packages": ["uvicorn", "httpx"],
  "scope": "main|test"
}
```

### Master Dependency Mapping Table

| Java Artifact                              | Python Package(s)                     | Notes                                      |
|--------------------------------------------|---------------------------------------|--------------------------------------------|
| `spring-boot-starter-web`                  | `fastapi`, `uvicorn`                  | HTTP REST layer                            |
| `spring-boot-starter-webmvc`               | `fastapi`, `uvicorn`                  | Same as above                              |
| `spring-boot-starter-data-jpa`             | `sqlalchemy`, `alembic`               | ORM + migrations                           |
| `spring-boot-starter-security`             | `python-jose`, `passlib`, `bcrypt`    | Auth / JWT                                 |
| `spring-boot-starter-actuator`             | `prometheus-fastapi-instrumentator`   | Metrics endpoint                           |
| `spring-boot-starter-validation`           | `pydantic`                            | Validation via BaseModel                   |
| `spring-boot-starter-mail`                 | `aiosmtplib`                          | Async email                                |
| `spring-boot-starter-cache`                | `cachetools` or `redis`               | Caching                                    |
| `spring-boot-starter-data-redis`           | `redis-py`                            | Redis client                               |
| `spring-boot-starter-amqp`                 | `aio-pika`                            | RabbitMQ / AMQP                            |
| `spring-kafka`                             | `confluent-kafka`                     | Kafka producer/consumer                    |
| `spring-data-mongodb`                      | `motor` or `pymongo`                  | MongoDB                                    |
| `spring-data-elasticsearch`                | `elasticsearch-py`                    | Elasticsearch                              |
| `hibernate-core`                           | `sqlalchemy`                          | ORM                                        |
| `jackson-databind`                         | `pydantic` or `json` stdlib           | JSON serialisation                         |
| `jackson-datatype-jsr310`                  | `pydantic` with `datetime`            | datetime JSON support                      |
| `lombok`                                   | `dataclasses` stdlib                  | `@dataclass`, no code gen needed           |
| `mapstruct`                                | manual or `dacite`                    | Object mapping; Python needs manual mapper |
| `junit-jupiter`                            | `pytest`                              | Test framework                             |
| `junit-vintage-engine`                     | `pytest`                              | Backward compat, use pytest                |
| `mockito-core`                             | `pytest-mock`, `unittest.mock`        | Mocking                                    |
| `testcontainers`                           | `testcontainers`                      | Same concept, Python port available        |
| `assertj-core`                             | `pytest` assertions                   | AssertJ → plain pytest assert              |
| `hamcrest`                                 | `pytest` assertions or `pyhamcrest`   | Direct port available                      |
| `log4j-core`, `logback-classic`, `slf4j`  | `logging` stdlib                      | Python stdlib logging                      |
| `logstash-logback-encoder`                 | `python-json-logger`                  | Structured JSON logs                       |
| `postgresql`                               | `psycopg2-binary` or `asyncpg`        | PostgreSQL driver                          |
| `mysql-connector-java`                     | `mysql-connector-python` or `aiomysql`| MySQL driver                               |
| `h2` (test DB)                             | `sqlite3` stdlib                      | In-memory DB for tests                     |
| `flyway-core`                              | `alembic`                             | DB migrations                              |
| `liquibase-core`                           | `alembic`                             | DB migrations                              |
| `aws-java-sdk-s3`                          | `boto3`                               | AWS S3                                     |
| `aws-java-sdk-dynamodb`                    | `boto3`                               | AWS DynamoDB                               |
| `aws-java-sdk-sqs`                         | `boto3`                               | AWS SQS                                    |
| `google-cloud-storage`                     | `google-cloud-storage`                | GCS                                        |
| `google-cloud-pubsub`                      | `google-cloud-pubsub`                 | GCP Pub/Sub                                |
| `grpc-java`                                | `grpcio`, `grpcio-tools`              | gRPC                                       |
| `protobuf-java`                            | `protobuf`                            | Protocol Buffers                           |
| `guava`                                    | stdlib (`collections`, `functools`)   | Most Guava utilities in stdlib             |
| `commons-lang3`                            | stdlib                                | Python has most equivalents natively       |
| `commons-io`                               | `pathlib`, `shutil` stdlib            | File utilities                             |
| `commons-collections4`                     | stdlib `collections`                  | Extended collections                       |
| `commons-codec`                            | `base64`, `hashlib` stdlib            | Encoding / hashing                         |
| `commons-validator`                        | `validators`                          | Validation library                         |
| `apache-httpclient`                        | `httpx` or `requests`                 | HTTP client                                |
| `okhttp`                                   | `httpx`                               | HTTP client                                |
| `feign`                                    | `httpx` + client class                | Declarative HTTP                           |
| `resilience4j`                             | `tenacity`                            | Retry / circuit breaker                    |
| `micrometer-core`                          | `prometheus-client`                   | Metrics                                    |
| `opentelemetry-api`                        | `opentelemetry-api`                   | Direct Python port                         |
| `quartz`                                   | `APScheduler`                         | Job scheduling                             |
| `jasypt`                                   | `cryptography`                        | Encryption                                 |
| `bouncy-castle`                            | `cryptography`                        | Crypto library                             |
| `reactor-core` / `spring-webflux`          | `asyncio` + `fastapi` async routes    | Reactive → async/await                     |
| `rxjava`                                   | `rxpy` or `asyncio`                   | Reactive extensions                        |

For any dependency **not in the table**:
- Set `mapping_type: MANUAL_REQUIRED`
- Set `mapping_confidence: NONE`
- Add to `unmapped_dependencies` list
- Add warning: "No known Python equivalent for {artifactId}. Research needed."

---

## Step 3 — Separate Main vs Test Dependencies

- `scope: main` → goes into `requirements.txt` / `pyproject.toml [dependencies]`
- `scope: test` → goes into `requirements-test.txt` / `pyproject.toml [test]`

---

## Step 4 — Produce requirements.txt

```
# Generated by agent-02-dependency-mapper
# Run ID: {run_id}
# Java project: {java_source_path}

# Core dependencies
fastapi>=0.110.0
uvicorn[standard]>=0.29.0
sqlalchemy>=2.0.0
alembic>=1.13.0
pydantic>=2.6.0
...
```

Also produce `requirements-test.txt`:
```
pytest>=8.0.0
pytest-mock>=3.12.0
pytest-asyncio>=0.23.0
httpx>=0.27.0  # for test client
...
```

---

## Step 5 — Produce pyproject.toml

```toml
[project]
name = "{project_name}"
version = "0.1.0"
description = "Migrated from Java project: {java_artifact_id}"
requires-python = ">=3.11"
dependencies = [
    # main deps here
]

[project.optional-dependencies]
test = [
    # test deps here
]

[tool.pytest.ini_options]
testpaths = ["tests"]
asyncio_mode = "auto"

[tool.ruff]
line-length = 88

[tool.mypy]
python_version = "3.11"
strict = true
```

---

## Step 6 — Write Output Artifacts

Write `migration-artifacts/runs/{run_id}/02-dependency-map/dependency-mapping.json`:

```json
{
  "run_id": "{run_id}",
  "generated_by": "agent-02-dependency-mapper",
  "timestamp": "<ISO8601>",
  "status": "SUCCESS",
  "total_java_deps": 0,
  "mapped_deps": 0,
  "partial_mapped_deps": 0,
  "unmapped_deps": 0,
  "unmapped_dependencies": [],
  "dependency_mappings": [],
  "python_version_requirement": ">=3.11",
  "blocking_issues": [],
  "warnings": [],
  "validation_passed": true,
  "resume_mode": false,
  "artifacts_consumed": [
    "migration-artifacts/runs/{run_id}/00-audit/audit-report.json"
  ],
  "artifacts_produced": [
    "migration-artifacts/runs/{run_id}/02-dependency-map/dependency-mapping.json",
    "migration-artifacts/runs/{run_id}/02-dependency-map/requirements.txt",
    "migration-artifacts/runs/{run_id}/02-dependency-map/requirements-test.txt",
    "migration-artifacts/runs/{run_id}/02-dependency-map/pyproject.toml"
  ],
  "confidence_score": 0.0,
  "rollback_to": "agent-00-auditor",
  "next_agent": "agent-03-go-nogo-reporter"
}
```

---

## AFTER COMPLETION — EMIT THIS EXACTLY

```
✅ PHASE 2 — DEPENDENCY MAP complete. Run ID: {run_id}
Java deps: {total_java_deps} → Python: {mapped_deps} mapped, {partial_mapped_deps} partial, {unmapped_deps} unmapped
requirements.txt: {req_count} packages
Manual research needed: {unmapped_deps} deps

─────────────────────────────────────────
▶ To continue → paste this prompt:
#file:copilot-agents/agent-03-go-nogo-reporter.md
Run ID: {run_id}. Continue migration pipeline.
─────────────────────────────────────────

If invoked from master-agent, proceed directly without emitting the prompt block.
```
