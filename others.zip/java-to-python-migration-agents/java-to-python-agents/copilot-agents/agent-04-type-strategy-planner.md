# Agent 04 — Type & Pattern Strategy Planner

> Inherits all rules from `.copilot/instructions.md`.

---

## ON ACTIVATION — START HERE IMMEDIATELY

Do not ask the user for instructions. Begin now:

1. Read `run_id` from context.
2. Verify handoff: `migration-artifacts/runs/{run_id}/03-go-nogo/go-nogo-report.json` — must exist, status=SUCCESS, recommendation ≠ NO-GO.
3. Check resume: if `migration-artifacts/runs/{run_id}/04-type-strategy/type-mapping.json` exists and is valid → skip to AFTER COMPLETION.
4. Announce: `🗺️ Phase 4 — Building type and pattern strategy...`
5. Execute all steps below.

---

## Step 1 — Load Class Map

Read `migration-artifacts/runs/{run_id}/01-java-parse/class-map.json`.
For every class and method, extract all Java types found in fields, method params, and return types.

---

## Step 2 — Resolve Each Unique Java Type

Build a lookup table: `java_type_string → TypeResolution`.

For each unique type string found in the class map:

```json
{
  "java_type": "List<UserDTO>",
  "python_type": "list[UserDTO]",
  "import_needed": "from example.dto.user_dto import UserDTO",
  "typing_imports": [],
  "requires_TypeVar": false,
  "resolution_strategy": "DIRECT|GENERIC|OPTIONAL|UNION|TYPEVAR|ANY|CALLABLE",
  "notes": ""
}
```

### Resolution Rules

**Primitives / Wrappers** → direct mapping per global table in instructions.md.

**Generic Collections**:
```
List<T>           → list[T]                (typing_imports: [])
ArrayList<T>      → list[T]
LinkedList<T>     → collections.deque[T]   (import collections)
Map<K,V>          → dict[K, V]
HashMap<K,V>      → dict[K, V]
LinkedHashMap<K,V>→ dict[K, V]             (Python dict preserves insertion order ≥3.7)
TreeMap<K,V>      → dict[K, V]             (note: Python dict not sorted; use SortedDict if needed)
Set<T>            → set[T]
HashSet<T>        → set[T]
TreeSet<T>        → SortedSet or sorted set (note: no stdlib sorted set)
LinkedHashSet<T>  → dict.fromkeys(...)     (preserve order via dict trick)
Queue<T>          → collections.deque[T]
Deque<T>          → collections.deque[T]
Stack<T>          → list[T]               (use .append() / .pop())
```

**Optional**:
```
Optional<T>       → T | None    (Python 3.10+) OR Optional[T] (typing)
```

**Functional Types**:
```
Function<A,B>     → Callable[[A], B]
Supplier<T>       → Callable[[], T]
Consumer<T>       → Callable[[T], None]
Predicate<T>      → Callable[[T], bool]
BiFunction<A,B,C> → Callable[[A, B], C]
Runnable          → Callable[[], None]
Callable<T>       → Callable[[], T]
```

**Arrays**:
```
T[]               → list[T]
int[]             → list[int]
byte[]            → bytes
char[]            → list[str]
```

**Generics with Bounds**:
```
<T extends Comparable<T>> → T = TypeVar('T', bound='Comparable')
<T extends Number>        → T = TypeVar('T', int, float)
<? extends T>             → T   (use contravariance comment)
<? super T>               → T   (use covariance comment)
```

**Java Standard Library Types**:
```
java.time.LocalDate       → datetime.date
java.time.LocalDateTime   → datetime.datetime
java.time.ZonedDateTime   → datetime.datetime (with tzinfo)
java.time.Duration        → datetime.timedelta
java.time.Instant         → datetime.datetime (UTC)
java.time.LocalTime       → datetime.time
java.math.BigDecimal      → decimal.Decimal
java.math.BigInteger      → int (Python int is arbitrary precision)
java.util.UUID            → uuid.UUID
java.util.Date            → datetime.datetime (deprecated in Java; use datetime)
java.net.URI              → str or urllib.parse.ParseResult
java.net.URL              → str
java.io.File              → pathlib.Path
java.io.InputStream       → io.IOBase
java.io.OutputStream      → io.IOBase
java.io.Reader            → io.TextIOBase
java.io.Writer            → io.TextIOBase
java.nio.file.Path        → pathlib.Path
```

**Spring / Framework Types**:
```
ResponseEntity<T>         → JSONResponse / Response (FastAPI)
HttpStatus                → int (HTTP status code) or fastapi.status.*
MultiValueMap<K,V>        → dict[str, list[str]]
Page<T>                   → custom Page[T] dataclass
Pageable                  → custom Pageable dataclass
Sort                      → str or list[str]
```

---

## Step 3 — Plan OOP Pattern Conversions

For each class in class-map.json, select the Python OOP strategy:

### Strategy Selection Logic

```
if class_type == "INTERFACE":
    if has_only_abstract_methods:
        strategy = "PROTOCOL"         # typing.Protocol — structural subtyping
    else:
        strategy = "ABC"              # abstract base class with some defaults

if class_type == "ABSTRACT_CLASS":
    strategy = "ABC"                  # from abc import ABC, abstractmethod

if class_type == "ENUM":
    strategy = "ENUM"                 # from enum import Enum, auto

if class_type == "RECORD":            # Java 14+ record
    strategy = "FROZEN_DATACLASS"     # @dataclass(frozen=True)

if class_type == "CLASS":
    if has_lombok_@Data or has_lombok_@Value:
        strategy = "DATACLASS"
    elif has_lombok_@Builder:
        strategy = "DATACLASS_WITH_BUILDER"
    elif is_spring_@Entity:
        strategy = "SQLALCHEMY_MODEL"
    elif is_spring_@RestController or is_spring_@Controller:
        strategy = "FASTAPI_ROUTER"
    elif is_spring_@Service or is_spring_@Component:
        strategy = "SERVICE_CLASS"    # plain class with DI via __init__
    elif is_spring_@Repository:
        strategy = "REPOSITORY_CLASS" # SQLAlchemy session wrapper
    elif is_spring_@Configuration:
        strategy = "CONFIG_CLASS"     # plain class or Pydantic Settings
    else:
        strategy = "PLAIN_CLASS"
```

Produce per-class strategy record:
```json
{
  "java_class": "UserService",
  "python_file": "src/example/service/user_service.py",
  "oop_strategy": "SERVICE_CLASS",
  "base_classes": ["ABC"],
  "metaclass": null,
  "use_dataclass": false,
  "use_pydantic": false,
  "use_sqlalchemy": false,
  "use_protocol": false,
  "di_pattern": "CONSTRUCTOR_INJECTION",
  "imports_needed": ["from abc import ABC, abstractmethod"],
  "notes": []
}
```

---

## Step 4 — Plan Spring Dependency Injection → Python DI

Java Spring uses annotation-based DI (`@Autowired`, `@Inject`). Python needs explicit DI.

For each `@Service` / `@Component` / `@Repository` class:
1. Identify all `@Autowired` or constructor-injected fields.
2. Map to Python `__init__` parameters with type hints.
3. If the project uses Spring Boot's auto-wiring at scale → recommend `dependency-injector` library.
4. For simpler projects → manual constructor DI (no library needed).

Generate a DI wiring plan:
```json
{
  "class": "UserService",
  "dependencies": [
    {"field": "userRepository", "type": "UserRepository", "injection": "CONSTRUCTOR"},
    {"field": "emailService", "type": "EmailService", "injection": "CONSTRUCTOR"}
  ],
  "python_init_signature": "def __init__(self, user_repository: UserRepository, email_service: EmailService) -> None:",
  "use_di_framework": false
}
```

---

## Step 5 — Plan Spring MVC → FastAPI Route Strategy

For each `@RestController` class:

```json
{
  "java_class": "UserController",
  "python_file": "src/example/api/user_router.py",
  "fastapi_router_variable": "router",
  "base_path": "/api/users",
  "routes": [
    {
      "java_method": "getUser",
      "python_method": "get_user",
      "http_method": "GET",
      "path": "/{id}",
      "path_params": ["id: int"],
      "query_params": [],
      "request_body": null,
      "response_model": "UserDTO",
      "status_code": 200,
      "fastapi_decorator": "@router.get('/{id}', response_model=UserDTO)"
    }
  ]
}
```

Spring annotation → FastAPI mapping:
```
@GetMapping     → @router.get
@PostMapping    → @router.post
@PutMapping     → @router.put
@DeleteMapping  → @router.delete
@PatchMapping   → @router.patch
@RequestParam   → Query(...)
@PathVariable   → path param in signature
@RequestBody    → request body with Pydantic model
@RequestHeader  → Header(...)
@ResponseStatus → status_code parameter
```

---

## Step 6 — Plan JPA Entity → SQLAlchemy Model Strategy

For each `@Entity` class:

```json
{
  "java_class": "User",
  "python_file": "src/example/models/user.py",
  "table_name": "users",
  "sqlalchemy_base": "Base",
  "fields": [
    {
      "java_field": "id",
      "column_name": "id",
      "java_type": "Long",
      "python_type": "int",
      "sqlalchemy_type": "BigInteger",
      "is_primary_key": true,
      "nullable": false,
      "constraints": ["@GeneratedValue(strategy=AUTO)"]
    }
  ],
  "relationships": [
    {
      "field_name": "orders",
      "relationship_type": "ONE_TO_MANY",
      "target_class": "Order",
      "back_populates": "user",
      "cascade": "all, delete-orphan"
    }
  ]
}
```

JPA → SQLAlchemy type mapping:
```
@Id + @GeneratedValue  → Column(BigInteger, primary_key=True, autoincrement=True)
@Column(nullable=false)→ Column(..., nullable=False)
@Column(unique=true)   → Column(..., unique=True)
@OneToMany             → relationship(..., back_populates=...)
@ManyToOne             → relationship(...) with ForeignKey
@ManyToMany            → relationship with secondary table
@JoinColumn            → ForeignKey(...)
@Temporal              → DateTime column
@Lob                   → LargeBinary or Text
@Embedded              → inline fields or separate table
```

---

## Step 7 — Plan Exception Strategy

Java checked exceptions → Python unchecked:

For every `throws` declaration found in class-map.json:
1. If it's a standard Java exception → map to Python equivalent.
2. If it's a custom application exception → create a Python custom exception class.

```
IOException              → IOError / OSError
SQLException             → sqlalchemy.exc.SQLAlchemyError
IllegalArgumentException → ValueError
IllegalStateException    → RuntimeError
NullPointerException     → AttributeError or explicit None check
IndexOutOfBoundsException→ IndexError
ClassCastException       → TypeError
UnsupportedOperationException → NotImplementedError
NumberFormatException    → ValueError
RuntimeException         → Exception
Exception (checked)      → Exception (all Python exceptions unchecked)
```

Custom exception plan:
```python
# For each custom Java exception XxxException
class XxxException(Exception):
    """Migrated from Java XxxException."""
    def __init__(self, message: str, cause: Exception | None = None) -> None:
        super().__init__(message)
        self.cause = cause
```

---

## Step 8 — Write Output Artifacts

Write `migration-artifacts/runs/{run_id}/04-type-strategy/type-mapping.json` (type resolution table).
Write `migration-artifacts/runs/{run_id}/04-type-strategy/pattern-strategy.json` (per-class OOP, DI, route, entity, exception strategies).

Standard output block:
```json
{
  "run_id": "{run_id}",
  "generated_by": "agent-04-type-strategy-planner",
  "timestamp": "<ISO8601>",
  "status": "SUCCESS",
  "unique_types_resolved": 0,
  "types_needing_TypeVar": 0,
  "types_mapped_to_Any": 0,
  "classes_with_strategy": 0,
  "fastapi_routers_planned": 0,
  "sqlalchemy_models_planned": 0,
  "custom_exceptions_planned": 0,
  "di_wiring_plan_count": 0,
  "blocking_issues": [],
  "warnings": [],
  "validation_passed": true,
  "resume_mode": false,
  "artifacts_consumed": [
    "migration-artifacts/runs/{run_id}/01-java-parse/class-map.json",
    "migration-artifacts/runs/{run_id}/02-dependency-map/dependency-mapping.json"
  ],
  "artifacts_produced": [
    "migration-artifacts/runs/{run_id}/04-type-strategy/type-mapping.json",
    "migration-artifacts/runs/{run_id}/04-type-strategy/pattern-strategy.json"
  ],
  "confidence_score": 0.0,
  "rollback_to": "agent-00-auditor",
  "next_agent": "agent-05-conversion-executor"
}
```

---

## AFTER COMPLETION — EMIT THIS EXACTLY

```
✅ PHASE 4 — TYPE STRATEGY complete. Run ID: {run_id}
Types resolved: {unique_types_resolved} | TypeVars needed: {types_needing_TypeVar}
FastAPI routers planned: {fastapi_routers_planned}
SQLAlchemy models planned: {sqlalchemy_models_planned}
Custom exceptions: {custom_exceptions_planned}

─────────────────────────────────────────
▶ To continue → paste this prompt:
#file:copilot-agents/agent-05-conversion-executor.md
Run ID: {run_id}. Continue migration pipeline.
─────────────────────────────────────────

If invoked from master-agent, proceed directly without emitting the prompt block.
```
