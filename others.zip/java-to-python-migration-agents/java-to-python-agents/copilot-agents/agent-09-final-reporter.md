# Agent 09 — Final Reporter

> Inherits all rules from `.copilot/instructions.md`.

---

## ON ACTIVATION — START HERE IMMEDIATELY

Do not ask the user for instructions. Begin now:

1. Read `run_id` from context.
2. Verify handoff: `migration-artifacts/runs/{run_id}/08-review/review-report.json` — must exist, status=SUCCESS.
3. Check resume: if `migration-artifacts/runs/{run_id}/09-final-report/final-report.md` exists and is valid → skip to AFTER COMPLETION.
4. Announce: `📄 Phase 9 — Generating final migration report...`
5. Execute all steps below.

---

## Step 1 — Load All Artifacts

Read the following in full:
- `00-audit/audit-report.json`
- `01-java-parse/class-map.json`
- `02-dependency-map/dependency-mapping.json`
- `03-go-nogo/go-nogo-report.json`
- `04-type-strategy/pattern-strategy.json`
- `05-conversion/conversion-log.json`
- `06-tests/test-plan.json`
- `07-validation/validation-report.json`
- `08-review/review-report.json`

---

## Step 2 — Write final-report.md

Write `migration-artifacts/runs/{run_id}/09-final-report/final-report.md`:

```markdown
# Java → Python Migration Report

| Field              | Value                          |
|--------------------|-------------------------------|
| **Run ID**         | {run_id}                      |
| **Date**           | {timestamp}                   |
| **Java source**    | {java_source_path}            |
| **Migration grade**| {grade} ({overall_score}/10)  |
| **Status**         | {COMPLETE / COMPLETE WITH WARNINGS / PARTIAL} |

---

## Executive Summary

{2–4 paragraph narrative summarizing:
- What was migrated (size, complexity, frameworks)
- How the migration went (any major hurdles)
- Current state (test pass rate, files needing review)
- What needs to happen before production cutover
}

---

## Migration Statistics

| Metric                         | Value           |
|-------------------------------|-----------------|
| Java source files              | {n}             |
| Java test files                | {n}             |
| Total Java lines               | {n}             |
| Python files generated         | {n}             |
| Total Python lines             | {n}             |
| Code size ratio (Py/Java)      | {ratio}         |
| Java dependencies              | {n}             |
| Python packages required       | {n}             |
| Unmapped dependencies          | {n}             |
| Conversion: SUCCESS            | {n} files       |
| Conversion: NEEDS_REVIEW       | {n} files       |
| Conversion: FAILED             | {n} files       |
| pytest tests generated         | {n}             |
| pytest passed                  | {n} ({rate}%)   |
| pytest failed                  | {n}             |
| pytest skipped (skeletons)     | {n}             |
| mypy errors                    | {n}             |
| ruff violations                | {n}             |

---

## Framework Migration Summary

| Java Framework         | Python Replacement        | Status              |
|------------------------|---------------------------|---------------------|
| Spring Boot (REST)     | FastAPI + Uvicorn         | {COMPLETE/PARTIAL}  |
| Spring Data JPA        | SQLAlchemy 2.0 + Alembic  | {COMPLETE/PARTIAL}  |
| Spring Security        | FastAPI auth + python-jose| {COMPLETE/PARTIAL}  |
| JUnit 5 + Mockito      | pytest + unittest.mock    | {COMPLETE/PARTIAL}  |
| Lombok                 | @dataclass                | {COMPLETE/PARTIAL}  |
| {others detected...}   | {mapped to...}            | {status}            |

---

## Dependency Mapping Summary

### Successfully Mapped ({n} packages)
{list top 10 most significant mapped packages}

### Unmapped Dependencies ({n} packages)
{list each unmapped dep with recommended action}

---

## Files Requiring Manual Review

### Priority 1 — Fix Before Production ({n} files)
{list with file path, reason, and suggested fix}

### Priority 2 — Fix Before Production Recommended ({n} files)
{list with file path and reason}

### Priority 3 — Optional Improvements ({n} files)
{list skeleton tests and minor issues}

---

## Test Coverage

| Test Type          | Generated | Migrated from Java | Skeleton (TODO) |
|--------------------|-----------|-------------------|-----------------|
| Unit tests         | {n}       | {n}               | {n}             |
| Integration tests  | {n}       | {n}               | {n}             |
| **Total**          | {n}       | {n}               | {n}             |

**Skeleton tests** are stubs with `pytest.skip()` — implement before production.

---

## Validation Results

| Check              | Result                          |
|--------------------|---------------------------------|
| Syntax (AST parse) | {pass_count}/{total} passed     |
| mypy               | {error_count} errors            |
| ruff               | {violation_count} violations    |
| pytest             | {passed}/{total} ({rate}%)      |
| Overall health     | {HEALTHY / DEGRADED / CRITICAL} |

---

## Patterns Converted

| Java Pattern               | Python Equivalent Used        | Occurrences |
|----------------------------|-------------------------------|-------------|
| Java Streams               | List comprehensions / generators | {n}       |
| Optional<T>                | T \| None                     | {n}         |
| Lombok @Data               | @dataclass                    | {n}         |
| Builder pattern            | @dataclass / kwargs           | {n}         |
| try-with-resources         | with statement                | {n}         |
| String.format              | f-strings                     | {n}         |
| @RestController            | FastAPI APIRouter             | {n}         |
| @Entity                    | SQLAlchemy ORM Model          | {n}         |
| synchronized               | threading.Lock                | {n}         |
| Checked exceptions         | Unchecked + docstring         | {n}         |
| CompletableFuture          | async/await                   | {n}         |

---

## Output Artifacts

| Artifact                              | Path                                                      |
|---------------------------------------|-----------------------------------------------------------|
| Converted Python source               | `migration-artifacts/runs/{run_id}/05-conversion/src/`    |
| Generated tests                       | `migration-artifacts/runs/{run_id}/06-tests/tests/`       |
| requirements.txt                      | `migration-artifacts/runs/{run_id}/02-dependency-map/`    |
| pyproject.toml                        | `migration-artifacts/runs/{run_id}/02-dependency-map/`    |
| Cutover plan                          | `migration-artifacts/runs/{run_id}/08-review/cutover-plan.md` |
| Rollback plan                         | `migration-artifacts/runs/{run_id}/08-review/rollback-plan.md` |
| Validation report                     | `migration-artifacts/runs/{run_id}/07-validation/validation-report.json` |
| pytest output                         | `migration-artifacts/runs/{run_id}/07-validation/pytest-output.txt` |

---

## Next Steps

### Immediate (before any deployment)
1. Fix all Priority 1 files listed above.
2. Install dependencies: `pip install -r migration-artifacts/runs/{run_id}/02-dependency-map/requirements.txt`
3. Configure `.env` from the environment variable mapping in the cutover plan.
4. Run Alembic migration: `alembic upgrade head`
5. Run full test suite: `pytest migration-artifacts/runs/{run_id}/06-tests/tests/ -v`

### Short-term (before production)
6. Implement skeleton tests (Priority 3 list).
7. Run `mypy --strict src/` and fix remaining type errors.
8. Run `ruff check --fix src/` for auto-fixable style issues.
9. Load test the FastAPI service with Locust.
10. Validate API contract against original Java Swagger/OpenAPI spec.

### Deployment
11. Follow the cutover plan: `08-review/cutover-plan.md`
12. Shadow traffic test for 24–48 hours.
13. Canary rollout: 5% → 25% → 50% → 100%.
14. Keep Java service on standby for 1 week post-cutover.

---

## Known Limitations of Automated Migration

The following require manual attention regardless of migration grade:

1. **Business logic in complex conditionals** — automated conversion preserves structure but cannot verify business semantics. Read every complex method.
2. **Security-sensitive code** — password hashing, token validation, and auth flows must be manually audited.
3. **Database transactions** — SQLAlchemy transaction boundaries may differ from Hibernate's flush/commit model. Test transaction rollback scenarios explicitly.
4. **Concurrency** — Python's GIL means CPU-bound concurrent code performs differently. Evaluate whether `asyncio`, `threading`, or `multiprocessing` is appropriate for each concurrent component.
5. **Performance** — Python is slower than Java for CPU-intensive tasks. Profile with `py-spy` after deployment.
6. **JNI native methods** — any `native` Java methods must be re-implemented from scratch.
7. **Reflection-based code** — Spring's heavy use of reflection is replaced by explicit Python. Verify all dependency injection wiring.

---

*Report generated by Java → Python Migration Pipeline*
*agent-09-final-reporter | Run ID: {run_id}*
```

---

## Step 3 — Write final-summary.json

```json
{
  "run_id": "{run_id}",
  "generated_by": "agent-09-final-reporter",
  "timestamp": "<ISO8601>",
  "status": "SUCCESS",
  "migration_grade": "A|B|C|D|F",
  "overall_score": 0.0,
  "java_source_path": "<path>",
  "source_files_converted": 0,
  "test_files_generated": 0,
  "pytest_pass_rate": 0.0,
  "files_needing_manual_review": 0,
  "pipeline_complete": true,
  "blocking_issues": [],
  "warnings": [],
  "validation_passed": true,
  "resume_mode": false,
  "artifacts_consumed": ["all prior phase artifacts"],
  "artifacts_produced": [
    "migration-artifacts/runs/{run_id}/09-final-report/final-report.md",
    "migration-artifacts/runs/{run_id}/09-final-report/final-summary.json"
  ],
  "confidence_score": 0.0,
  "rollback_to": null,
  "next_agent": null
}
```

---

## AFTER COMPLETION — EMIT THIS EXACTLY

```
✅ PIPELINE COMPLETE. Run ID: {run_id}

Migration Grade: {grade} ({overall_score}/10)
Converted source: migration-artifacts/runs/{run_id}/05-conversion/src/
Final report:     migration-artifacts/runs/{run_id}/09-final-report/final-report.md
Cutover plan:     migration-artifacts/runs/{run_id}/08-review/cutover-plan.md

─────────────────────────────────────────
Next: Fix Priority 1 files, run tests, follow cutover plan.
─────────────────────────────────────────
```
