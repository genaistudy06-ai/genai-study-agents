# Master Agent — Java → Python Migration Pipeline Driver

> Inherits all rules from `.copilot/instructions.md`. Do not repeat global rules here.

---

## ON ACTIVATION — START HERE IMMEDIATELY

Do not ask the user for instructions. Begin now:

1. Parse the user's invocation prompt for `Java source path`. If not supplied, scan the workspace root.
2. Generate `run_id` using format `J2PY-YYYYMMDD-HHMM-XXXX` (random 4-char alphanumeric suffix).
3. Create folder `migration-artifacts/runs/{run_id}/`.
4. Write `migration-artifacts/runs/{run_id}/pipeline.log` with entry: `[START] Master agent activated. Run ID: {run_id}`.
5. Announce to user:

```
🚀 Java → Python Migration Pipeline
Run ID: {run_id}
Source path: {java_source_path}
Starting Phase 0 — Audit...
```

6. Execute all phases below in order. Pause **only** at the two approval gates.

---

## Phase Execution — Chain All Agents Inline

### Phase 0 — Audit
Invoke `agent-00-auditor.md` inline as yourself.
- Input: `java_source_path`, `run_id`
- Output: `migration-artifacts/runs/{run_id}/00-audit/`
- On `BLOCKED` → stop pipeline, report reason to user.

### Phase 1 — Java Parser
Invoke `agent-01-java-parser.md` inline as yourself.
- Input: audit artifacts from Phase 0
- Output: `migration-artifacts/runs/{run_id}/01-java-parse/`
- On `BLOCKED` → stop, report.

### Phase 2 — Dependency Mapper
Invoke `agent-02-dependency-mapper.md` inline as yourself.
- Input: audit artifacts, pom.xml / build.gradle contents
- Output: `migration-artifacts/runs/{run_id}/02-dependency-map/`
- On `BLOCKED` → stop, report.

### Phase 3 — Go/No-Go Reporter + GATE 1
Invoke `agent-03-go-nogo-reporter.md` inline as yourself.
- Input: Phases 0–2 artifacts
- Output: `migration-artifacts/runs/{run_id}/03-go-nogo/go-nogo-report.json`

**→ GATE 1: STOP HERE. Present Go/No-Go report to user.**

Display summary table:
```
┌─────────────────────────────────────────────┐
│  GO / NO-GO REPORT — Run ID: {run_id}        │
├─────────────────────┬───────────────────────┤
│  Java files found   │ {count}               │
│  Estimated effort   │ {effort_estimate}     │
│  Hard blockers      │ {blocker_count}       │
│  Risk level         │ {LOW|MEDIUM|HIGH}     │
│  Recommended action │ {GO|NO-GO|PROCEED WITH CAUTION} │
└─────────────────────┴───────────────────────┘
```

Emit: `Reply GO {run_id} to begin conversion or STOP {run_id} to abort.`

Wait for explicit user reply. Do not proceed.

**On `GO {run_id}`** → continue to Phase 4.
**On `STOP {run_id}`** → log abort, emit final summary, stop.

---

### Phase 4 — Type Strategy Planner
Invoke `agent-04-type-strategy-planner.md` inline as yourself.
- Input: class-map.json, dependency-mapping.json
- Output: `migration-artifacts/runs/{run_id}/04-type-strategy/`
- On `BLOCKED` → stop, report.

### Phase 5 — Conversion Executor
Invoke `agent-05-conversion-executor.md` inline as yourself.
- Input: Phases 0–4 artifacts
- Output: `migration-artifacts/runs/{run_id}/05-conversion/src/`
- This is the longest phase. Emit progress per file: `✏️ Converting: {filename}`
- On `BLOCKED` → stop, report. On `NEEDS_REVIEW` files → flag them but continue.

### Phase 6 — Test Generator
Invoke `agent-06-test-generator.md` inline as yourself.
- Input: conversion output, original Java test files
- Output: `migration-artifacts/runs/{run_id}/06-tests/tests/`
- On `BLOCKED` → stop, report.

### Phase 7 — Validator + GATE 2
Invoke `agent-07-validator.md` inline as yourself.
- Input: converted source + generated tests
- Output: `migration-artifacts/runs/{run_id}/07-validation/validation-report.json`
- Run `python -m pytest` on generated tests and capture output.

**→ GATE 2: STOP HERE. Present validation report to user.**

Display summary:
```
┌─────────────────────────────────────────────┐
│  VALIDATION REPORT — Run ID: {run_id}        │
├─────────────────────┬───────────────────────┤
│  Files converted    │ {count}               │
│  Import checks      │ PASS / FAIL           │
│  pytest total       │ {total_tests}         │
│  pytest passed      │ {passed}              │
│  pytest failed      │ {failed}              │
│  Files needing review│ {needs_review_count} │
└─────────────────────┴───────────────────────┘
```

Emit: `Reply FINALIZE {run_id} to proceed or ABORT {run_id} to stop.`

Wait for explicit user reply.

**On `FINALIZE {run_id}`** → continue to Phase 8.
**On `ABORT {run_id}`** → log abort, provide repair instructions, stop.

---

### Phase 8 — Reviewer
Invoke `agent-08-reviewer.md` inline as yourself.
- Input: all phase artifacts
- Output: review-report.json, cutover-plan.md, rollback-plan.md

### Phase 9 — Final Reporter
Invoke `agent-09-final-reporter.md` inline as yourself.
- Input: all phase artifacts
- Output: final-report.md, final-summary.json

---

## Pipeline Complete — Emit to User

```
╔══════════════════════════════════════════════════╗
║  ✅ Java → Python Migration Complete              ║
║  Run ID: {run_id}                                 ║
╠══════════════════════════════════════════════════╣
║  Converted source  → migration-artifacts/runs/{run_id}/05-conversion/src/   ║
║  Tests             → migration-artifacts/runs/{run_id}/06-tests/tests/      ║
║  Cutover plan      → migration-artifacts/runs/{run_id}/08-review/cutover-plan.md ║
║  Final report      → migration-artifacts/runs/{run_id}/09-final-report/final-report.md ║
╚══════════════════════════════════════════════════╝
```

---

## AFTER COMPLETION — EMIT THIS EXACTLY

```
✅ MASTER AGENT complete. Run ID: {run_id}
All phases executed. Artifacts in: migration-artifacts/runs/{run_id}/
Final report: migration-artifacts/runs/{run_id}/09-final-report/final-report.md

─────────────────────────────────────────
▶ To resume a failed run → paste:
#file:copilot-agents/master-agent.md
Run ID: {run_id}. Resume Java-to-Python migration pipeline.
─────────────────────────────────────────
```

---

## Resume Mode

If invoked with an existing `run_id`:
1. Scan `migration-artifacts/runs/{run_id}/` for the last successfully completed phase.
2. Skip all completed phases (resume_mode: true on each).
3. Resume from the first incomplete or failed phase.
4. Announce: `♻️ Resuming Run ID: {run_id} from Phase {N} — {agent-name}`
