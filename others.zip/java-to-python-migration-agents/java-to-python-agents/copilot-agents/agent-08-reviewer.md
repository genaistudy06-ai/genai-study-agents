# Agent 08 — Reviewer & Cutover Planner

> Inherits all rules from `.copilot/instructions.md`.

---

## ON ACTIVATION — START HERE IMMEDIATELY

Do not ask the user for instructions. Begin now:

1. Read `run_id` from context.
2. Verify handoff: `migration-artifacts/runs/{run_id}/07-validation/validation-report.json` — must exist, status=SUCCESS or FAILED (not BLOCKED).
3. Check resume: if `migration-artifacts/runs/{run_id}/08-review/review-report.json` exists and is valid → skip to AFTER COMPLETION.
4. Announce: `📝 Phase 8 — Generating review, cutover, and rollback plans...`
5. Execute all steps below.

---

## Step 1 — Consolidate All Gate Verdicts

Load artifacts from all prior phases and summarize the end-to-end picture:

| Phase | Agent              | Status | Key Findings |
|-------|--------------------|--------|--------------|
| 0     | Auditor            | {status} | {findings} |
| 1     | Java Parser        | {status} | {findings} |
| 2     | Dependency Mapper  | {status} | {findings} |
| 3     | Go/No-Go           | {status} | {recommendation} |
| 4     | Type Strategy      | {status} | {strategies} |
| 5     | Conversion         | {status} | {success/review/fail counts} |
| 6     | Test Generator     | {status} | {test counts} |
| 7     | Validator          | {status} | {pass_rate, health} |

---

## Step 2 — Migration Quality Assessment

Score the migration on 5 dimensions (0–10 each):

| Dimension                  | Score | Rationale |
|----------------------------|-------|-----------|
| Conversion completeness    | /10   | % of files with SUCCESS status |
| Test coverage              | /10   | migrated tests / original Java tests |
| Test pass rate             | /10   | pytest pass rate |
| Type safety                | /10   | 10 - (mypy_errors / total_methods) × 10 |
| Code quality               | /10   | 10 - (ruff violations / total_lines × 100) |

Overall score = weighted average:
```
overall = (completeness × 0.3 + test_pass × 0.3 + coverage × 0.15 + type_safety × 0.15 + quality × 0.1)
```

Grade: A (≥9), B (≥7.5), C (≥6), D (≥4.5), F (<4.5)

---

## Step 3 — Files Requiring Manual Attention

Produce a prioritized list of files that need human review, ordered by severity:

**Priority 1 — Must Fix Before Production**:
- Conversion status `FAILED`
- Confidence score < 0.5
- pytest tests failing for this file
- `F821` (undefined name) mypy errors

**Priority 2 — Should Fix Before Production**:
- Conversion status `NEEDS_REVIEW`
- Incomplete test migration (missing mocks/assertions)
- mypy errors (not F821)

**Priority 3 — Nice to Fix**:
- Skeleton tests not yet implemented
- Ruff violations > 5 per file
- Confidence 0.5–0.7

For each file in Priority 1:
```markdown
### ❌ src/example/service/ComplexService.py
**Reason**: Conversion confidence 0.38 — complex threading pattern not fully translated
**Java source**: src/main/java/com/example/service/ComplexService.java
**Issues**:
- Line 45: `synchronized` block converted to Lock but shared state logic unclear
- Line 78: Thread pool (ExecutorService) → asyncio conversion needs verification
**Suggested action**: Manual review of concurrency logic. Consider using `asyncio.gather` or `concurrent.futures.ThreadPoolExecutor`.
```

---

## Step 4 — Dependency Configuration Review

List all unmapped Java dependencies with actionable research steps:

```markdown
### Unmapped Dependency: com.example.internal:custom-audit-lib:2.1.0
**Status**: No Python equivalent found
**Options**:
1. Rewrite the functionality natively in Python
2. Check if the library is open source and has a Python port
3. Wrap the JAR via Py4J or JPype (not recommended for production)
4. Contact the library maintainer
```

---

## Step 5 — Generate Cutover Plan

Write `migration-artifacts/runs/{run_id}/08-review/cutover-plan.md`:

```markdown
# Cutover Plan — Java → Python Migration
**Run ID**: {run_id}
**Migration grade**: {grade} ({overall_score}/10)
**Generated**: {timestamp}

---

## Pre-Cutover Checklist

### Code Readiness
- [ ] All Priority 1 files manually reviewed and fixed
- [ ] pytest pass rate ≥ 90% (currently: {pass_rate}%)
- [ ] mypy --strict passes with no F821 errors
- [ ] ruff check passes with no E/F violations
- [ ] requirements.txt pinned to exact versions: `pip freeze > requirements-locked.txt`

### Infrastructure Readiness
- [ ] Python 3.11+ installed in target environment
- [ ] PostgreSQL/MySQL driver installed and connection string configured in .env
- [ ] Database migration (Alembic) initialized: `alembic init alembic && alembic revision --autogenerate`
- [ ] Alembic migration tested against staging DB
- [ ] Uvicorn / Gunicorn server configured
- [ ] Environment variables ported from Java `application.properties` → `.env` file

### Testing Readiness
- [ ] Integration tests pass against staging database
- [ ] Load test run: `locust -f locustfile.py` (generate locustfile from Java load tests)
- [ ] API contract validated: if Swagger/OpenAPI exists in Java, compare with FastAPI auto-generated docs

### Rollback Readiness
- [ ] Java service still running and deployable (do not decommission yet)
- [ ] Feature flag or API gateway switch prepared (to route traffic back to Java if needed)
- [ ] Database has no Python-only schema changes applied yet (or they are backward compatible)

---

## Cutover Execution Steps

### Step 1 — Deploy Python Service (Shadow Mode)
Deploy the Python service alongside the Java service. Do not route production traffic yet.

```bash
# Install dependencies
pip install -r requirements-locked.txt

# Run DB migrations (read-only check first)
alembic upgrade head --sql  # dry-run

# Start service
uvicorn src.main:app --host 0.0.0.0 --port 8081 --workers 4
```

### Step 2 — Shadow Traffic Testing
Route a copy of production traffic to Python service using your load balancer (e.g., nginx `mirror` directive or AWS ALB).
Compare responses between Java (authoritative) and Python (shadow).
Monitor for 24–48 hours.

### Step 3 — Canary Rollout
Route 5% → 25% → 50% → 100% of traffic to Python service.
After each increment, monitor:
- Error rate (target: < Java baseline)
- p50/p95/p99 latency
- Business metrics (same as Java baseline)

### Step 4 — Full Cutover
Route 100% of traffic to Python service.
Keep Java service running on standby for 1 week.

### Step 5 — Decommission Java Service
After 1 week without rollback trigger:
- Archive Java source
- Remove Java service from deployment pipeline
- Update documentation

---

## Environment Variable Mapping

Port Java `application.properties` to Python `.env`:

| Java Property                         | Python .env Variable        |
|---------------------------------------|-----------------------------|
| `spring.datasource.url`               | `DATABASE_URL`              |
| `spring.datasource.username`          | `DB_USER`                   |
| `spring.datasource.password`          | `DB_PASSWORD`               |
| `server.port`                         | `PORT` (uvicorn `--port`)   |
| `spring.kafka.bootstrap-servers`      | `KAFKA_BOOTSTRAP_SERVERS`   |
| `spring.redis.host`                   | `REDIS_HOST`                |
| `logging.level.root`                  | `LOG_LEVEL`                 |
| `spring.security.oauth2.issuer-uri`   | `OAUTH_ISSUER_URI`          |

Sample `.env.template`:
```env
DATABASE_URL=postgresql+psycopg2://user:pass@localhost:5432/dbname
PORT=8080
LOG_LEVEL=INFO
# ... add all mapped properties
```
```

---

## Step 6 — Generate Rollback Plan

Write `migration-artifacts/runs/{run_id}/08-review/rollback-plan.md`:

```markdown
# Rollback Plan — Java → Python Migration
**Run ID**: {run_id}
**Valid until**: Java service decommissioned

---

## Rollback Triggers

Roll back immediately if any of these occur after cutover:
- Error rate > 1% above Java baseline for > 5 minutes
- p99 latency > 2× Java baseline for > 10 minutes
- Any data corruption detected
- Any security vulnerability found in migrated auth code
- Business-critical bug with no immediate fix available

---

## Rollback Steps

### Immediate (< 2 minutes)
1. Switch API gateway / load balancer to route all traffic back to Java service.
2. Verify Java service health: `curl http://java-host:8080/actuator/health`
3. Alert on-call team via incident channel.

### Short-term (< 1 hour)
1. Identify root cause from Python service logs.
2. Capture all Python service logs for post-mortem.
3. If DB schema was changed: roll back with `alembic downgrade -1`.

### Post-rollback
1. File issue with root cause, affected test case, and repro steps.
2. Fix in Python service.
3. Re-run agent-05 through agent-07 for affected files only.
4. Repeat validation and cutover process.

---

## Rollback Decision Matrix

| Severity | Auto-rollback? | Timeline |
|----------|---------------|----------|
| CRITICAL (data loss / security) | YES — automated | Immediate |
| HIGH (error rate > 1%) | Manual | < 2 min |
| MEDIUM (latency degradation) | Manual | < 10 min |
| LOW (cosmetic / non-functional) | No rollback | Fix-forward |
```

---

## Step 7 — Write Output Artifacts

Write `migration-artifacts/runs/{run_id}/08-review/review-report.json` with standard output block.

---

## AFTER COMPLETION — EMIT THIS EXACTLY

```
✅ PHASE 8 — REVIEW complete. Run ID: {run_id}
Migration grade: {grade} ({overall_score}/10)
Priority 1 (must fix): {p1_count} files
Priority 2 (should fix): {p2_count} files
Cutover plan: migration-artifacts/runs/{run_id}/08-review/cutover-plan.md
Rollback plan: migration-artifacts/runs/{run_id}/08-review/rollback-plan.md

─────────────────────────────────────────
▶ To continue → paste this prompt:
#file:copilot-agents/agent-09-final-reporter.md
Run ID: {run_id}. Continue migration pipeline.
─────────────────────────────────────────

If invoked from master-agent, proceed directly without emitting the prompt block.
```
