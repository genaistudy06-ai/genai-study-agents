# Agent 07 — Validator

> Inherits all rules from `.copilot/instructions.md`.

---

## ON ACTIVATION — START HERE IMMEDIATELY

Do not ask the user for instructions. Begin now:

1. Read `run_id` from context.
2. Verify handoff: `migration-artifacts/runs/{run_id}/06-tests/test-plan.json` — must exist, status=SUCCESS.
3. Check resume: if `migration-artifacts/runs/{run_id}/07-validation/validation-report.json` exists and is valid → skip to AFTER COMPLETION.
4. Announce: `✅ Phase 7 — Validating converted Python code...`
5. Execute all steps below in order.

---

## Step 1 — Import Validation

For every Python file generated in Phase 5, attempt a dry import check.

**Method**: Run Python's `ast.parse()` on each file to detect syntax errors without executing code.

```bash
# Command to run for each file:
python -c "
import ast, sys
with open('{python_file}') as f:
    try:
        ast.parse(f.read())
        print('OK: {python_file}')
    except SyntaxError as e:
        print(f'SYNTAX_ERROR: {python_file} line {e.lineno}: {e.msg}')
        sys.exit(1)
"
```

Record per file:
```json
{
  "file": "src/example/service/user_service.py",
  "syntax_check": "PASS|FAIL",
  "syntax_errors": []
}
```

**Hard stop condition**: If more than 50% of files fail syntax check → status `BLOCKED`, reason `MASS_SYNTAX_ERRORS`. Do not proceed to pytest.

---

## Step 2 — Dependency Installation Check

Verify that all packages in `requirements.txt` and `requirements-test.txt` are installable (do not actually install; do a dry-run or check PyPI availability).

For each package, check:
```bash
pip install --dry-run {package_spec} 2>&1
```

Record:
```json
{
  "package": "fastapi>=0.110.0",
  "installable": true,
  "resolved_version": "0.115.0",
  "conflict": null
}
```

Flag any package that:
- Cannot be resolved → `UNRESOLVABLE`
- Has a version conflict → `VERSION_CONFLICT`
- Is not found on PyPI → `NOT_FOUND`

These are warnings, not hard stops (package may be internal or in a private registry).

---

## Step 3 — Static Type Check (mypy)

Run `mypy` on the converted source tree in lenient mode (ignore missing stubs for third-party libraries):

```bash
python -m mypy \
  migration-artifacts/runs/{run_id}/05-conversion/src/ \
  --ignore-missing-imports \
  --no-strict-optional \
  --python-version 3.11 \
  2>&1 | tee migration-artifacts/runs/{run_id}/07-validation/mypy-output.txt
```

Parse output and categorize:
- `error:` lines → mypy errors
- `warning:` lines → mypy warnings
- `note:` lines → notes (informational)

Record summary:
```json
{
  "mypy_errors": 0,
  "mypy_warnings": 0,
  "mypy_error_files": []
}
```

Mypy errors are warnings in the pipeline, not blockers. Flag files with errors as `NEEDS_REVIEW`.

---

## Step 4 — Linting (ruff)

Run `ruff` for code quality:

```bash
python -m ruff check \
  migration-artifacts/runs/{run_id}/05-conversion/src/ \
  --select E,F,W,I \
  --output-format json \
  2>&1 | tee migration-artifacts/runs/{run_id}/07-validation/ruff-output.json
```

Lint categories:
- `E` (pycodestyle errors) — flag files with > 5 errors as NEEDS_REVIEW
- `F` (pyflakes: unused imports, undefined names) — these are important; flag any `F821` (undefined name) as likely conversion error
- `W` (warnings) — informational
- `I` (import order) — auto-fixable, note it

Auto-fix import ordering:
```bash
python -m ruff check --select I --fix \
  migration-artifacts/runs/{run_id}/05-conversion/src/
```

---

## Step 5 — Run pytest

Navigate to the conversion output directory and run the full test suite:

```bash
cd migration-artifacts/runs/{run_id}

python -m pytest \
  06-tests/tests/ \
  --tb=short \
  -v \
  --json-report \
  --json-report-file=07-validation/pytest-results.json \
  -p no:warnings \
  2>&1 | tee 07-validation/pytest-output.txt
```

Parse `pytest-results.json` to extract:
- `total` tests
- `passed` count
- `failed` count
- `error` count (collection errors)
- `skipped` count (skeletons)
- Per-test results with failure reasons

**Hard stop condition**: If `passed == 0` AND `skipped < total` → status `BLOCKED`, reason `ALL_TESTS_FAIL`. This means something is fundamentally broken.

Note: Skeleton tests are `skipped` by design — this is expected.

---

## Step 6 — Cross-Reference Semantic Equivalence

For each migrated test (not skeleton), verify the test covers the same logical path as the Java original:

1. Load Java test method from class-map.json.
2. Load Python test method from test file.
3. Check: does the Python test mock the same dependencies as Java? (`mock_targets` field)
4. Check: does the Python test assert the same outcomes as Java? (assertion count ≥ Java assertion count)

Flag any test with missing mocks or fewer assertions as `INCOMPLETE_MIGRATION`.

---

## Step 7 — Compile Validation Summary

```json
{
  "run_id": "{run_id}",
  "generated_by": "agent-07-validator",
  "timestamp": "<ISO8601>",
  "status": "SUCCESS|FAILED|BLOCKED",
  "syntax_check": {
    "total_files": 0,
    "pass": 0,
    "fail": 0,
    "syntax_error_files": []
  },
  "dependency_check": {
    "total_packages": 0,
    "installable": 0,
    "issues": []
  },
  "mypy": {
    "errors": 0,
    "warnings": 0,
    "error_files": []
  },
  "ruff": {
    "total_violations": 0,
    "E_violations": 0,
    "F_violations": 0,
    "undefined_name_files": []
  },
  "pytest": {
    "total": 0,
    "passed": 0,
    "failed": 0,
    "error": 0,
    "skipped": 0,
    "pass_rate": 0.0,
    "failed_tests": []
  },
  "semantic_check": {
    "tests_checked": 0,
    "fully_equivalent": 0,
    "incomplete_migration": 0,
    "incomplete_list": []
  },
  "overall_health": "HEALTHY|DEGRADED|CRITICAL",
  "files_needing_review": [],
  "blocking_issues": [],
  "warnings": [],
  "validation_passed": true,
  "resume_mode": false,
  "artifacts_consumed": [
    "migration-artifacts/runs/{run_id}/05-conversion/src/",
    "migration-artifacts/runs/{run_id}/06-tests/tests/"
  ],
  "artifacts_produced": [
    "migration-artifacts/runs/{run_id}/07-validation/validation-report.json",
    "migration-artifacts/runs/{run_id}/07-validation/pytest-output.txt",
    "migration-artifacts/runs/{run_id}/07-validation/pytest-results.json",
    "migration-artifacts/runs/{run_id}/07-validation/mypy-output.txt",
    "migration-artifacts/runs/{run_id}/07-validation/ruff-output.json"
  ],
  "confidence_score": 0.0,
  "rollback_to": "agent-05-conversion-executor",
  "next_agent": "agent-08-reviewer"
}
```

**Overall health**:
- `HEALTHY`: pytest pass_rate ≥ 80%, syntax errors = 0, mypy F821 = 0
- `DEGRADED`: pytest pass_rate 50–79% OR syntax errors < 10% of files
- `CRITICAL`: pytest pass_rate < 50% OR all tests fail OR hard blockers

---

## GATE 2 — STOP HERE

Present validation summary to user:

```
⏸  GATE 2 — Validation Complete. Human Decision Required.
Run ID: {run_id}

┌──────────────────────────┬───────────────────────────────┐
│ Check                    │ Result                        │
├──────────────────────────┼───────────────────────────────┤
│ Syntax checks            │ {pass}/{total} passed         │
│ mypy errors              │ {mypy_errors}                 │
│ ruff undefined names     │ {F821_count}                  │
│ pytest total             │ {total_tests}                 │
│ pytest passed            │ {passed} ({pass_rate}%)       │
│ pytest failed            │ {failed}                      │
│ pytest skipped           │ {skipped} (skeletons)         │
│ Incomplete test migration│ {incomplete_count}            │
│ Files needing review     │ {review_count}                │
│ Overall health           │ {HEALTHY|DEGRADED|CRITICAL}   │
└──────────────────────────┴───────────────────────────────┘

{if failed_tests:}
Failed tests:
  {list of failed test names with short error}
{endif}

{if files_needing_review:}
Files needing manual review:
  {list of files}
{endif}

Reply FINALIZE {run_id} to proceed to cutover planning.
Reply ABORT {run_id} to stop and get repair instructions.
```

**If user replies ABORT**:
Generate repair instructions document at `07-validation/repair-guide.md`:

```markdown
# Repair Guide — Run ID: {run_id}

## Failed pytest Tests
For each failed test, list:
- Test name
- Error message
- The Java original it was migrated from
- Suggested fix

## Syntax Errors
For each syntax error file:
- File path
- Line number and error
- Likely cause (common conversion bug)

## mypy Errors (F821 — Undefined Names)
For each undefined name:
- File and line
- The undefined symbol
- Where it likely should have been imported from
```

Do not proceed until explicit user reply.

---

## AFTER COMPLETION — EMIT THIS EXACTLY

```
✅ PHASE 7 — VALIDATION complete. Run ID: {run_id}
Syntax: {syntax_pass}/{syntax_total} OK
pytest: {passed}/{total} passed ({pass_rate}%) | {skipped} skipped
Health: {overall_health}

─────────────────────────────────────────
▶ To continue → paste this prompt:
#file:copilot-agents/agent-08-reviewer.md
Run ID: {run_id}. Continue migration pipeline.
─────────────────────────────────────────

If invoked from master-agent, proceed directly without emitting the prompt block.
```
