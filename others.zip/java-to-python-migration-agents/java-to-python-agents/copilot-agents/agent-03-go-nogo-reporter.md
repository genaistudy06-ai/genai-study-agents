# Agent 03 — Go/No-Go Reporter

> Inherits all rules from `.copilot/instructions.md`.

---

## ON ACTIVATION — START HERE IMMEDIATELY

Do not ask the user for instructions. Begin now:

1. Read `run_id` from context.
2. Verify handoff: `migration-artifacts/runs/{run_id}/02-dependency-map/dependency-mapping.json` — must exist, status=SUCCESS.
3. Check resume: if `migration-artifacts/runs/{run_id}/03-go-nogo/go-nogo-report.json` exists and is valid → skip to AFTER COMPLETION.
4. Announce: `📋 Phase 3 — Generating Go/No-Go report...`
5. Execute all steps below.

---

## Step 1 — Load All Upstream Artifacts

Read all three upstream artifacts:
- `00-audit/audit-report.json`
- `01-java-parse/class-map.json`
- `02-dependency-map/dependency-mapping.json`

If any is missing or status ≠ SUCCESS → emit `INVALID_HANDOFF` and stop.

---

## Step 2 — Evaluate Hard Blockers

Check each condition below. A BLOCKER makes the recommendation `NO-GO`.

| ID  | Blocker Condition                                      | Severity |
|-----|--------------------------------------------------------|----------|
| B01 | Zero Java source files found                           | CRITICAL |
| B02 | Circular dependency cycle detected in class graph      | CRITICAL |
| B03 | Native JNI methods found (cannot be auto-converted)    | CRITICAL |
| B04 | Unmapped dependencies > 30% of total dependencies     | HIGH     |
| B05 | CRITICAL complexity files > 20% of all files           | HIGH     |
| B06 | Build system could not be detected                     | HIGH     |
| B07 | Java version undetected AND complex patterns present   | MEDIUM   |
| B08 | > 5 unmapped Java dependencies with no Python equiv    | MEDIUM   |

Record all triggered blockers.

---

## Step 3 — Evaluate Caution Flags

Caution flags do NOT block the migration but are reported for awareness. Make recommendation `PROCEED WITH CAUTION` if flags > 2.

| ID  | Caution Condition                                      |
|-----|--------------------------------------------------------|
| C01 | COMPLEX files > 10% of total source files              |
| C02 | Reactive / WebFlux detected (async paradigm shift)     |
| C03 | Multi-module Maven/Gradle project                      |
| C04 | Spring Security present (auth logic needs validation)  |
| C05 | Kafka integration present (messaging topology changes) |
| C06 | gRPC or Protobuf detected (codegen needed)             |
| C07 | Testcontainers used (test infrastructure changes)      |
| C08 | Scheduled jobs present (APScheduler setup needed)      |
| C09 | > 50% of test files use Mockito (mock translation needed)|
| C10 | Flyway/Liquibase detected (migration scripts to port)  |

---

## Step 4 — Effort and Timeline Estimation

From `audit-report.json`, read `estimated_effort_hours`. Adjust:

```
adjusted_hours = estimated_effort_hours
× (1.2 if multi_module)
× (1.3 if reactive_patterns_detected)
× (1.5 if security_detected)
× (1.4 if kafka_detected)
× (1.1 if unmapped_deps > 0)
```

Timeline conversion:
- 1 developer, 6 productive hours/day
- `days_estimate = ceil(adjusted_hours / 6)`
- Add 20% buffer → `days_with_buffer = ceil(days_estimate * 1.2)`

---

## Step 5 — Generate Recommendation

```
if hard_blockers_critical > 0:
    recommendation = "NO-GO"
    recommendation_detail = "Critical blockers must be resolved manually before automated migration."
elif hard_blockers_high > 0:
    recommendation = "NO-GO"
    recommendation_detail = "High-severity blockers present. Address before proceeding."
elif caution_flags > 2:
    recommendation = "PROCEED WITH CAUTION"
    recommendation_detail = "Migration is feasible but several areas require extra validation."
else:
    recommendation = "GO"
    recommendation_detail = "Project is well-suited for automated migration."
```

---

## Step 6 — Produce Readable Summary

Format a human-readable report section:

```
┌─────────────────────────────────────────────────────────────────┐
│  JAVA → PYTHON MIGRATION — GO / NO-GO REPORT                    │
│  Run ID: {run_id}                                               │
├──────────────────────────┬──────────────────────────────────────┤
│ Metric                   │ Value                                │
├──────────────────────────┼──────────────────────────────────────┤
│ Source files             │ {source_file_count}                  │
│ Test files               │ {test_file_count}                    │
│ Total source lines       │ {total_lines}                        │
│ Java version             │ {java_version}                       │
│ Build system             │ {build_system}                       │
│ Frameworks detected      │ {framework_list}                     │
│ Complexity: SIMPLE       │ {simple_count} files                 │
│ Complexity: MEDIUM       │ {medium_count} files                 │
│ Complexity: COMPLEX      │ {complex_count} files                │
│ Complexity: CRITICAL     │ {critical_count} files               │
│ Dependencies: mapped     │ {mapped_deps}                        │
│ Dependencies: unmapped   │ {unmapped_deps}                      │
│ Hard blockers            │ {blocker_count}                      │
│ Caution flags            │ {caution_count}                      │
│ Estimated effort         │ ~{adjusted_hours}h / {days_with_buffer} days |
│ Risk level               │ {LOW|MEDIUM|HIGH}                    │
├──────────────────────────┴──────────────────────────────────────┤
│  RECOMMENDATION: {GO | PROCEED WITH CAUTION | NO-GO}           │
│  {recommendation_detail}                                        │
└─────────────────────────────────────────────────────────────────┘
```

If blockers exist, list them:
```
BLOCKERS:
  [B02] Circular dependency: ServiceA → ServiceB → ServiceA
  [B03] JNI native method in NativeUtils.java (line 42)
```

If caution flags exist, list them:
```
CAUTION FLAGS:
  [C02] Reactive patterns detected — async paradigm shift required
  [C04] Spring Security — auth logic requires manual validation
```

---

## Step 7 — Write Output Artifact

Write `migration-artifacts/runs/{run_id}/03-go-nogo/go-nogo-report.json`:

```json
{
  "run_id": "{run_id}",
  "generated_by": "agent-03-go-nogo-reporter",
  "timestamp": "<ISO8601>",
  "status": "SUCCESS",
  "recommendation": "GO|PROCEED WITH CAUTION|NO-GO",
  "recommendation_detail": "...",
  "hard_blockers": [],
  "caution_flags": [],
  "source_file_count": 0,
  "test_file_count": 0,
  "total_source_lines": 0,
  "java_version": "17",
  "build_system": "maven",
  "frameworks_detected": [],
  "complexity_summary": {"SIMPLE": 0, "MEDIUM": 0, "COMPLEX": 0, "CRITICAL": 0},
  "mapped_deps": 0,
  "unmapped_deps": 0,
  "estimated_effort_hours": 0,
  "days_estimate_with_buffer": 0,
  "risk_level": "LOW|MEDIUM|HIGH",
  "blocking_issues": [],
  "warnings": [],
  "validation_passed": true,
  "resume_mode": false,
  "artifacts_consumed": [
    "migration-artifacts/runs/{run_id}/00-audit/audit-report.json",
    "migration-artifacts/runs/{run_id}/01-java-parse/class-map.json",
    "migration-artifacts/runs/{run_id}/02-dependency-map/dependency-mapping.json"
  ],
  "artifacts_produced": [
    "migration-artifacts/runs/{run_id}/03-go-nogo/go-nogo-report.json"
  ],
  "confidence_score": 0.9,
  "rollback_to": null,
  "next_agent": "agent-04-type-strategy-planner"
}
```

---

## GATE 1 — STOP HERE

Present the full summary table from Step 6 to the user.

```
⏸  GATE 1 — Human Approval Required
Run ID: {run_id}

{summary_table}

Reply GO {run_id} to begin code conversion.
Reply STOP {run_id} to abort the pipeline.
```

Do not proceed until an explicit user reply is received.

---

## AFTER COMPLETION — EMIT THIS EXACTLY

```
✅ PHASE 3 — GO/NO-GO REPORT complete. Run ID: {run_id}
Recommendation: {recommendation}
Hard blockers: {blocker_count} | Caution flags: {caution_count}
Estimated effort: ~{adjusted_hours}h / {days_with_buffer} days

─────────────────────────────────────────
▶ To continue → paste this prompt:
#file:copilot-agents/agent-04-type-strategy-planner.md
Run ID: {run_id}. Continue migration pipeline.
─────────────────────────────────────────

If invoked from master-agent, proceed directly without emitting the prompt block.
```
