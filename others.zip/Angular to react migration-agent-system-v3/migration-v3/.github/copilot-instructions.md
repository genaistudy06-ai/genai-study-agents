# GitHub Copilot — Workspace Context

## Migration Agent System v3

Angular → React incremental migration pipeline.
Works in any NX monorepo — auto-discovers project structure on every session.

**All work starts with:**
```
@MigrateOrchestrator
```

**First time? Run scaffold first:**
```
@MigrateOrchestrator scaffold
```

---

## Agents

| Agent | Role | Invoked By |
|---|---|---|
| MigrateOrchestrator | Entry point, routing, learning capture | User |
| MigrateScaffold | React project setup, Vite, styles, assets (run once) | Orchestrator |
| MigrateAuditor | Pre-migration analysis | Orchestrator |
| MigrateCoder | Angular → React translation | Orchestrator |
| MigrateTester | Vitest + RTL tests, 100% coverage | Orchestrator |
| MigrateReviewer | 8 quality gates including Style & Asset compliance | Orchestrator |

---

## Shared Knowledge Files

| File | Purpose |
|---|---|
| `WORKSPACE_MAP.md` | Live project structure — regenerated every session |
| `USER_PREFERENCES.md` | CSS approach, fonts, auth, build — captured at scaffold |
| `MIGRATION_LEARNINGS.md` | Patterns and known mistakes — grows with each module |
| `MIGRATION.md` | Module progress tracker |
| `SESSION_STATE.md` | Mid-pipeline checkpoint for resumability |
| `REVIEW_REPORT.md` | Latest gate results |
| `PR_DESCRIPTION.md` | Auto-generated PR description (on approval) |

---

## Quality Standards

- 100% Vitest coverage (statements, branches, functions, lines)
- Zero ESLint errors
- Zero SonarQube issues
- Cognitive complexity ≤ 15
- `React.memo` on every component
- `useCallback` on every callback prop
- `useMemo` on every derived value
- All font files verified to exist at referenced paths
- No `:host` or `::ng-deep` in CSS Modules
- No relative font URL paths
- Dev server returns HTTP 200 after every module pipeline

---

## Instruction Files
- `.github/instructions/angular-to-react-migration.instructions.md`
- `.github/instructions/angular-to-react-incremental-migration.instructions.md`
